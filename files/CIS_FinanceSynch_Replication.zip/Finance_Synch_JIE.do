/*==============================================================================
REPLICATION CODES OF "FINANCE AND SYNCHRONIZATION"
BY A. CESA-BIANCHI, J. SALEHEEN, AND J. IMBS  
*===============================================================================
This Stata (.DO) file provides the replication codes for the results in 
Cesa-Bianchi, Saleheen, and Imbs (2018), "Finance and Synchronization," 
forthcoming in the Journal of International Economics.

Note: the bilateral financial linkages data from the BIS are not publicly 
available. See footnote 10 in the text. We therefore removed from the data file 
"Finance_Synch_DATA_JIE.dta" all confidential data.

To be able to run this DO file codes is therefore necessary to obtain banks' 
cross-border claims and liabilities from the BIS, and construct the variables 
"bankint1" and "bankint2" (see the text for the definition of these variables).

These data are accessible by anyone affiliated with a participating central bank 
through DBS Online. The BIS also agrees to grant access to the data to anyone 
wishing to replicate the results upon physically arriving at the BIS and 
conducting analysis on the premises.
*=============================================================================*/


* Table 1 
*-------------------------------------------------------------------------------
use "Finance_Synch_DATA_JIE.dta", clear
set more off
sort id year 
by id: egen mm=mean(ggdp)
by id: egen ss=sd(ggdp)
gen ggdpn = (ggdp-mm)/ss
keep year c ggdpn 
collapse ggdpn, by(c year)
reshape wide ggdpn, i(year) j(c)
pca ggdpn*, covariance

* Table 2
*-------------------------------------------------------------------------------
use "Finance_Synch_DATA_JIE.dta", clear
set more off
keep if c<p
eststo clear
eststo: xtreg S  L1.bankint1 i.year, fe robust
eststo: xtreg SF L1.bankint1 i.year, fe robust
eststo: xtreg Se L1.bankint1 i.year, fe robust
eststo: xtreg S  L1.bankint2 i.year, fe robust
eststo: xtreg SF L1.bankint2 i.year, fe robust
eststo: xtreg Se L1.bankint2 i.year, fe robust
esttab, drop(19* 20* _c*)

* Table 3
*-------------------------------------------------------------------------------
use "Finance_Synch_DATA_JIE.dta", clear
set more off
keep if c<p
eststo clear
eststo: xtreg S  L1.bankint1 L1.tradeint i.year, fe robust
eststo: xtreg SF L1.bankint1 L1.tradeint i.year, fe robust
eststo: xtreg Se L1.bankint1 L1.tradeint i.year, fe robust
eststo: xtreg S  L1.bankint2 L1.tradeint i.year, fe robust
eststo: xtreg SF L1.bankint2 L1.tradeint i.year, fe robust
eststo: xtreg Se L1.bankint2 L1.tradeint i.year, fe robust
esttab, drop(19* 20* _c*)

* Table 4
*-------------------------------------------------------------------------------
use "Finance_Synch_DATA_JIE.dta", clear
set more off 
keep if c<p
drop if year>2006
eststo clear
eststo: xtreg S  L1.bankint1 i.year, fe robust
eststo: xtreg SF L1.bankint1 i.year, fe robust
eststo: xtreg Se L1.bankint1 i.year, fe robust
eststo: xtreg S  L1.bankint2 i.year, fe robust
eststo: xtreg SF L1.bankint2 i.year, fe robust
eststo: xtreg Se L1.bankint2 i.year, fe robust
esttab, drop(19* 20* _c*)

* Table 5
*-------------------------------------------------------------------------------
use "Finance_Synch_DATA_JIE.dta", clear
set more off 
keep if c<p
drop if year>2006
eststo clear
eststo: xtivreg S  (bankint1 = lnfsap) i.year, fe first
eststo: xtivreg SF (bankint1 = lnfsap) i.year, fe first
eststo: xtivreg Se (bankint1 = lnfsap) i.year, fe first
eststo: xtivreg S  (bankint2 = lnfsap) i.year, fe first
eststo: xtivreg SF (bankint2 = lnfsap) i.year, fe first
eststo: xtivreg Se (bankint2 = lnfsap) i.year, fe first
esttab, drop(19* 20* _c*)

* Table 6
*-------------------------------------------------------------------------------
use "Finance_Synch_DATA_JIE.dta", clear
set more off 
keep if c<p
gen B1 = bi_1*bj_1
gen B2 = bi_2*bj_2
gen B3 = bi_3*bj_3
* Same sign by PC
g same1 = (bi_1 - bj_1)*pc1 if B1>0
g same2 = (bi_2 - bj_2)*pc2 if B2>0
g same3 = (bi_3 - bj_3)*pc3 if B3>0
replace same1 = 0 if (same1== .)
replace same2 = 0 if (same2== .)
replace same3 = 0 if (same3== .)
g SF_same = -abs(same1 + same2 + same3)
* Opposite sign by PC
g samenot1 = (bi_1 - bj_1)*pc1 if B1<0
g samenot2 = (bi_2 - bj_2)*pc2 if B2<0
g samenot3 = (bi_3 - bj_3)*pc3 if B3<0
replace samenot1 = 0 if (samenot1== .) & ((samenot2~=.) | (samenot3~=.))
replace samenot2 = 0 if (samenot2== .) & ((samenot1~=.) | (samenot3~=.))
replace samenot3 = 0 if (samenot3== .) & ((samenot1~=.) | (samenot2~=.))
g SF_samenot = -abs(samenot1 + samenot2 + samenot3)
* Regressions
eststo clear
eststo: xtreg SF         L1.bankint1 L1.tradeint i.year, fe robust
eststo: xtreg SF_same    L1.bankint1 L1.tradeint i.year, fe robust
eststo: xtreg SF_samenot L1.bankint1 L1.tradeint i.year, fe robust
eststo: xtreg SF         L1.bankint2 L1.tradeint i.year, fe robust
eststo: xtreg SF_same    L1.bankint2 L1.tradeint i.year, fe robust
eststo: xtreg SF_samenot L1.bankint2 L1.tradeint i.year, fe robust
esttab, drop(19* 20* _c*)

* Figure 4
*-------------------------------------------------------------------------------
* Generate K loadings
use "Finance_Synch_DATA_JIE.dta", clear
keep if c<p
keep bankint1 year id
reshape wide bankint1, i(year) j(id)
* Drop six (of 153) pairs for which we do not have full sample (make panel balanced)
drop bankint1236 bankint1237 bankint1238 bankint1271 bankint1272 bankint1289  
* PCA
pca  bankint1*
predict FK1 FK2 FK3 FK4 FK5
reshape long
tsset id year, yearly
* Regression
xi: xtreg bankint1, fe
predict aux, e
gen fFK0 = bankint1 - aux
drop aux
* Regression
xi: xtreg bankint1 i.id*FK1, fe
predict eFK1, e
gen fFK1 = bankint1 - fFK0 - eFK1
gen bkij_1 = fFK1/FK1
save "temp.dta", replace

* Scatter
use "Finance_Synch_DATA_JIE.dta", clear
keep if c<p
merge m:m id year using "temp.dta"
erase "temp.dta"
gen bibj_1_abs = abs(bibj_1)
collapse bibj_1_abs bkij_1, by(id)
reg bibj_1_abs bkij_1
corr bibj_1_abs bkij_1
twoway scatter bibj_1_abs bkij_1 || lfit bibj_1_abs bkij_1 

* Table 7
*-------------------------------------------------------------------------------
use "Finance_Synch_DATA_JIE.dta", clear
set more off
keep if c<p
keep if year==1980 | year==1985 | year==1990 | year==1995  | year==2000 | year==2005 | year==2010
eststo clear
eststo: xtreg C  bankint1_L1 i.year, fe robust
eststo: xtreg CF bankint1_L1 i.year, fe robust
eststo: xtreg Ce bankint1_L1 i.year, fe robust
eststo: xtreg C  bankint2_L1 i.year, fe robust
eststo: xtreg CF bankint2_L1 i.year, fe robust
eststo: xtreg Ce bankint2_L1 i.year, fe robust
esttab, drop(19* 20* _c*)

* Table 8
*-------------------------------------------------------------------------------
use "Finance_Synch_DATA_JIE.dta", clear
set more off
keep if c<p
eststo clear
eststo: xtreg S  L.bankint1 L.lnspec i.year, fe robust
eststo: xtreg SF L.bankint1 L.lnspec i.year, fe robust
eststo: xtreg Se L.bankint1 L.lnspec i.year, fe robust
eststo: xtreg S  L.bankint2 L.lnspec i.year, fe robust
eststo: xtreg SF L.bankint2 L.lnspec i.year, fe robust
eststo: xtreg Se L.bankint2 L.lnspec i.year, fe robust
esttab, drop(19* 20* _c*)

* Table 9
*-------------------------------------------------------------------------------
use "Finance_Synch_DATA_JIE.dta", clear
set more off
keep if c<p
* S
eststo clear
forvalues i=1980(4)2002{
	preserve 
	keep if year>=`i'
	eststo: xtreg S L1.bankint1 i.year, fe robust
	restore
}
esttab, drop(19* 20* _c*)
* SF
eststo clear
forvalues i=1980(4)2002{
	preserve 
	keep if year>=`i'
	eststo: xtreg SF L1.bankint1 i.year, fe robust
	restore
}
esttab, drop(19* 20* _c*)
* Se
eststo clear
forvalues i=1980(4)2002{
	preserve 
	keep if year>=`i'
	eststo: xtreg Se L1.bankint1 i.year, fe robust
	restore
}
esttab, drop(19* 20* _c*)
