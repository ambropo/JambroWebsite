This Stata (.DTA) file provides the data for the replication of the results 
in  Cesa-Bianchi, Saleheen, and Imbs (2018), "Finance and Synchronization," 
forthcoming in the Journal of International Economics.

Note: the bilateral financial linkages data from the BIS are not publicly 
available. See footnote 10 in the text. We therefore removed from the data file 
"Finance_Synch_DATA_JIE.dta" all confidential data.

To be able to replicate the results is therefore necessary to obtain banks' 
cross-border claims and liabilities from the BIS, and construct the variables 
"bankint1" and "bankint2" (see the text for the definition of these variables).

These data are accessible by anyone affiliated with a participating central bank 
through DBS Online. The BIS also agrees to grant access to the data to anyone 
wishing to replicate the results upon physically arriving at the BIS and 
conducting analysis on the premises.