function CusumPlot(DATA,xdata,drop,param_names,row,col,figname)
% =======================================================================
% Plot the cusum statistics produced by cusum.m function
% =======================================================================
% CusumPlot(DATA,xdata,drop,param_names,row,col,figname)
% -----------------------------------------------------------------------
% INPUTS 
%	- DATA: cusum statistics produced by cusum.m function
%	- xdata: x axis
%	- drop: number of burnin observations
%	- param_names: parameters name as produced by Dynare
%	- row: number of columns for subplot
%	- col: number of columns for subplot
%	- figname: name of the saved .PDF and .PNG figure
% =========================================================================
% Ambrogio Cesa Bianchi, August 2011
% ambrogio.cesabianchi@gmail.com



%% Set the parameters for the plot
%==========================================================================

% number of parameters
[nobs, nvars] = size(DATA);

% font_size_title = 10;
font_size = 7;


% If not specified, compute optimal number of rows and columns
if ~exist('row','var') || ~exist('col','var')
    row = round(sqrt(nvars));
    col = ceil(sqrt(nvars));
end


%% Plot
%==========================================================================

nfigures = NumTotFigures(row,col,nvars);

% Plot
jj=1;
for nn=1:nfigures;
    for kk=1:row*col;
        
        if jj>nvars % to solve if I put more row*col 
            subplot(row,col,kk)
            xxx = [0:1:xdata]';
            plot(xxx,'LineStyle','none')
            axis off
        else
            
            % Plot prior, posterior, and mode
            subplot(row,col, kk);
            plot(xdata,xdata*0,'-k','LineWidth',0.2)        % x-axis
            hold on
            plot(xdata,-xdata./xdata*0.05,'g','LineWidth',1.5) % lower band
            hold on
            plot(xdata, xdata./xdata*0.05,'g','LineWidth',1.5) % upper band
            hold on
            plot(xdata,DATA(:,jj),'linewidth',0.8)      % cusum
            
            set(gca,'FontSize',font_size)
            title(char(param_names(jj)),'Interpreter','None')
            
%             ax=axis;
%             ax(2)=nobs;ax(3)=-0.25;ax(4)=0.25;
%             axis(ax)
            hold on
            plot(ones(nobs,1)*drop,linspace(min(DATA(:,jj)),max(DATA(:,jj)),nobs)',':r','linewidth',1.5)
            hold off
            
            % Set the x axis
            x_max = max(xdata);
            x_min = min(xdata);
            xlim([x_min x_max])
            
            % Set the y axis
            y_max = max(DATA(:,jj));
            y_min = min(DATA(:,jj));
            ylim([y_min y_max])
            
            jj=jj+1;
            
        end
    end


    % insert the super title
    suptitle(char('CUSUM - Markov Chain Convergence '));

    % Create the figname of the image to be saved...
    % ... if more than one image per country, start enumerating
    if nfigures > 1
        aux_figname = [figname  num2str(nn)];
    else
        aux_figname = figname;
    end

    % Save
    set(gcf, 'Color', 'w');
    export_fig(aux_figname,'-pdf','-png','-painters')
    clf('reset');
end

close all