function [XX,ndraws] = LoadChain(fname_,block)
% =======================================================================
% Load the chain simulations from the relevant directory (..\metropolis)
% =======================================================================
% [XX,ndraws] = LoadChain(fname_)
% -----------------------------------------------------------------------
% INPUT
%   fname_ : name of the mod file
%
% OPTIONAL INPUT
%   block : if multiple chain are chosen, number of the chain (default=1)
%
% OUTPUT
%   XX     : values of each MH ndrawsation
%   ndraws : total number of ndrawsations of the MH algorithm
% =========================================================================
% Ambrogio Cesa Bianchi, August 2011
% ambrogio.cesabianchi@gmail.com


%% Note -------------------------------------------------------------------
% In the mh files every column is a parameter and every row is a
% ndrawsation of the MH algorithm. The order of the parameters follow the
% order in the file fname_mode.mat
%--------------------------------------------------------------------------


if ~exist('block','var')
    block = 1;
end

% Add the metropolis hasting results folder
eval( ['addpath ' fname_ '\metropolis'] );

% Initialize some parameters to load the MH files
ndraws = 0;
XX     = [];
logpo  = [];
file   = 1;

% Initialize the file to read from
instr = [fname_ '_mh' int2str(file) '_blck' int2str(block) '.mat'];

disp(' ');
disp(['Loading simulation output for ' fname_ '...'])
disp(' ');

% This is to keep track of the loop below
multiple = 20;
checkpoint = multiple;

% Loop to read all mh files from the specified block
while exist(instr,'file')==2
    instr = [fname_ '_mh' int2str(file) '_blck' int2str(block) '.mat'];
	eval(['load ' instr ';']);
    block_ndraws = size(x2,1);
    ndraws = ndraws + block_ndraws;
    XX = [XX; x2];
    logpo = [logpo; logpo2];
    clear x2 logpo2;     
    file = file + 1;
    instr = [fname_ '_mh' int2str(file) '_blck' int2str(block) '.mat'];
    
    % Keep track of the loop
    if file == checkpoint
        disp(['Loop #: ' num2str(file)]);
        checkpoint = checkpoint + multiple;
    end
        
end

disp(' ');
disp([num2str(file-1) ' file(s) containing ' num2str(ndraws) ' draws']);
