function OUT = cusum(XX)
% =======================================================================
% Cusum statistics for evaluating convergence of parameter estimates.
% =======================================================================
% OUT = cusum(XX)
% -----------------------------------------------------------------------
% INPUTS 
%	- XX:   chain simulations loaded from Dynare output --from the relevant 
%           directory (..\metropolis)-- as done by LoadChain.m function
%
% OUTPUTS
%   - OUT:  cusum statistics
% =========================================================================
% Ambrogio Cesa Bianchi, August 2011
% ambrogio.cesabianchi@gmail.com


[r, c] = size(XX);
if r > c  % every parameter is a row
    XX    = XX';
    nvars = c;
    nobs  = r;
else
    nvars = r;
    nobs  = c;
end

XXmean = mean(XX,2);
XXstd  = max(std(XX,0,2),1e-6);

OUT    = zeros(nvars,nobs);
count = 1;
smpl  = 1;

while smpl < nobs
    if smpl==1
        S1 = XX(:,1);
    end
    OUT(:,smpl) = (1/smpl)*(S1-smpl*XXmean)./XXstd; % much faster !!!
    S1 = S1 + XX(:,smpl+1);
    if smpl==count*1000
        %disp(' ')
        %fprintf('CUSUM-test:  %3.0f draws\n',smpl)
        count=count+1;
    end
    smpl = smpl + 1;
end


