function PriorPostPlot(X,Xmode,bayestopt_,param_names,figname)
% =======================================================================
% Plot prior, posterior, and mode of the estimated model
% =======================================================================
% PriorPostPlot(X,Xmode,bayestopt_,param_names,figname)
% -----------------------------------------------------------------------
% INPUTS 
%	- X: cusum statistics produced by cusum.m function
%	- Xmode: x axis
%	- prior.bayestopt_: prior definitions as in Dynare output
%	- param_names: parameters name as produced by Dynare
%	- figname: name of the saved .PDF and .PNG figure
% =========================================================================
% Ambrogio Cesa Bianchi, August 2011
% ambrogio.cesabianchi@gmail.com


%% Parameters for the plot
%=========================

% font_size_title = 10;
font_size = 7;
grey  = [0.7,0.7,0.7];
green = [0.1 0.40 0.1];
bord  = [0.7 0.2 0.2];


%% Preliminaries
%============================
[nobs, nvars] = size(X);
Xmin        = 0.95*min(X);
Xmax        = 1.05*max(X);
knobs       = 201; % this is equivalent to the bin in the histogram
kX          = zeros(knobs,nvars); % x axis


%% Plot
%=======

% Determine how many figures are produced
row = 3;
col = 3;

nfigures = NumTotFigures(row,col,nvars);

% Plot
jj=1;
for nn=1:nfigures;
    for kk=1:row*col;
        
        if jj>nvars % to solve if I put more row*col 
            subplot(row,col,kk)
            xxx = [0:1:nobs]';
            plot(xxx,'LineStyle','none')
            axis off
        else
            
            % Use the function draw_prior_density from dynare
            [xpri,fpri,abscissa,dens,binf,bsup] = draw_prior_density(jj,bayestopt_);
            x = linspace(Xmin(jj),Xmax(jj),knobs)';
            kX(:,jj) = kernel(x,X(:,jj),0.4);

            % Plot prior, posterior, and mode
            subplot(row,col, kk);
            plot(xpri,fpri,'Color',grey,'LineWidth',1.5) % prior
            hold on
            plot(x,kX(:,jj),'Color',green,'LineWidth',2) % posterior
            hold on
            plot(ones(knobs,1)*Xmode(jj),linspace(0,max(kX(:,jj)),knobs)','Color',bord,'LineStyle','--','LineWidth',1.5) % mode
            
            set(gca,'FontSize',font_size)
            title(char(param_names(jj)),'Interpreter','None')
            
            % Set the x axis
            x_max = max(max(xpri),max(x));
            x_min = min(min(xpri),min(x));
            xlim([x_min x_max])
            
            axis('tight')
            

            jj=jj+1;
            
        end
    end

    % insert the super title
    suptitle(char('Marginal Prior & Posterior Kernel'));
    
    
    % if more than one image per country, start enumerating
    if nfigures > 1
        aux_figname = [figname num2str(nn)];
    else
        aux_figname = figname;
    end
    
    % Save
    set(gcf, 'Color', 'w');
    export_fig(aux_figname,'-pdf','-png','-painters')
    clf('reset');
end

close all

