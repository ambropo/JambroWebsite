function ScatterParameter(DATA,names,r,c,row,col,figname)
% =======================================================================
% Plot prior, posterior, and mode of the estimated model
% =======================================================================
% PriorPostPlot(X,Xmode,bayestopt_,param_names,figname)
% -----------------------------------------------------------------------
% INPUTS 
%	- DATA: cusum statistics produced by cusum.m function
%	- names: x axis
%	- r: selected parameters
%	- c: selected parameters
%	- row: number of columns for subplot
%	- col: number of columns for subplot
%	- figname: name of the saved .PDF and .PNG figure
% =========================================================================
% Ambrogio Cesa Bianchi, August 2011
% ambrogio.cesabianchi@gmail.com


% Preliminaries: define the dimension of the data vector DATA
[nobs, nvars]= size(DATA);

% If not specified, compute the bivariate distr for all parameters
if ~exist('r','var') || ~exist('c','var')
    r = [1:nvars]';
    c = [1:nvars]';
end

% Create the two matrices to plot...
YY = DATA(:,r'); 
ZZ = DATA(:,c');

%... and the names
YYnames = names(1,r');
ZZnames = names(1,c');

% New dimension 
[nobs, nvars]= size(YY);

% If too many charts ask if you wanna go!
if nvars>50
    disp(' ');
    disp(' Warning: you are trying to plot more than 50 charts');
    go_on = input(' Press enter to continue (or any other key to stop): ','s');
    if ~isempty(go_on)
        return
    end        
end

% If not specified, compute optimal number of rows and columns
if ~exist('row','var') || ~exist('col','var')
    row = round(sqrt(nvars));
    col = ceil(sqrt(nvars));
end

%% Select some draws to be plotted and compute the mode
%==========================================================================

% Compute the mode
YYmode   = mode(YY);
ZZmode   = mode(ZZ);

% Take a random sample from the chain
select = round(linspace(1,nobs,1000))';
YY = YY(select,:);
ZZ = ZZ(select,:);



%% Plot
%==========================================================================

% font_size_title = 10;
font_size = 7;
font_size_title = 10;
bord  = [0.7 0.2 0.2];

% Dimensions
[nobs, nvars] = size(YY);
x             = [0:1:nobs-1]';
nfigures      = NumTotFigures(row,col,nvars);

% Plot
jj=1;
for nn=1:nfigures;
    for kk=1:row*col;
        if jj>nvars % to solve if I put more row*col 
            subplot(row,col,kk)
            plot(x,'LineStyle','none')
            axis off
        else 
            subplot(row,col,kk);
            % scatter plot of parameters
            scatter(YY(:,jj),ZZ(:,jj),'.','LineWidth',3)
            hold on
            % compute the limits of the axes 
            h = gca;
            xbounds = xlim(h);
            ybounds = ylim(h);
            % plot the mode of parameter jj
            plot(ones(nobs,1)*YYmode(:,jj),linspace(ybounds(1),ybounds(2),nobs)','Color','green','LineWidth',1)
            hold on 
            % plot the mode of parameter in Y
            plot(linspace(xbounds(1),xbounds(2),nobs)',ones(nobs,1)*ZZmode(:,jj),'Color','green','LineWidth',1)
            % reset axis limits (if changed)
            xlim( [xbounds(1) xbounds(2)] )
            ylim( [ybounds(1) ybounds(2)] )
            % axes
%             xlabel(YYnames(jj))
%             ylabel(ZZnames(jj))
            set(gca,'FontSize',font_size)
            set(gca, 'Box','off')
            % title
            text_corr = num2str(corr(YY(:,jj),ZZ(:,jj)), '%1.2f');
            text_title = ['Corr(' char(YYnames(jj)) ',' char(ZZnames(jj)) ') = ' text_corr ];
            title(text_title,'FontSize',font_size_title,'Interpreter','None')
            
            jj=jj+1;
        end
    end

    % insert the super title
    suptitle('Bivariate Distributions of Selected Parameters')

    % Create the figname of the image to be saved...
    % ...if more than one image per country, start enumerating
    if nfigures > 1
        aux_figname = [figname  num2str(nn)];
    else
        aux_figname = figname;
    end

    % Save
    set(gcf, 'Color', 'w');
    export_fig(aux_figname,'-pdf','-png','-painters')
    clf('reset');
end

close all