function [param,hh,names] = LoadMode(fname_)
% =======================================================================
% Load the mode of the maximized log posterior
% =======================================================================
% [param,hh,names] = LoadMode(fname_)
% -----------------------------------------------------------------------
% INPUT
%   fname_ : name of the mod file
%
% OUTPUT
%   param  : values of the estimated parameters at the mode
%   hh     : Hessian at the mode
%   names  : names of the parameters
% =========================================================================
% Ambrogio Cesa Bianchi, August 2011
% ambrogio.cesabianchi@gmail.com


% Load posterior mode and saves it
tmp = load([fname_ '_mode']);

param = tmp.xparam1;
hh    = tmp.hh;
names = tmp.parameter_names;
