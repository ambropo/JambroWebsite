function SRout = SR(VAR,R,VARopt)
% =======================================================================
% Compute IRs, VDs, and HDs for a VAR model identified with sign
% restrictions, with optional narrative sign restrictions. When R is a
% plain sign-restriction matrix, the call is fully backward compatible.
% =======================================================================
% SRout = SR(VAR,R,VARopt)
% -----------------------------------------------------------------------
% INPUT
%   - VAR: structure, result of VARmodel function
%   - SIGN or R: sign and narrative restrictions. By convention, pass a
%       plain matrix as SIGN and a struct as R (see EXAMPLE). Either:
%       (a) SIGN — plain sign-restriction matrix (nvar x nshocks): +1
%           restricts positive, -1 restricts negative, 0 unrestricted;
%           narrative restrictions are skipped (fully backward compatible)
%       (b) R — struct with fields:
%           R.sign      - sign restriction matrix (nvar x nshocks) [matrix]
%           R.narr_sign - narrative sign restrictions: sign of structural
%               shock j at date t* must match the given sign. Fields
%               (each n x 1): .shock, .period, .sign (+1 or -1) [struct]
%           R.narr_dom  - dominant-shock restrictions: shock j must be
%               the dominant driver of variable i at date t*. Fields
%               (each n x 1): .shock, .period, .var [struct]
%           Both R.narr_sign and R.narr_dom are optional; omit either
%           field to skip that class of restrictions.
%           .period may be a numeric residual-sample index (integer) or a
%           date string (e.g. '1979m10', '1990q3', '2001') matched against
%           VARopt.dates. For multiple restrictions, use a numeric column
%           vector or a cell array of strings, respectively.
%   - VARopt: options of the VAR (see VARoption from VARmodel)
%             VARopt.dates must be set to a cell array of date strings
%             aligned with the rows of the data passed to VARmodel when
%             string-format periods are used in R.narr_sign or R.narr_dom.
% -----------------------------------------------------------------------
% OUTPUT
%   - SRout: structure with the following fields:
%       * accept_rate:  share of all rotation attempts that are accepted
%                       (pass sign and, if active, narrative restrictions);
%                       equals ndraws / ndraws_tried. Counts individual
%                       rotation draws inside SignRestrictions, so it
%                       correctly reflects how tight the sign restrictions
%                       are (not just whether SignRestrictions succeeded).
%       * ndraws_tried: total rotation draws attempted; always >= ndraws;
%                       larger when sign or narrative filtering is tight
% -----------------------------------------------------------------------
% NARRATIVE RESTRICTION TYPES
%   narr_sign — Sign of structural shock at date t* (ADRR Type 1):
%       R.narr_sign.sign(k) * e(t*,j) > 0, where e = inv(B)*resid
%   narr_dom  — Dominant shock for variable i at date t* (ADRR Type 2):
%       |B(i,j)*e(t*,j)| > sum_{k~=j} |B(i,k)*e(t*,k)|
% -----------------------------------------------------------------------
% EXAMPLE
%   - See GO_ADRR2018.m in "Replic/ADRR2018/"
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-19
% -----------------------------------------------------------------------

%% 1. Check inputs and parse R
% -----------------------------------------------------------------------
if ~exist('R','var')
    error('You have not provided sign restrictions (R)')
end
if ~exist('VARopt','var')
    error('You need to provide VAR options (VARopt from VARmodel)');
end

% R can be a plain matrix (backward compatible) or a struct with sign and
% narrative restriction fields
if isstruct(R)
    SIGN = R.sign;
    narr_sign_active = isfield(R,'narr_sign') && ~isempty(R.narr_sign);
    narr_dom_active  = isfield(R,'narr_dom')  && ~isempty(R.narr_dom);
else
    SIGN = R;
    narr_sign_active = false;
    narr_dom_active  = false;
end
narr_active = narr_sign_active || narr_dom_active;
if narr_sign_active; n_narr_sign = length(R.narr_sign.shock); end
if narr_dom_active;  n_narr_dom  = length(R.narr_dom.shock);  end

% Convert any string date periods to numeric residual-sample indices
if narr_sign_active
    R.narr_sign.period = resolve_period(R.narr_sign.period, VARopt, VAR.nlag);
end
if narr_dom_active
    R.narr_dom.period = resolve_period(R.narr_dom.period, VARopt, VAR.nlag);
end


%% 2. Retrieve parameters and preallocate variables
% -----------------------------------------------------------------------
nvar    = VAR.nvar;
nvar_ex = VAR.nvar_ex;
nsteps  = VARopt.nsteps;
ndraws  = VARopt.ndraws;
nobs    = VAR.nobs;
nlag    = VAR.nlag;
pctg    = VARopt.pctg;

IRall  = nan(nsteps,nvar,nvar,ndraws);
VDall  = nan(nsteps,nvar,nvar,ndraws);
HDall.shock  = zeros(nobs+nlag,nvar,nvar,ndraws);
HDall.init   = zeros(nobs+nlag,nvar,ndraws);
HDall.const  = zeros(nobs+nlag,nvar,ndraws);
HDall.trend  = zeros(nobs+nlag,nvar,ndraws);
HDall.trend2 = zeros(nobs+nlag,nvar,ndraws);
HDall.endo   = zeros(nobs+nlag,nvar,ndraws);
HDall.exo    = zeros(nobs+nlag,nvar,nvar_ex,ndraws);
Ball = nan(nvar,nvar,ndraws);


%% 3. Sign restriction routine with narrative filter
% -----------------------------------------------------------------------
% Draw orthonormal rotations satisfying SIGN. For each sign-valid draw,
% compute structural shocks and apply narrative restrictions as an
% additional acceptance filter before counting the draw.
jj = 0;   % accepted draws (passed sign and narrative restrictions)
tt = 0;   % total attempted draws
ww = 1;   % index for printing progress
narr_sign_pass = 0;  % sign-valid draws that entered the narrative filter

while jj < ndraws

    if tt > VARopt.sr_draw
        disp('------------------------------------------------------------')
        disp( 'Total number of draws for finding sign restrictions exceeded')
        disp( 'Change the restrictions or increase VARopt.sr_draw');
        disp('------------------------------------------------------------')
        error('See details above')
    end

    label = {['draw' num2str(jj)]};
    VAR_draw.(label{1}) = VAR;
    VARopt.ident = 'sign';

    % If selected, draw F and sigma from the posterior to include model
    % uncertainty in addition to identification uncertainty
    if VARopt.sr_mod == 1
        [sigma_draw, Ft_draw, F_draw, Fcomp_draw] = VARdrawpost(VAR);
        VAR_draw.(label{1}).Ft    = Ft_draw;
        VAR_draw.(label{1}).F     = F_draw;
        VAR_draw.(label{1}).Fcomp = Fcomp_draw;
        VAR_draw.(label{1}).sigma = sigma_draw;
    end

    % Draw a rotation satisfying the sign restrictions
    [B, n_rot] = SignRestrictions(SIGN, VAR_draw.(label{1}), VARopt);

    % Narrative restrictions: additional filter on sign-valid draws.
    % Compute structural shocks e = inv(B)*resid and check each narrative
    % constraint. A draw failing any constraint is discarded.
    if ~isempty(B) && narr_active
        narr_sign_pass = narr_sign_pass + 1;
        e = (B \ VAR_draw.(label{1}).resid')';   % nobs x nvar structural shocks

        % narr_sign: sign of structural shock j at date t* must match R.narr_sign.sign
        if narr_sign_active
            for kk = 1:n_narr_sign
                if R.narr_sign.sign(kk) * e(R.narr_sign.period(kk), R.narr_sign.shock(kk)) <= 0
                    B = []; break
                end
            end
        end

        % narr_dom: |contribution of shock j to variable i| must dominate all others
        if ~isempty(B) && narr_dom_active
            for kk = 1:n_narr_dom
                contrib  = B(R.narr_dom.var(kk), :) .* e(R.narr_dom.period(kk), :);
                shock_kk = R.narr_dom.shock(kk);
                if abs(contrib(shock_kk)) <= sum(abs(contrib)) - abs(contrib(shock_kk))
                    B = []; break
                end
            end
        end
    end

    if ~isempty(B)
        jj = jj+1; tt = tt+n_rot;
        Ball(:,:,jj) = B;
        VAR_draw.(label{1}).B = B;

        [aux_irf, VAR_draw.(label{1})] = VARir(VAR_draw.(label{1}),VARopt);
        IRall(:,:,:,jj)  = aux_irf;
        aux_fevd = VARvd(VAR_draw.(label{1}),VARopt);
        VDall(:,:,:,jj)  = aux_fevd;
        aux_hd = VARhd(VAR_draw.(label{1}),VARopt);
        HDall.shock(:,:,:,jj) = aux_hd.shock;
        HDall.init(:,:,jj)    = aux_hd.init;
        HDall.const(:,:,jj)   = aux_hd.const;
        HDall.trend(:,:,jj)   = aux_hd.trend;
        HDall.trend2(:,:,jj)  = aux_hd.trend2;
        HDall.endo(:,:,jj)    = aux_hd.endo;
        if nvar_ex > 0; HDall.exo(:,:,:,jj) = aux_hd.exo; end

        if jj == VARopt.mult * ww
            disp(['Rotation: ' num2str(jj) ' / ' num2str(ndraws)]);
            ww = ww + 1;
        end
    else
        tt = tt + n_rot;
    end

end
disp('-- Done!');
disp(' ');


%% 4. Store results
% -----------------------------------------------------------------------
SRout.IRall = IRall;
SRout.VDall = VDall;
SRout.Ball  = Ball;
SRout.HDall = HDall;

% Acceptance rate and total draws attempted
SRout.accept_rate  = jj / tt;   % share of all attempted draws accepted
SRout.ndraws_tried = tt;        % total rotation draws attempted

% Median B matrix across accepted draws
SRout.Bmed = median(Ball,3);

% Select the accepted draw whose B matrix is closest to the median (Frobenius distance)
aux = sum(sum((Ball - SRout.Bmed).^2,1),2);
sel = find(aux == min(aux));
sel = sel(1);
SRout.B = Ball(:,:,sel);

% Percentile bands for IRs and VDs
pctg_inf = (100-pctg)/2;
pctg_sup = 100 - (100-pctg)/2;
SRout.IRmed = median(IRall,4);
aux = prctile(IRall,[pctg_inf pctg_sup],4);
SRout.IRinf = aux(:,:,:,1);
SRout.IRsup = aux(:,:,:,2);
SRout.VDmed = median(VDall,4);
aux = prctile(VDall,[pctg_inf pctg_sup],4);
SRout.VDinf = aux(:,:,:,1);
SRout.VDsup = aux(:,:,:,2);

% Point-estimate IR, VD, HD from the draw closest to the median B.
% Ball(:,:,n) is stored under label draw(n-1) because label is set from
% the pre-increment value of jj, so the correct field name is sel-1.
VARopt.ident = 'sign';
VAR = VAR_draw.(['draw' num2str(sel-1)]);
SRout.IR = VARir(VAR,VARopt);
SRout.VD = VARvd(VAR,VARopt);
SRout.HD = VARhd(VAR,VARopt);


%% LOCAL FUNCTIONS
% -----------------------------------------------------------------------
function idx = resolve_period(period, VARopt, nlag)
% Convert a period specification to a numeric residual-sample index.
% Numeric input is returned unchanged. String or cell-of-strings input is
% matched against VARopt.dates and converted via pos - nlag. VARopt.dates
% must be aligned with the rows of the data passed to VARmodel (i.e.
% trimmed to the common sample before calling SR).
if isnumeric(period)
    idx = period;
    return
end

% String input: require VARopt.dates
if ~isfield(VARopt,'dates') || isempty(VARopt.dates)
    error('SR:noDates', ['String period requires VARopt.dates ' ...
        '(cell array of date strings aligned with the data passed to VARmodel).'])
end

% Wrap scalar char as 1-element cell for uniform handling
if ischar(period)
    period = {period};
end

idx = zeros(size(period));
for kk = 1:numel(period)
    pos = find(strcmp(VARopt.dates, period{kk}));
    if isempty(pos)
        error('SR:dateNotFound', ...
            'Date ''%s'' not found in VARopt.dates.', period{kk})
    end
    idx(kk) = pos - nlag;
    if idx(kk) <= 0
        error('SR:dateTooEarly', ...
            ['Date ''%s'' falls within the lag window ' ...
            '(residual-sample index = %d <= 0).'], period{kk}, idx(kk))
    end
end
