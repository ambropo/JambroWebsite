function [INF,SUP,MED,BAR] = VARhdband(VAR,VARopt)
% =======================================================================
% Compute bootstrap confidence bands for historical decompositions
% computed with VARhd
% =======================================================================
% [INF,SUP,MED,BAR] = VARhdband(VAR,VARopt)
% -----------------------------------------------------------------------
% INPUT
%   - VAR: structure, result of VARmodel.m
%   - VARopt: options of the VAR (result of VARmodel.m)
% -----------------------------------------------------------------------
% OUTPUT
%   - INF(:,:,:): lower confidence band (nobs+nlag x N variables x N shocks)
%   - SUP(:,:,:): upper confidence band (nobs+nlag x N variables x N shocks)
%   - MED(:,:,:): median HD.shock (nobs+nlag x N variables x N shocks)
%   - BAR(:,:,:): mean HD.shock (nobs+nlag x N variables x N shocks)
% -----------------------------------------------------------------------
% EXAMPLE
%   - See VARToolbox_Primer.m in "../Primer/"
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: May 2026. Updated: 2026-05-21
% -----------------------------------------------------------------------


%% 1. Check inputs
% -----------------------------------------------------------------------
if ~exist('VAR','var')
    error('You need to provide VAR structure, result of VARmodel');
end
if ~exist('VARopt','var')
    error('You need to provide VAR options (VARopt from VARmodel)');
end
% IV identification is not supported by VARhd
if strcmp(VARopt.ident,'iv')
    error('VARhdband: IV identification is not supported for historical decompositions.');
end


%% 2. Retrieve and initialize variables
% -----------------------------------------------------------------------
ndraws  = VARopt.ndraws;
pctg    = VARopt.pctg;
method  = VARopt.method;

Ft      = VAR.Ft;  % \Phi' in the notes (rows are coeffs, columns are eqs)
nvar    = VAR.nvar;
nvar_ex = VAR.nvar_ex;
nlag    = VAR.nlag;
nlag_ex = VAR.nlag_ex;
const   = VAR.const;
nobs    = VAR.nobs;
resid   = VAR.resid;
ENDO    = VAR.ENDO;
EXOG    = VAR.EXOG;

% Preallocate output confidence band arrays (nobs+nlag x nvar x nvar)
INF = zeros(nobs+nlag,nvar,nvar);
SUP = zeros(nobs+nlag,nvar,nvar);
MED = zeros(nobs+nlag,nvar,nvar);
BAR = zeros(nobs+nlag,nvar,nvar);


%% 3. Preallocate artificial data matrix
% -----------------------------------------------------------------------
y_artificial = zeros(nobs+nlag,nvar);


%% 4. Bootstrap loop
% -----------------------------------------------------------------------
tt = 1; % number of accepted draws
ww = 1; % index for printing on screen
while tt<=ndraws

    % Display progress
    if tt==VARopt.mult*ww
        disp(['Loop ' num2str(tt) ' / ' num2str(ndraws) ' draws'])
        ww=ww+1;
    end

    % Step 1: choose the method and generate the residuals
    if strcmp(method,'bs')
        % Sampling with replacement: draw rows of residual matrix randomly
        u = resid(ceil(size(resid,1)*rand(nobs,1)),:);
    elseif strcmp(method,'wild')
        % Wild bootstrap based on Rademacher distribution
        rr = 1-2*(rand(nobs,1)>0.5);
        u = resid.*(rr*ones(1,nvar));
    else
        error(['The method ' method ' is not available'])
    end

    % Step 2: generate the artificial data
    % Step 2.1: initialize first nlag observations with real data
    LAG=[];
    for jj = 1:nlag
        y_artificial(jj,:) = ENDO(jj,:);
        LAG = [y_artificial(jj,:) LAG]; %#ok<AGROW> intentional: prepend each lag block
    end
    % Build LAGplus (lag matrix augmented with deterministics)
    T = (1:nobs)';
    if const==0
        LAGplus = LAG;
    elseif const==1
        LAGplus = [1 LAG];
    elseif const==2
        LAGplus = [1 T(1) LAG];
    elseif const==3
        LAGplus = [1 T(1) T(1).^2 LAG];
    end
    if nvar_ex~=0
        LAGplus = [LAGplus VAR.X_EX(jj-nlag+1,:)]; %#ok<AGROW> exogenous cols appended after deterministics
    end

    % Step 2.2: simulate observations nlag+1 to nobs recursively
    for jj = nlag+1:nobs+nlag
        for mm = 1:nvar
            y_artificial(jj,mm) = LAGplus * Ft(1:end,mm) + u(jj-nlag,mm);
        end
        % Update the lag matrix for the next iteration
        if jj<nobs+nlag
            LAG = [y_artificial(jj,:) LAG(1,1:(nlag-1)*nvar)];
            if const==0
                LAGplus = LAG;
            elseif const==1
                LAGplus = [1 LAG];
            elseif const==2
                LAGplus = [1 T(jj-nlag+1) LAG];
            elseif const==3
                LAGplus = [1 T(jj-nlag+1) T(jj-nlag+1).^2 LAG];
            end
            if nvar_ex~=0
                LAGplus = [LAGplus VAR.X_EX(jj-nlag+1,:)]; %#ok<AGROW> exogenous cols appended after deterministics
            end
        end
    end

    % Step 3: estimate VAR on artificial data
    if nvar_ex~=0
        [VAR_draw, ~] = VARmodel(y_artificial,nlag,const,EXOG,nlag_ex);
    else
        [VAR_draw, ~] = VARmodel(y_artificial,nlag,const);
    end

    % Step 4: compute HD for this draw and store if stationary
    [HD_draw, VAR_draw] = VARhd(VAR_draw,VARopt);
    if VAR_draw.maxEig<.9999
        HD_store(:,:,:,tt) = HD_draw.shock; %#ok<AGROW> grows along 4th dim; pre-alloc avoided as ndraws accepted draws unknown a priori
        tt=tt+1;
    end
end
disp('-- Done!');
disp(' ');

%% 5. Compute the error bands
% -----------------------------------------------------------------------
pctg_inf = (100-pctg)/2;
pctg_sup = 100 - (100-pctg)/2;
INF(:,:,:) = prctile(HD_store(:,:,:,:),pctg_inf,4);
SUP(:,:,:) = prctile(HD_store(:,:,:,:),pctg_sup,4);
MED(:,:,:) = prctile(HD_store(:,:,:,:),50,4);
BAR(:,:,:) = mean(HD_store(:,:,:,:),4);
