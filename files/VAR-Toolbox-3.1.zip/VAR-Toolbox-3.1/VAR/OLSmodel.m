function OLS = OLSmodel(y,x,const,nlag_nw)
% =======================================================================
% OLS regression
% =======================================================================
% OLS = OLSmodel(y,x,const,nlag_nw)
% -----------------------------------------------------------------------
% INPUT
%	- y: dependent variable vector    (nobs x 1)
%	- x: independent variables matrix (nobs x nvar)
% -----------------------------------------------------------------------
% OPTIONAL INPUT
%	- const: 0 no constant; 1 constant; 2 constant and trend; 3 constant
%        and trend^2 [dflt = 1]
%   - nlag_nw: Newey-West bandwidth (number of lags). When omitted, the
%        automatic bandwidth floor(4*(nobs/100)^(2/9)) is used. Pass 0
%        to obtain the HC0 (Huber-White) sandwich estimator. [dflt = auto]
% -----------------------------------------------------------------------
% OUTPUT
%	- OLS: structure including OLS estimation results
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-19
% -----------------------------------------------------------------------

%% 1. Check inputs
% -----------------------------------------------------------------------
if isempty(x)
    [nobs, ~] = size(y);
    nvar = 0;
else
    [nobs, nvar] = size(x);
    [nobs2, ~] = size(y);
    if (nobs ~= nobs2); error('x and y must have same # obs'); end
end

% Check if there are constant, trend, both, or none
if ~exist('const','var')
    const = 1;
end

% Add constant or trend if needed
if const==1
    x = [ones(nobs,1) x];
    nvar = nvar+1;
elseif const==2
    trend = 1:nobs;
    x = [ones(nobs,1) trend' x];
    nvar = nvar+2;
elseif const==3
    trend = 1:nobs;
    x = [ones(nobs,1) trend'.^2 x];
    nvar = nvar+2;
end

OLS.meth = 'ols';
OLS.y = y;
OLS.x = x;
OLS.nobs = nobs;
OLS.nvar = nvar;

%% 2. OLS estimation
% -----------------------------------------------------------------------
% Use QR decomposition for numerical stability when nobs < 10000
if nobs < 10000
    [~, r] = qr(x,0);
    xpxi = (r'*r)\eye(nvar);  % (X'X)^{-1}
else
    xpxi = (x'*x)\eye(nvar);
end

% Coefficient estimates
OLS.beta = xpxi*(x'*y);

% Predicted values and residuals
OLS.yhat  = x*OLS.beta;
OLS.resid = y - OLS.yhat;

% Variance of the residuals (dof-adjusted)
sigu = OLS.resid'*OLS.resid;
OLS.sige    = sigu/(nobs-nvar);
OLS.sigbeta = OLS.sige*xpxi;  % covariance matrix of beta


%% 3. Standard errors (OLS, Huber-White, Newey-West)
% -----------------------------------------------------------------------
% OLS standard errors, t-stats, confidence intervals
tmp = (OLS.sige)*(diag(xpxi));
sigb = sqrt(tmp);
OLS.bstd  = sigb;
tcrit = -tdis_inv(.025,nobs);
OLS.bint  = [OLS.beta-tcrit.*sigb, OLS.beta+tcrit.*sigb];
OLS.tstat = OLS.beta./(sqrt(tmp));
OLS.tprob = tdis_prb(OLS.tstat,nobs);

% Huber-White heteroskedasticity-robust standard errors (nlag = 0: no
% serial-correlation correction, heteroskedasticity only)
nlag = 0;
emat = repmat(OLS.resid', nvar, 1); % preallocate: stack nvar copies of e'
hhat = emat.*x';
G = zeros(nvar,nvar); w = zeros(2*nlag+1,1);
a = 0;
while a ~= nlag+1
    ga = zeros(nvar,nvar);
    w(nlag+1+a,1) = (nlag+1-a)/(nlag+1);
    za = hhat(:,(a+1):nobs)*hhat(:,1:nobs-a)';
    if a==0
        ga = ga + za;
    else
        ga = ga + za + za';
    end
    G = G + w(nlag+1+a,1)*ga;
    a = a+1;
end
V = xpxi*G*xpxi;
OLS.bstd_HW = sqrt(diag(V));

% Newey-West heteroskedasticity- and autocorrelation-consistent std errors
% Use caller-supplied bandwidth when provided; otherwise fall back to the
% automatic Newey-West bandwidth floor(4*(nobs/100)^(2/9))
if ~exist('nlag_nw','var')
    nlag = floor(4*((nobs/100)^(2/9))); % automatic bandwidth
else
    nlag = nlag_nw;                      % caller-specified bandwidth
end
emat = repmat(OLS.resid', nvar, 1); % preallocate: stack nvar copies of e'
hhat = emat.*x';
G = zeros(nvar,nvar); w = zeros(2*nlag+1,1);
a = 0;
while a ~= nlag+1
    ga = zeros(nvar,nvar);
    w(nlag+1+a,1) = (nlag+1-a)/(nlag+1);
    za = hhat(:,(a+1):nobs)*hhat(:,1:nobs-a)';
    if a==0
        ga = ga + za;
    else
        ga = ga + za + za';
    end
    G = G + w(nlag+1+a,1)*ga;
    a = a+1;
end
V = xpxi*G*xpxi;
OLS.bstd_NW = sqrt(diag(V));


%% 4. Goodness of fit
% -----------------------------------------------------------------------
% R2
ym = y - mean(y);
rsqr1 = sigu;
rsqr2 = ym'*ym;
OLS.rsqr = 1.0 - rsqr1/rsqr2; % r-squared
rsqr1 = rsqr1/(nobs-nvar);
rsqr2 = rsqr2/(nobs-1.0);
if rsqr2 ~= 0
    OLS.rbar = 1 - (rsqr1/rsqr2); % rbar-squared
else
    OLS.rbar = OLS.rsqr;
end

% Durbin-Watson
ediff = OLS.resid(2:nobs) - OLS.resid(1:nobs-1);
OLS.dw = (ediff'*ediff)/sigu; % durbin-watson
OLS.const = const;

% F-test
if const>0
    fx = x(:,1); 
    fxpxi = (fx'*fx)\eye(1);
    fbeta = fxpxi*(fx'*y);
    fyhat = fx*fbeta;
    fresid = y - fyhat;
    fsigu = fresid'*fresid;
    fym = y - mean(y);
    frsqr1 = fsigu;
    frsqr2 = fym'*fym;
    frsqr = 1.0 - frsqr1/frsqr2; % r-squared
    OLS.F = ((frsqr-OLS.rsqr)/(1-nvar)) / ((1-OLS.rsqr)/(nobs-nvar));
end
