function LPopt = LPoption
% =======================================================================
% Set default options for LP (local projection) estimation
% =======================================================================
% LPopt = LPoption
% -----------------------------------------------------------------------
% OUTPUT
%   - LPopt: structure of default LP options. Fields listed below with
%       defaults; see LPmodel and LPirplot for usage.
% -----------------------------------------------------------------------
% EXAMPLE
%   - See VARToolbox_Primer.m in "../Primer/"
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: November 2024. Updated: 2026-05-25
% -----------------------------------------------------------------------

%% 1. ESTIMATION SETTINGS
% -----------------------------------------------------------------------
% Projection horizon and confidence level
LPopt.nsteps = 40; % number of steps for computation of IRFs
LPopt.pctg   = 95; % confidence level for bands (percent)

% Optional regressors
LPopt.EXOG = []; % matrix of exogenous variables
LPopt.LAGS = []; % matrix of control variables to enter with lags

% Lag and deterministic specification
LPopt.nlag  = 4; % number of lags of LAGS to include
LPopt.const = 1; % deterministic component (0=none,1=const,2=const+trend)

% Shock normalisation
LPopt.impact = 0; % 0 = one-std-dev shock; 1 = unit shock

% Long-difference LHS: when 1, the dependent variable at horizon h is
% ENDO_{t+h} - ENDO_{t-1} instead of the level ENDO_{t+h}
LPopt.longdiff = 0;

% Instrumental variable: when non-empty, contains the endogenous treatment
% variable D (e.g. the policy rate) to be instrumented by S (the shock
% passed to LPmodel). When empty, OLS is used (backward compatible).
LPopt.IV = [];

% Number of lags of the instrument to add as additional instruments when
% LPopt.IV is non-empty. 0 = just-identified IV (default). n > 0 adds
% lags 1,...,n of S (after FWL) as extra instruments for 2SLS (matches
% instruments(rz l(1/n).rz) in Stata ivreghdfe). Requires nlag_iv <= nlag.
LPopt.nlag_iv = 0;


%% 2. DISPLAY OPTIONS
% -----------------------------------------------------------------------
% Variable and shock labels
LPopt.vnames     = {};    % cell array of variable names, one per column of IR
LPopt.sname      = '';    % name of the shock (single string)

% Figure export
LPopt.figname    = '';      % prefix for the exported figure filename
LPopt.FigSize    = [26,24]; % figure window size [width, height] in cm
LPopt.quality    = 2;       % export quality: 2=high (exportgraphics), 1=high, 0=pdf
LPopt.suptitle   = 0;       % 1 = show a super-title above all panels

% Panel appearance
LPopt.latex      = 0;    % 1 = use LaTeX interpreter for figure text
LPopt.grid       = 1;    % 1 = show gridlines in plots
LPopt.marker     = 'o';  % marker style for the IR line ('o', 'none', etc.)
LPopt.subplot    = [];   % subplot grid [rows cols]; empty = auto from sqrt(nvars)
LPopt.shorttitle = 0;    % 1 = show only variable name as panel title; 0 = 'var to shock'
LPopt.color      = [];   % band and line color (RGB triplet); empty = pantone('Blue')
LPopt.linestyle  = '-';  % IR line style ('-', '--', ':', '-.')
LPopt.hstart     = 1;    % first horizon label on x-axis (0 or 1)
LPopt.xlim       = [];   % x-axis limits [lo hi]; empty = auto from hstart:H
LPopt.ylim       = [];   % y-axis limits [lo hi]; empty = auto
LPopt.xtick      = [];   % x-tick positions; empty = auto
LPopt.xlabel     = '';   % x-axis label (applied to each panel; empty = none)
LPopt.ylabel     = '';   % y-axis label (applied to each panel; empty = none)
LPopt.boxoff     = 0;    % 1 = box off on each panel
LPopt.visible    = 1;    % 1 = show figure window, 0 = suppress display (save only)
