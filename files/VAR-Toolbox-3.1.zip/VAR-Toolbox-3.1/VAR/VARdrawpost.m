function [sigma_draw, Ft_draw, F_draw, Fcomp_draw] = VARdrawpost(VAR)
% =======================================================================
% Draw from the posterior distribution of a VAR model
% =======================================================================
% [sigma_draw, Ft_draw, F_draw, Fcomp_draw] = VARdrawpost(VAR)
% -----------------------------------------------------------------------
% INPUT
%   - VAR: structure, result of VARmodel function
% -----------------------------------------------------------------------
% OUTPUT
%   - sigma_draw: draw from the posterior of the VCV matrix of VAR residuals
%   - Ft_draw: draw from the posterior of Ft (coefficient matrix, ncoeff x nvar)
%   - F_draw: transpose of Ft_draw (nvar x ncoeff)
%   - Fcomp_draw: companion form matrix of the draw
% -----------------------------------------------------------------------
% EXAMPLE
%   - See VARToolbox_Primer.m in "../Primer/"
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-19
% -----------------------------------------------------------------------


%% 1. Get relevant parameters from VAR structure
% -----------------------------------------------------------------------
nobs  = VAR.nobs;
X     = VAR.X;
const = VAR.const;
nvar  = VAR.nvar;
nlag  = VAR.nlag;
% Number of rows in the coefficient matrix (regressors per equation)
k = size(X, 2);


%% 2. OLS estimates
% -----------------------------------------------------------------------
Ft_hat        = VAR.Ft;
sigma_hat     = VAR.sigma;
inv_sigma_hat = inv(sigma_hat);


%% 3. Draw the VCV matrix (sigma)
% -----------------------------------------------------------------------
% Use a Wishart draw on the precision matrix and invert to get sigma
inv_sigma_draw = wishrnd(inv_sigma_hat/nobs, nobs);
sigma_draw     = inv(inv_sigma_draw);

%% 4. Draw the coefficient matrix (Ft)
% -----------------------------------------------------------------------
% Compute the Kronecker-structured VCV of the vectorised coefficient matrix
aux1 = (X'*X)\eye(size(X,2));
aux2 = kron(sigma_draw, aux1);
aux2 = (aux2 + aux2')/2; % force symmetry to guard against numerical error
Fthat_vec = Ft_hat(:);
Ftdraw    = mvnrnd(Fthat_vec, aux2);
Ft_draw   = reshape(Ftdraw, k, nvar);
F_draw    = Ft_draw';
Fcomp_draw = [F_draw(:,1+const:nvar*nlag+const); eye(nvar*(nlag-1)) zeros(nvar*(nlag-1),nvar)];

