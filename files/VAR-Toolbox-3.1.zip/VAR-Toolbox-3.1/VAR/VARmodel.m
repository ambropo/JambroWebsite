function [VAR, VARopt] = VARmodel(ENDO,nlag,const,EXOG,nlag_ex)
% =======================================================================
% Perform vector autoregressive (VAR) estimation with OLS
% =======================================================================
% [VAR, VARopt] = VARmodel(ENDO,nlag,const,EXOG,nlag_ex)
% -----------------------------------------------------------------------
% INPUT
%	- ENDO: an (nobs x nvar) matrix of y-vectors
%	- nlag: lag length
% -----------------------------------------------------------------------
% OPTIONAL INPUT
%	- const: 0 no constant; 1 constant; 2 constant and trend; 3 constant
%       and trend^2 [dflt = 0]
%	- EXOG: optional matrix of variables (nobs x nvar_ex)
%	- nlag_ex: number of lags for exogenous variables [dflt = 0]
% -----------------------------------------------------------------------
% OUTPUT
%   - VAR: structure including VAR estimation results
%   - VARopt: structure including VAR options (see VARoption)
% -----------------------------------------------------------------------
% EXAMPLE
%   - See VARToolbox_Primer.m in "../Primer/"
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-19
% -----------------------------------------------------------------------


%% 1. Check inputs
% -----------------------------------------------------------------------
[nobs, nvar] = size(ENDO);

% Create VARopt and update it
VARopt = VARoption;
VAR.ENDO = ENDO;
VAR.nlag = nlag;

% Check if there are constant, trend, both, or none
if ~exist('const','var')
    const = 1;
end
VAR.const = const;

% Check if there are exogenous variables
if exist('EXOG','var')
    [nobs2, nvar_ex] = size(EXOG);
    % Check that ENDO and EXOG are conformable
    if (nobs2 ~= nobs)
        error('var: nobs in EXOG-matrix not the same as y-matrix');
    end
    clear nobs2
    % Check if there is lag order of EXOG, otherwise set it to 0
    if ~exist('nlag_ex','var')
        nlag_ex = 0;
    end
    VAR.EXOG = EXOG;
else
    nvar_ex = 0;
    nlag_ex = 0;
    VAR.EXOG = [];
end


%% 2. Save parameters and create data matrices
% -----------------------------------------------------------------------
% Effective sample size after accounting for lags of endogenous and exogenous
nobse         = nobs - max(nlag,nlag_ex);
VAR.nobs      = nobse;
VAR.nvar      = nvar;
VAR.nvar_ex   = nvar_ex;
VAR.nlag      = nlag;
VAR.nlag_ex   = nlag_ex;
ncoeff        = nvar*nlag;
VAR.ncoeff    = ncoeff;
ncoeff_ex     = nvar_ex*(nlag_ex+1);
ntotcoeff     = ncoeff + ncoeff_ex + const;
VAR.ntotcoeff = ntotcoeff;
VAR.const     = const;

% Create independent vector and lagged dependent matrix
[Y, X] = VARmakexy(ENDO,nlag,const);

% Create (lagged) exogenous matrix and align sample with endogenous
if nvar_ex>0
    X_EX  = VARmakelags(EXOG,nlag_ex);
    if nlag == nlag_ex
        X = [X X_EX];
    elseif nlag > nlag_ex
        diff = nlag - nlag_ex;
        X_EX = X_EX(diff+1:end,:);
        X = [X X_EX];
    elseif nlag < nlag_ex
        diff = nlag_ex - nlag;
        Y = Y(diff+1:end,:);
        X = [X(diff+1:end,:) X_EX];
    end
end


%% 3. OLS estimation equation by equation
% -----------------------------------------------------------------------
% Each equation is estimated separately; results are collected in VAR.eqJ
for j=1:nvar
    Yvec = Y(:,j);
    OLSout = OLSmodel(Yvec,X,0);
    aux = ['eq' num2str(j)];
    eval( ['VAR.' aux '.beta  = OLSout.beta;'] );  % bhats
    eval( ['VAR.' aux '.tstat = OLSout.tstat;'] ); % t-stats
    eval( ['VAR.' aux '.bstd  = OLSout.bstd;'] );  % beta std error
    % compute t-probs
    tstat = OLSout.tstat;
    tout = tdis_prb(tstat,nobse-ncoeff);
    eval( ['VAR.' aux '.tprob = tout;'] );        % t-probs
    eval( ['VAR.' aux '.resid = OLSout.resid;'] );% resids
    eval( ['VAR.' aux '.yhat  = OLSout.yhat;'] ); % yhats
    eval( ['VAR.' aux '.y     = Yvec;'] );        % actual y
    eval( ['VAR.' aux '.rsqr  = OLSout.rsqr;'] ); % r-squared
    eval( ['VAR.' aux '.rbar  = OLSout.rbar;'] ); % r-adjusted
    eval( ['VAR.' aux '.sige  = OLSout.sige;'] ); % standard error
    eval( ['VAR.' aux '.dw    = OLSout.dw;'] );   % DW
end


%% 4. Compute the matrix of coefficients and VCV
% -----------------------------------------------------------------------
% Stack OLS estimates: Ft is the (ncoeff x nvar) coefficient matrix
Ft = (X'*X)\(X'*Y);
VAR.Ft = Ft;
F = Ft';
VAR.F = Ft';
% Degrees-of-freedom adjusted VCV (divides by nobs - ntotcoeff per equation)
SIGMA = (1/(nobse-ntotcoeff))*(Y-X*Ft)'*(Y-X*Ft);
VAR.sigma = SIGMA;
VAR.resid = Y - X*Ft;
VAR.X = X;
VAR.Y = Y;
if nvar_ex > 0
    VAR.X_EX = X_EX;
end


%% 5. Companion matrix of F and max eigenvalue
% -----------------------------------------------------------------------
% Build the nvar*nlag companion form to assess stationarity
Fcomp = [F(:,1+const:nvar*nlag+const); eye(nvar*(nlag-1)) zeros(nvar*(nlag-1),nvar)];
VAR.Fcomp = Fcomp;
VAR.maxEig = max(abs(eig(Fcomp)));


%% 6. Initialize other results
% -----------------------------------------------------------------------
% Fields populated downstream by VARir, VARvd, VARhd, or the user
VAR.B   = [];   % structural impact matrix (need identification: see VARir/VARvd/VARhd)
VAR.Biv = [];   % first columns of structural impact matrix (need "iv" identification: see VARir/VARvd/VARhd)
VAR.PSI = [];   % Wold multipliers (computed only with VARir/VARvd/VARhd)
VAR.Fp  = [];   % Recursive F by lag (useful to compute MA representation)
VAR.IV  = [];   % External instruments for identification
