function [AIC, BIC, logL] = VARlag(ENDO,maxlag,const,EXOG,lag_ex)
% =======================================================================
% Determine VAR lag length with Akaike (AIC) and Bayesian Information
% Criterion (BIC).
% =======================================================================
% [AIC, BIC, logL] = VARlag(ENDO,maxlag,const,EXOG,lag_ex)
% -----------------------------------------------------------------------
% INPUT
%   - ENDO: an (nobs x nvar) matrix of endogenous variables.
%	- maxlag: the maximum lag length over which information
%       criteria (AIC and BIC) are computed
% -----------------------------------------------------------------------
% OPTIONAL INPUT
%   - const: 0 no constant; 1 constant ; 2 constant and trend;
%           3 constant and trend^2; [dflt = 1]
%	- EXOG: optional matrix of variables (nobs x nvar_ex)
%   - lag_ex: number of lags for exogenous variables (dflt = 0)
% -----------------------------------------------------------------------
% OUTPUT
%	- AIC: preferred lag length according to AIC
%   - BIC: preferred lag length according to BIC
%   - logL: vector [maxlag x 1] of loglikelihood
% -----------------------------------------------------------------------
% EXAMPLE
%   x = [1 2; 3 4; 5 6; 7 8; 9 10];
%   [AIC, BIC, logL] = VARlag([1 2; 3 4; 5 6; 7 8; 9 10], 2)
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-19
% -----------------------------------------------------------------------


%% 1. Check inputs
% -----------------------------------------------------------------------
[nobs, ~] = size(ENDO);

% Check if there are constant, trend, both, or none
if ~exist('const','var')
    const = 1;
end

% Check if there are exogenous variables
if exist('EXOG','var')
    [nobs2, num_ex] = size(EXOG);
    % Check that ENDO and EXOG are conformable
    if (nobs2 ~= nobs)
        error('var: nobs in EXOG-matrix not the same as y-matrix');
    end
    clear nobs2
else
    num_ex = 0;
end

% Check if there is lag order of EXOG, otherwise set it to 0
if ~exist('lag_ex','var')
    lag_ex = 0;
end

% Number of exogenous variables per equation
nvar_ex = num_ex*(lag_ex+1);

%% 2. Compute log likelihood and information criteria
% -----------------------------------------------------------------------
% For each candidate lag length, estimate the VAR on a common sample
% (starting at maxlag+1) and compute AIC and BIC.
logL = zeros(maxlag,1);
AIC  = zeros(maxlag,1);
BIC  = zeros(maxlag,1);
for i=1:maxlag
    % Estimate VAR with lag length i on a sample aligned to the longest lag
    X = ENDO(maxlag+1-i:end,:);
    aux = VARmodel(X,i,const);
    if nvar_ex>0
        Y = EXOG(maxlag+1-i:end,:);
        aux = VARmodel(X,i,const,Y,lag_ex);
    end

    % Extract key quantities from the VAR output
    NOBSadj   = aux.nobs;     % observations used in estimation
    NOBS      = aux.nobs + i; % total observations including initial lags
    NVAR      = aux.nvar;
    NTOTCOEFF = aux.ntotcoeff;
    RES       = aux.resid;

    % VCV of the residuals (plain MLE denominator for likelihood comparison)
    SIGMA = (1/NOBSadj) * (RES)' * (RES);

    % Log-likelihood under normality
    logL(i) = -(NOBS/2) * (NVAR*(1+log(2*pi)) + log(det(SIGMA)));

    % AIC: -2*logL/T + 2*k/T, where k = NVAR*NTOTCOEFF total parameters
    AIC(i) = -2*(logL(i)/NOBS) + 2*(NVAR*NTOTCOEFF)/NOBS;

    % BIC: -2*logL/T + k*log(T)/T (penalises more heavily than AIC)
    BIC(i) = -2*(logL(i)/NOBS) + (NVAR*NTOTCOEFF)*log(NOBS)/NOBS;
end

% Return the lag length that minimises each criterion
AIC = find(AIC==min(AIC));
BIC = find(BIC==min(BIC));
