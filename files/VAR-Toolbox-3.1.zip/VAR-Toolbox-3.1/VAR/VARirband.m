function [INF,SUP,MED,BAR] = VARirband(VAR,VARopt)
% =======================================================================
% Calculate confidence intervals for impulse response functions computed
% with VARir
% =======================================================================
% [INF,SUP,MED,BAR] = VARirband(VAR,VARopt)
% -----------------------------------------------------------------------
% INPUT
%   - VAR: structure, result of VARmodel.m
%   - VARopt: options of the VAR (result of VARmodel.m)
% -----------------------------------------------------------------------
% OUTPUT
%   - INF(:,:,:): lower confidence band (H horizons, N variables, N shocks)
%   - SUP(:,:,:): upper confidence band (H horizons, N variables, N shocks)
%   - MED(:,:,:): median response (H horizons, N variables, N shocks)
%   - BAR(:,:,:): mean response (H horizons, N variables, N shocks)
% -----------------------------------------------------------------------
% EXAMPLE
%   - See VARToolbox_Primer.m in "../Primer/"
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-19
% -----------------------------------------------------------------------


%% 1. Check inputs
% -----------------------------------------------------------------------
if ~exist('VAR','var')
    error('You need to provide VAR structure, result of VARmodel');
end
if ~exist('VARopt','var')
    error('You need to provide VAR options (VARopt from VARmodel)');
end


%% 2. Retrieve and initialize variables
% -----------------------------------------------------------------------
nsteps = VARopt.nsteps;
ndraws = VARopt.ndraws;
pctg   = VARopt.pctg;
method = VARopt.method;

Ft      = VAR.Ft;  % \Phi' in the notes (rows are coeffs, columns are eqs)
nvar    = VAR.nvar;
nvar_ex = VAR.nvar_ex;
nlag    = VAR.nlag;
nlag_ex = VAR.nlag_ex;
const   = VAR.const;
nobs    = VAR.nobs;
resid   = VAR.resid;
ENDO    = VAR.ENDO;
EXOG    = VAR.EXOG;
IV      = VAR.IV;

% Preallocate output confidence band arrays
INF = zeros(nsteps,nvar,nvar);
SUP = zeros(nsteps,nvar,nvar);
MED = zeros(nsteps,nvar,nvar);
BAR = zeros(nsteps,nvar,nvar);

%% 3. Preallocate artificial data matrix
% -----------------------------------------------------------------------
y_artificial = zeros(nobs+nlag,nvar);


%% 4. Bootstrap loop
% -----------------------------------------------------------------------
tt = 1; % numbers of accepted draws
ww = 1; % index for printing on screen
while tt<=ndraws

    % Display progress
    if tt==VARopt.mult*ww
        disp(['Loop ' num2str(tt) ' / ' num2str(ndraws) ' draws'])
        ww=ww+1;
    end

    % Step 1: choose the method and generate the residuals
    if strcmp(method,'bs')
        % Sampling with replacement: draw rows of residual matrix randomly
        u = resid(ceil(size(resid,1)*rand(nobs,1)),:);
    elseif strcmp(method,'wild')
        % Wild bootstrap based on Rademacher distribution
        if strcmp(VARopt.ident,'iv')
            rr = 1-2*(rand(nobs,size(IV,2))>0.5);
            u = resid.*(rr*ones(size(IV,2),nvar));
            Z = [IV(1:nlag,:); IV(nlag+1:end,:).*rr];
        else
            rr = 1-2*(rand(nobs,1)>0.5);
            u = resid.*(rr*ones(1,nvar));
        end
    else
        error(['The method ' method ' is not available'])
    end

    % Step 2: generate the artificial data
    % Step 2.1: initialize first nlag observations with real data
    LAG=[];
    for jj = 1:nlag
        y_artificial(jj,:) = ENDO(jj,:);
        LAG = [y_artificial(jj,:) LAG]; %#ok<AGROW> intentional: prepend each lag block
    end
    % Build LAGplus (lag matrix augmented with deterministics)
    T = (1:nobs)';
    if const==0
        LAGplus = LAG;
    elseif const==1
        LAGplus = [1 LAG];
    elseif const==2
        LAGplus = [1 T(1) LAG];
    elseif const==3
        LAGplus = [1 T(1) T(1).^2 LAG];
    end
    if nvar_ex~=0
        LAGplus = [LAGplus VAR.X_EX(jj-nlag+1,:)]; %#ok<AGROW> exogenous cols appended after deterministics
    end

    % Step 2.2: simulate observations nlag+1 to nobs recursively
    for jj = nlag+1:nobs+nlag
        for mm = 1:nvar
            y_artificial(jj,mm) = LAGplus * Ft(1:end,mm) + u(jj-nlag,mm);
        end
        % Update the lag matrix for the next iteration
        if jj<nobs+nlag
            LAG = [y_artificial(jj,:) LAG(1,1:(nlag-1)*nvar)];
            if const==0
                LAGplus = LAG;
            elseif const==1
                LAGplus = [1 LAG];
            elseif const==2
                LAGplus = [1 T(jj-nlag+1) LAG];
            elseif const==3
                LAGplus = [1 T(jj-nlag+1) T(jj-nlag+1).^2 LAG];
            end
            if nvar_ex~=0
                LAGplus = [LAGplus VAR.X_EX(jj-nlag+1,:)]; %#ok<AGROW> exogenous cols appended after deterministics
            end
        end
    end

    % Step 3: estimate VAR on artificial data
    if nvar_ex~=0
        [VAR_draw, ~] = VARmodel(y_artificial,nlag,const,EXOG,nlag_ex);
    else
        [VAR_draw, ~] = VARmodel(y_artificial,nlag,const);
    end
    % For IV identification, attach the bootstrapped instrument
    if exist('Z','var')
        VAR_draw.IV = Z;
    end

    % Step 4: compute IRFs for this draw and store if stationary
    [IR_draw, VAR_draw] = VARir(VAR_draw,VARopt);
    if VAR_draw.maxEig<.9999
        IR(:,:,:,tt) = IR_draw; %#ok<AGROW> grows along 4th dim; pre-alloc avoided as ndraws accepted draws unknown a priori
        tt=tt+1;
    end
end
disp('-- Done!');
disp(' ');

%% 5. Compute the error bands
% -----------------------------------------------------------------------
pctg_inf = (100-pctg)/2;
pctg_sup = 100 - (100-pctg)/2;
INF(:,:,:) = prctile(IR(:,:,:,:),pctg_inf,4);
SUP(:,:,:) = prctile(IR(:,:,:,:),pctg_sup,4);
MED(:,:,:) = prctile(IR(:,:,:,:),50,4);
BAR(:,:,:) = mean(IR(:,:,:,:),4);
