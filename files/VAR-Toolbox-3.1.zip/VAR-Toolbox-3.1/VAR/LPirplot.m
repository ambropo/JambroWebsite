function LPirplot(IR,LPopt,INF,SUP,INF2,SUP2)
% =======================================================================
% Plot the impulse responses computed with LPmodel
% =======================================================================
% LPirplot(IR,LPopt,INF,SUP,INF2,SUP2)
% -----------------------------------------------------------------------
% INPUT
%   - IR(:,:)  : LP impulse responses (H horizons x N variables); each
%                column is the response of one variable to the same shock
%   - LPopt    : LP options structure (see LPoption); must contain
%                LPopt.vnames (variable labels) and LPopt.sname (shock
%                label)
% -----------------------------------------------------------------------
% OPTIONAL INPUT
%   - INF:  lower confidence band, outer (H x N) [e.g. 95%]
%   - SUP:  upper confidence band, outer (H x N) [e.g. 95%]
%   - INF2: lower confidence band, inner (H x N) [e.g. 68%]
%   - SUP2: upper confidence band, inner (H x N) [e.g. 68%]
% -----------------------------------------------------------------------
% EXAMPLE
%   - See VARToolbox_Primer.m in "../Primer/"
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: May 2026. Updated: 2026-05-27
% -----------------------------------------------------------------------


%% 1. Check inputs
% -----------------------------------------------------------------------
if ~exist('LPopt','var')
    error('You need to provide LP options (LPopt from LPoption)');
end
vnames = LPopt.vnames;
if isempty(vnames)
    error('You need to add variable labels in LPopt.vnames');
end
sname = LPopt.sname;


%% 2. Retrieve and initialize variables
% -----------------------------------------------------------------------
if isempty(LPopt.figname); filename = 'LP_IR'; else; filename = LPopt.figname; end
quality  = LPopt.quality;
suptitle = LPopt.suptitle;
hstart   = LPopt.hstart;
lstyle   = LPopt.linestyle;
if isfield(LPopt,'latex') && LPopt.latex==1; interp='latex'; else; interp='tex'; end

% Use caller-specified color, or fall back to pantone('Blue')
if isempty(LPopt.color)
    plotcol = pantone('Blue');
else
    plotcol = LPopt.color;
end

[nsteps, nvars] = size(IR);

% Define subplot grid
if ~isempty(LPopt.subplot)
    nrow = LPopt.subplot(1);
    ncol = LPopt.subplot(2);
else
    nrow = round(sqrt(nvars));
    ncol = ceil(sqrt(nvars));
end

% Define x-axis vector (respects hstart convention) and zero line
steps  = hstart : 1 : hstart+nsteps-1;
x_axis = zeros(1,nsteps);


%% 3. Plot
% -----------------------------------------------------------------------
% Configure swathe (shaded band) appearance
SwatheOpt = PlotSwatheOption;
SwatheOpt.swathecol  = plotcol;
SwatheOpt.swatheonly = 1;
SwatheOpt.transp     = 1;
SwatheOpt.xvec       = steps;   % align bands with IR line when hstart ~= 1

% Detect two-band mode once before the loop
twoband = exist('INF2','var') && exist('SUP2','var');

% Figure visibility: 'off' suppresses display while still allowing saving
if isfield(LPopt,'visible') && LPopt.visible==0; vis='off'; else; vis='on'; end

% Loop over variables and fill subplot panels
figure('Visible',vis);
FigSize(LPopt.FigSize(1),LPopt.FigSize(2))
for ii = 1:nvars
    subplot(nrow,ncol,ii);

    if exist('INF','var') && exist('SUP','var')
        if twoband
            % Outer band (e.g. 95%): light shading, dashed border lines
            SwatheOpt.alpha = 0.15;
            SwatheOpt.border = 1;
            PlotSwathe(IR(:,ii),[INF(:,ii) SUP(:,ii)],SwatheOpt); hold on;
            % Inner band (e.g. 68%): darker shading, no border lines
            SwatheOpt.alpha = 0.30;
            SwatheOpt.border = 0;
            H2 = PlotSwathe(IR(:,ii),[INF2(:,ii) SUP2(:,ii)],SwatheOpt); hold on;
            set([H2.swathe],'Visible','off');
        else
            % Single-band mode: dashed border lines, matching VARirplot style
            SwatheOpt.alpha = 0.15;
            SwatheOpt.border = 1;
            PlotSwathe(IR(:,ii),[INF(:,ii) SUP(:,ii)],SwatheOpt); hold on;
        end
        set(gcf,'renderer','painters')
    end

    mk = LPopt.marker;
    if strcmp(mk,'none')
        plot(steps,IR(:,ii),'LineStyle',lstyle,'Color',plotcol,'LineWidth',2); hold on
    else
        plot(steps,IR(:,ii),'LineStyle',lstyle,'Color',plotcol,'LineWidth',2,'Marker',mk,'MarkerSize',7,'MarkerFaceColor',0.5*plotcol+0.5*[1 1 1],'MarkerEdgeColor',plotcol); hold on
    end
    plot(steps,x_axis,'-k','LineWidth',0.5); hold on

    % Axis limits and ticks
    if ~isempty(LPopt.xlim)
        xlim(LPopt.xlim);
    else
        xlim([steps(1) steps(end)]);
    end
    if ~isempty(LPopt.ylim);  ylim(LPopt.ylim);               end
    if ~isempty(LPopt.xtick); set(gca,'XTick',LPopt.xtick);  end

    shorttitle_flag = isfield(LPopt,'shorttitle') && LPopt.shorttitle==1;
    if shorttitle_flag
        tstr = vnames{ii};
    elseif isempty(LPopt.sname)
        if strcmp(interp,'latex'); tstr = ['\textbf{' vnames{ii} '}']; else; tstr = vnames{ii}; end
    elseif strcmp(interp,'latex')
        tstr = ['\textbf{' vnames{ii} ' to }' sname];
    else
        tstr = [vnames{ii} ' to ' sname];
    end
    title(tstr,'FontWeight','bold','FontSize',13,'Interpreter',interp);
    set(gca,'FontSize',11,'Layer','bottom','TickLabelInterpreter',interp);
    if LPopt.grid; grid on; end

    % Axis labels
    if ~isempty(LPopt.xlabel); xlabel(LPopt.xlabel); end
    if ~isempty(LPopt.ylabel); ylabel(LPopt.ylabel); end
    % Disable clipping so markers at the axis boundary render fully
    set(findobj(gca,'Type','line'), 'Clipping', 'off');

    SetAxesDual(gca);
end

% Save figure
if quality>=1
    if suptitle==1
        if isempty(LPopt.sname)
            SupTitle('LP: Impulse Responses')
        else
            SupTitle(['LP: IR to ' sname])
        end
    end
    SaveFigure(filename,quality)
elseif quality==0
    print('-dpdf','-r100',filename);
end

