function out = OrthNorm(n)
% =======================================================================
% Compute a [n x n] random orthonormal matrix
% =======================================================================
% out = OrthNorm(n)
% -----------------------------------------------------------------------
% INPUT
%   - n: size of the matrix
% -----------------------------------------------------------------------
% OUTPUT
%   - out: [n x n] random orthonormal matrix
% -----------------------------------------------------------------------
% EXAMPLE
%   - See VARToolbox_Primer.m in "../Primer/"
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-19
% -----------------------------------------------------------------------

%% 1. Check inputs
% -----------------------------------------------------------------------
if nargin < 1
    error('OrthNorm: input n (matrix size) is required');
end

%% 2. Draw random orthonormal matrix via QR decomposition
% -----------------------------------------------------------------------
% QR is not unique: MATLAB's qr() can return Q with columns of either sign.
% The sign-normalisation loop enforces r(i,i) >= 0 (positive diagonal),
% giving a unique ("canonical") Q. Used in sign-restriction algorithms to
% draw uniformly from the Haar measure on the space of orthonormal matrices.
a = randn(n);
[q, r] = qr(a);
for i = 1:size(q,1)
    if r(i,i) < 0
        q(:,i) = -q(:,i);
    end
end
out = q;
end
