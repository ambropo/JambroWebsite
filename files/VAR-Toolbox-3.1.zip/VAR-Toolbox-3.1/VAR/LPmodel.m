function [IR,LPout,INF,SUP] = LPmodel(ENDO,S,LPopt)
% =======================================================================
% Estimate local projections (LP) via OLS or LP-IV across horizons h=1,...,H
% =======================================================================
% [IR,LPout,INF,SUP] = LPmodel(ENDO,S,LPopt)
% -----------------------------------------------------------------------
% INPUT
%   - ENDO: dependent variable vector (nobs x 1)
%   - S: shock or instrument variable at time t (nobs x 1)
%        OLS mode (LPopt.IV=[]): S is the shock and enters the regression
%        directly. To include lags of S as controls, add S to LPopt.LAGS.
%        IV mode (LPopt.IV non-empty): S is the external instrument (Z)
%        used to identify the endogenous treatment in LPopt.IV.
% -----------------------------------------------------------------------
% OPTIONAL INPUT
%   - LPopt: structure of LP options (see LPoption) [dflt = LPoption]
% -----------------------------------------------------------------------
% OUTPUT
%   - IR:    impulse response at each horizon h (H x 1)
%   - LPout: structure with IR, INF, SUP and full output per horizon
%            IV mode adds: LPout.jtest_chi2, .jtest_df, .jtest_pval
%            (joint Wald test H0: all b_h = 0, chi2(H) statistic)
%   - INF:   lower confidence band (H x 1) [optional]
%   - SUP:   upper confidence band (H x 1) [optional]
% -----------------------------------------------------------------------
% EXAMPLE
%   - See VARToolbox_Primer.m in "../Primer/"
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: November 2024. Updated: 2026-05-25
% -----------------------------------------------------------------------

% Use default LP options if not provided by the caller
if ~exist('LPopt','var')
    LPopt = LPoption;
end

%% 1. RETRIEVE AND INITIALIZE VARIABLES
% -----------------------------------------------------------------------
% Unpack all scalar options from LPopt and set the IV mode flag.
impact   = LPopt.impact;
H        = LPopt.nsteps;
LAGS     = LPopt.LAGS;
EXOG     = LPopt.EXOG;
nlag     = LPopt.nlag;
const    = LPopt.const;
longdiff = LPopt.longdiff;
do_iv    = ~isempty(LPopt.IV);
nlag_iv  = LPopt.nlag_iv;

% Store input arrays in LPout for downstream access
LPout.ENDO = ENDO;
LPout.EXOG = EXOG;
LPout.LAGS = LAGS;
LPout.S    = S;

%% 2. CHECK INPUTS
% -----------------------------------------------------------------------
% Validate conformability of all input arrays
[nobsENDO, ~]        = size(ENDO);
[nobsEXOG, nvarEXOG] = size(EXOG);
[nobsLAGS, nvarLAGS] = size(LAGS);
[nobsS,    ~]        = size(S);

if nobsS ~= nobsENDO
    error('LPmodel: S has different number of observations from ENDO');
end
if nvarEXOG > 0 && nobsEXOG ~= nobsENDO
    error('LPmodel: EXOG has different number of observations from ENDO');
end
if nvarLAGS > 0 && nobsLAGS ~= nobsENDO
    error('LPmodel: LAGS has different number of observations from ENDO');
end
if do_iv && size(LPopt.IV,1) ~= nobsENDO
    error('LPmodel: LPopt.IV has different number of observations from ENDO');
end

% nlag must be at least 1 to avoid LAGS entering contemporaneously with S
if nlag < 1
    error('LPmodel: nlag must be >= 1 (set in LPopt)');
end

%% 3. SAVE PARAMETERS AND CREATE DATA MATRICES
% -----------------------------------------------------------------------
% Record model dimensions and total coefficient count, then build the
% lagged-control matrix and trim all inputs to the common sample.
LPout.nvar = 1 + nvarEXOG + nvarLAGS;
LPout.nlag = nlag;
if nvarLAGS > 0
    ntotcoeff = const + 1 + nvarEXOG + nvarLAGS*nlag;
else
    ntotcoeff = 1 + nvarEXOG;
end
LPout.ntotcoeff = ntotcoeff;
LPout.const = const;

% Build lagged control matrix and trim ENDO, S, EXOG to the lag-trimmed sample
if nvarLAGS > 0
    [~, auxX] = VARmakexy(LAGS,nlag,const);
    lags = auxX;
    endo = ENDO(1+nlag:end,1);
    s    = S(1+nlag:end,1);
    if nvarEXOG > 0
        exog = EXOG(1+nlag:end,:);
    else
        exog = [];
    end
else
    lags = [];
    endo = ENDO;
    s    = S;
    if nvarEXOG > 0
        exog = EXOG;
    else
        exog = [];
    end
end

% Trim the endogenous treatment variable to the lag-trimmed sample
if do_iv
    if nvarLAGS > 0
        iv = LPopt.IV(1+nlag:end,1);
    else
        iv = LPopt.IV;
    end
end

% Control matrix for FWL: lagged regressors (includes constant when const=1)
if ~isempty(lags) || ~isempty(exog)
    controls = [exog, lags];
else
    controls = [];
end

% Normalisation: for OLS, standardise S; for IV, normalise the treatment D
if ~do_iv
    if impact == 0
        shock = zscore(s);
    elseif impact == 1
        shock = s;
    else
        error('LPmodel: impact must be 0 or 1');
    end
    d_norm = 1;
else
    shock  = s;  % instrument; normalisation applies to D
    if impact == 0
        d_norm = std(iv);
    elseif impact == 1
        d_norm = 1;
    else
        error('LPmodel: impact must be 0 or 1');
    end
end

% OLS RHS matrix (IV builds its own RHS via FWL)
if ~do_iv
    LHS = endo;
    RHS = [shock, exog, lags];
else
    LHS = endo;
end

% Long-difference: pre-align ENDO_{t-1} with the lag-trimmed endo
if longdiff
    if nvarLAGS > 0
        endo_lag1 = ENDO(nlag:end-1,1);
    else
        endo_lag1 = [nan; ENDO(1:end-1,1)];
    end
end

%% 3.1 IV: VALIDATE IV OPTIONS AND INITIALISE JOINT-TEST STORAGE
% -----------------------------------------------------------------------
% Horizon-by-horizon 2SLS is fully computed in §4.2. This block only
% validates options and pre-allocates the score matrix used in §5 for
% the joint Wald test.
% nlag_iv instrument lags use S(1+nlag-k : ...) from the pre-trimmed
% window; nlag_iv <= nlag ensures those values are within S.
if do_iv
    % Effective sample length and nlag_iv validation
    nT = length(s);
    if nlag_iv > nlag
        error('LPmodel: nlag_iv must be <= nlag');
    end

    % Balanced sample (common to all H equations) for joint test
    n_bal = max(nT - H + 1, 1);
    G_bal = zeros(n_bal, H);   % per-horizon IV scores: D_hat_h .* eps_h
    C_jt  = zeros(H, 1);       % per-horizon first-stage scaling

    % Initialise joint-test fields (overwritten in §5 when computable)
    LPout.jtest_chi2 = nan;
    LPout.jtest_df   = nan;
    LPout.jtest_pval = nan;
end

%% 4. OLS OR IV ESTIMATION AT EACH PROJECTION HORIZON
% -----------------------------------------------------------------------
% Pre-allocate output arrays and loop over horizons h=1,...,H. At each
% step, trim the sample to the h-step-ahead window and dispatch to OLS
% (§4.1) or 2SLS (§4.2).
IR  = nan(H,1);
INF = nan(H,1);
SUP = nan(H,1);
conf = norminv(1 - (1-LPopt.pctg/100)/2);

for hh = 1:H

    hname = ['h' num2str(hh)];  % dynamic field name for LPout at this horizon

    % Construct LHS: level or long-difference relative to t-1
    Y_lead = LHS(hh:end);
    if longdiff
        Y_base = endo_lag1(1:length(Y_lead));
        Y = Y_lead - Y_base;
    else
        Y = Y_lead;
    end
    n_h = length(Y);

    if ~do_iv
        %% 4.1 OLS
        % ---------------------------------------------------------------
        % Trim X to the horizon-specific sample and estimate via OLS.
        % NW bandwidth = h-1: LP residuals are MA(h-1) by construction.
        X      = RHS(1:n_h,:);
        OLSout = OLSmodel(Y,X,0,hh-1);

        % Store OLS results for this horizon in output struct
        LPout.(hname).nobs    = n_h;
        LPout.(hname).beta    = OLSout.beta;
        LPout.(hname).tstat   = OLSout.tstat;
        LPout.(hname).bstd    = OLSout.bstd;
        LPout.(hname).bstd_HW = OLSout.bstd_HW;
        LPout.(hname).bstd_NW = OLSout.bstd_NW;
        tout = tdis_prb(OLSout.tstat, n_h-ntotcoeff);
        LPout.(hname).tprob   = tout;
        LPout.(hname).resid   = OLSout.resid;
        LPout.(hname).yhat    = OLSout.yhat;
        LPout.(hname).y       = Y;
        LPout.(hname).x       = X;
        LPout.(hname).rsqr    = OLSout.rsqr;
        LPout.(hname).rbar    = OLSout.rbar;
        LPout.(hname).dw      = OLSout.dw;
        LPout.(hname).sigma   = OLSout.sige;
        LPout.(hname).nlag_nw = hh-1;

        % Extract impulse response and NW confidence bands
        IR(hh,1)  = OLSout.beta(1);
        INF(hh,1) = IR(hh) - conf*OLSout.bstd_NW(1);
        SUP(hh,1) = IR(hh) + conf*OLSout.bstd_NW(1);

    else
        %% 4.2 LP-IV via horizon-by-horizon 2SLS
        % ---------------------------------------------------------------
        % All FWL is done within the horizon-specific n_h sample so that
        % point estimates exactly match Stata's per-horizon ivreghdfe
        % (Frisch-Waugh equivalence). For horizon h:
        %   1. FWL Y_h, D, and Z (with nlag_iv lags) on C_h = controls(1:n_h)
        %   2. Project r_d_h onto instrument space R_Z_h (first stage)
        %   3. 2SLS coefficient and NW HAC SE via delta-method sandwich
        %
        % The instrument matrix uses the original S vector for lag-k of Z:
        % S(1+nlag-k : nlag+n_h-k), which is valid when nlag_iv <= nlag.
        % NW bandwidth is fixed at nlag_iv for overidentified IV (matching
        % Stata vce(hac nw nlag_iv)); for just-identified IV, bandwidth = h-1.

        % Horizon-specific controls and FWL of Y_h
        if ~isempty(controls)
            C_h   = controls(1:n_h,:);
            r_y_h = Y - C_h*(C_h\Y);
        else
            C_h   = [];
            r_y_h = Y;
        end

        % Per-horizon FWL of treatment D
        D_h = iv(1:n_h);
        if ~isempty(C_h)
            r_d_h = D_h - C_h*(C_h\D_h);
        else
            r_d_h = D_h;
        end

        % Build and FWL the instrument matrix: n_h x (nlag_iv+1)
        % Column k+1 = lag-k of S, evaluated over the lag-trimmed window.
        % S(1+nlag-k : nlag+n_h-k) gives the lag-k values for t=1,...,n_h.
        Z_raw = zeros(n_h, nlag_iv+1);
        for k = 0:nlag_iv
            Z_raw(:, k+1) = S(1+nlag-k : nlag+n_h-k, 1);
        end
        if ~isempty(C_h)
            R_Z_h = Z_raw - C_h*(C_h\Z_raw);
        else
            R_Z_h = Z_raw;
        end

        % First stage: project r_d_h onto the instrument space
        D_hat_h = R_Z_h*(R_Z_h\r_d_h);

        % 2SLS point estimate and IV residual
        denom_h = D_hat_h'*r_d_h;
        beta_h  = (D_hat_h'*r_y_h)/denom_h;
        eps_h   = r_y_h - beta_h*r_d_h;

        % NW HAC SE via delta-method IV sandwich.
        % Bandwidth: nlag_iv (fixed, matching Stata vce(hac nw nlag_iv))
        % or h-1 for just-identified IV (nlag_iv=0).
        if nlag_iv > 0
            bw_h = nlag_iv;
        else
            bw_h = max(hh-1, 0);
        end
        g_h   = D_hat_h.*eps_h;
        g_ols = OLSmodel(g_h, ones(n_h,1), 0, bw_h);
        se_h  = g_ols.bstd_NW(1)/abs(denom_h/n_h);

        % Store scores for joint Wald test (balanced sample, before scaling)
        if n_h >= n_bal
            G_bal(1:n_bal, hh) = D_hat_h(1:n_bal).*eps_h(1:n_bal);
            C_jt(hh)           = denom_h/n_h;
        end

        % Scale to a d_norm-sized shock in the treatment D
        beta_h = beta_h*d_norm;
        se_h   = se_h*d_norm;

        % Store 2SLS results for this horizon in output struct
        LPout.(hname).nobs    = n_h;
        LPout.(hname).beta    = beta_h;
        LPout.(hname).se_iv   = se_h;
        LPout.(hname).nlag_nw = bw_h;

        % Extract impulse response and NW confidence bands
        IR(hh,1)  = beta_h;
        INF(hh,1) = beta_h - conf*se_h;
        SUP(hh,1) = beta_h + conf*se_h;
    end
end

%% 5. JOINT WALD TEST H0: b_1 = ... = b_H = 0
% -----------------------------------------------------------------------
% Wald test using the cross-horizon NW long-run covariance of the per-
% horizon IV scores g_{h,t} = D_hat_h(t) * eps_h(t), evaluated over the
% balanced sample (first n_bal obs common to all H equations). NW
% bandwidth is set to nlag_iv. The chi2(H) statistic is asymptotically
% valid under the same HAC assumptions as the per-horizon 2SLS SEs.
%
% Derivation: the asymptotic variance of sqrt(n)*b_hat_h is
%   LRV(g_h) / C_jt(h)^2,  where C_jt(h) = E[D_hat_h * r_d_h].
% The cross-horizon covariance: V_b(h,k) = Sigma(h,k)/(n*C_jt(h)*C_jt(k))
% where Sigma is the NW LR covariance matrix of the score columns of G_bal.
% Wald statistic: n_bal * (C.*b)' * Sigma^{-1} * (C.*b) ~ chi2(H).
if do_iv
    if n_bal >= 2 && all(C_jt ~= 0)
        bw_jt = nlag_iv;  % NW bandwidth for cross-horizon score covariance

        % NW long-run covariance matrix of IV scores (H x H)
        Sigma = G_bal'*G_bal/n_bal;
        for lag = 1:bw_jt
            w_l    = 1 - lag/(bw_jt+1);   % Bartlett weight
            Gcross = G_bal(lag+1:end,:)'*G_bal(1:end-lag,:)/n_bal;
            Sigma  = Sigma + w_l*(Gcross + Gcross');
        end

        % Wald statistic (d_norm cancels: chi2 is scale-invariant)
        b_unscaled = IR/d_norm;
        scaled_b   = C_jt.*b_unscaled;
        chi2_val   = n_bal*(scaled_b'*(Sigma\scaled_b));
        df_val     = H;
        pval_val   = gammainc(chi2_val/2, df_val/2, 'upper');

        LPout.jtest_chi2 = chi2_val;
        LPout.jtest_df   = df_val;
        LPout.jtest_pval = pval_val;
    end
end

% Store IR, INF, SUP as top-level fields for convenient access
LPout.IR  = IR;
LPout.INF = INF;
LPout.SUP = SUP;
