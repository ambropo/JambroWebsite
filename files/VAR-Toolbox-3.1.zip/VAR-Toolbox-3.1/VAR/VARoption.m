function VARopt = VARoption
% =======================================================================
% Set default options for VAR analysis. Called automatically by VARmodel.
% =======================================================================
% VARopt = VARoption
% -----------------------------------------------------------------------
% OUTPUT
%   - VARopt: structure of options used by VARir, VARvd, VARhd, and plot
%       functions. Fields listed below with defaults.
% -----------------------------------------------------------------------
% EXAMPLE
%   - See VARToolbox_Primer.m in "../Primer/"
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-25
% -----------------------------------------------------------------------

%% 1. SET DEFAULT OPTIONS
% -----------------------------------------------------------------------
% Variable and shock labels
VARopt.vnames    = [];      % endogenous variable names
VARopt.vnames_ex = [];      % exogenous variable names
VARopt.snames    = [];      % shock names (defaults to vnames if empty)

% IRF and FEVD computation
VARopt.nsteps    = 40;      % number of horizons for IRFs and FEVDs
VARopt.impact    = 0;       % shock size: 0 = one std dev, 1 = unit shock
VARopt.shut      = 0;       % force the IRF of one variable to zero (0 = off)
VARopt.ident     = 'short'; % identification: 'short' (zero short-run), 'long'
                            % (zero long-run), 'sign', 'iv' (external instrument)
VARopt.recurs    = 'wold';  % MA representation: 'wold' or companion form 'comp'

% Bootstrap
VARopt.ndraws    = 1000;    % number of bootstrap or sign-restriction draws
VARopt.mult      = 10;      % print progress every mult draws
VARopt.pctg      = 95;      % confidence level for error bands (percent)
VARopt.method    = 'bs';    % error band method: 'bs' standard, 'wild' wild bootstrap

% Sign restrictions
VARopt.sr_hor    = 1;       % number of periods over which sign restrictions apply
VARopt.sr_rot    = 500;     % maximum rotations per draw
VARopt.sr_draw   = 100000;  % maximum total draws
VARopt.sr_mod    = 1;       % 1 = include model uncertainty in sign restrictions

% Figure export
VARopt.pick      = 0;       % shock to plot: 0 = all, j = shock j only
VARopt.quality   = 2;       % export quality: 2 = high (exportgraphics), 1 = high
                            % (ghostscript, legacy), 0 = low (pdf)
VARopt.suptitle  = 0;       % 1 = add super-title above figure panels
VARopt.datesnum  = [];      % numeric date vector for the VAR sample
VARopt.datestxt  = [];      % cell array of date strings for the VAR sample
VARopt.datestype = 1;       % date label style: 1 = smart, 2 = less smart
VARopt.firstdate = [];      % first sample date (e.g. 1999.75 = 1999Q4)
VARopt.frequency = 'q';     % data frequency: 'q' quarterly, 'm' monthly, 'y' yearly
VARopt.figname   = [];      % prefix string for exported figure filename
VARopt.FigSize   = [26,24]; % figure window size [width, height] in cm

% Panel appearance (used by VARirplot)
VARopt.latex      = 0;      % 1 = use LaTeX interpreter for figure text
VARopt.grid       = 1;      % 1 = show gridlines in plots
VARopt.marker     = 'o';    % marker style for IRF line ('o', 'none', etc.)
VARopt.subplot    = [];     % subplot grid [rows cols]; empty = auto from sqrt(nvars)
VARopt.shorttitle = 0;      % 1 = show variable name only as panel title
VARopt.color      = [];     % line and band color (RGB triplet); empty = pantone('Blue')
VARopt.linestyle  = '-';    % IR line style ('-', '--', ':', '-.')
VARopt.hstart     = 1;      % first horizon label on x-axis (0 or 1)
VARopt.xlim       = [];     % x-axis limits [lo hi]; empty = auto
VARopt.ylim       = [];     % y-axis limits [lo hi]; empty = auto
VARopt.xtick      = [];     % x-tick positions; empty = auto
VARopt.xlabel     = '';     % x-axis label applied to each panel; empty = none
VARopt.ylabel     = '';     % y-axis label applied to each panel; empty = none
VARopt.boxoff     = 0;      % 1 = box off on each panel
VARopt.visible    = 1;      % 1 = show figure windows, 0 = suppress display (save only)

% In progress
%VARopt.maxvd_N   = 1;       % position of variable to maximize variance decomposition
%VARopt.maxvd_H   = 10;      % horizon over which to maximize variance decomposition
%VARopt.maxvd_rot = 1000;    % max number of rotations for maximization of variance decomposition
