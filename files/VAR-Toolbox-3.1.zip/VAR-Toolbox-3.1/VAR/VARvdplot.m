function VARvdplot(VD,VARopt)
% =======================================================================
% Plot the VDs computed with VARvd
% =======================================================================
% VARvdplot(VD,VARopt)
% -----------------------------------------------------------------------
% INPUT
%   - VD(:,:,:): matrix with 't' steps, the VD due to 'j' shock for 
%       'k' variable
%	- VARopt: options of the VDs (see VARoption)
% -----------------------------------------------------------------------
% EXAMPLE
%   - See VARToolbox_Primer.m in "../Primer/"
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-27
% -----------------------------------------------------------------------


%% 1. Check inputs
% -----------------------------------------------------------------------
if ~exist('VARopt','var')
    error('You need to provide VAR options (VARopt from VARmodel)');
end
% If there is VARopt check that vnames is not empty
vnames = VARopt.vnames;
if isempty(vnames)
    error('You need to add label for endogenous variables in VARopt');
end
% Define shock names
if isempty(VARopt.snames)
    snames = VARopt.vnames;
else
    snames = VARopt.snames;
end


%% 2. Retrieve and initialize variables
% -----------------------------------------------------------------------
if isempty(VARopt.figname); filename = 'VD'; else; filename = VARopt.figname; end
quality = VARopt.quality;
suptitle = VARopt.suptitle;
pick = VARopt.pick;
if isfield(VARopt,'latex') && VARopt.latex==1; interp='latex'; else; interp='tex'; end

% Initialize VD matrix
[nsteps, nshocks, nvars] = size(VD);

% If one variable is chosen, set the right value for nvars
if pick<0 || pick>nvars
    error('The selected variable is non valid')
else
    if pick==0
        pick=1;
    else
        nvars = pick;
    end
end

% Subplot grid: use caller-specified layout or auto from sqrt(nvars)
if ~isempty(VARopt.subplot)
    row = VARopt.subplot(1);
    col = VARopt.subplot(2);
else
    row = round(sqrt(nvars));
    col = ceil(sqrt(nvars));
end

% Define a timeline
steps = 1:1:nsteps;
x_axis = zeros(1,nsteps);


%% 3. Plot
% -----------------------------------------------------------------------
if isfield(VARopt,'visible') && VARopt.visible==0; vis='off'; else; vis='on'; end
figure('Visible',vis);
FigSize(VARopt.FigSize(1),VARopt.FigSize(2))
for ii=pick:nvars
    subplot(row,col,ii);
    H = AreaPlot(VD(:,:,ii));
    xlim([1 nsteps]);
    if isfield(VARopt,'xlim') && ~isempty(VARopt.xlim); xlim(VARopt.xlim); end
    ylim([0 100]);
    if isfield(VARopt,'ylim') && ~isempty(VARopt.ylim); ylim(VARopt.ylim); end
    if isfield(VARopt,'xtick') && ~isempty(VARopt.xtick); set(gca,'XTick',VARopt.xtick); end
    if strcmp(interp,'latex'); tstr = ['\textbf{' vnames{ii} '}']; else; tstr = vnames{ii}; end
    title(tstr, 'FontWeight','bold','FontSize',13,'Interpreter',interp);
    set(gca, 'FontSize', 11, 'Layer', 'bottom', 'TickLabelInterpreter', interp);
    if VARopt.grid; grid on; end
    if isfield(VARopt,'xlabel') && ~isempty(VARopt.xlabel); xlabel(VARopt.xlabel); end
    if isfield(VARopt,'ylabel') && ~isempty(VARopt.ylabel); ylabel(VARopt.ylabel); end
    % Disable clipping so area/line edges at the axis boundary render fully
    set(findobj(gca,'Type','line'), 'Clipping', 'off');

    SetAxesDual(gca);
end

% Save figure at the requested quality level
FigName = filename;
if quality>=1
    if suptitle==1
        Alphabet = char('a'+(1:nvars)-1);
        SupTitle([Alphabet(ii) ') VD of '  vnames{ii}])
    end
    opt = LegOption; opt.handle = H(1,:);
    LegSubplot(snames,opt);
    SaveFigure(FigName,quality)
elseif quality==0
    legend(H(1,:),snames)
    print('-dpdf','-r100',FigName);
end

%close all
