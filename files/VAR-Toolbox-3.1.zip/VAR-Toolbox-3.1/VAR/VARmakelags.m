function OUT = VARmakelags(DATA,lag)
% =======================================================================
% Builds a matrix with lagged values of DATA, i.e. if DATA = [x1 x2],
% VARmakelags(DATA,1) yields OUT = [x1 x2 x1(-1) x2(-1)]. Serves as an
% input to VARmakexy
% =======================================================================
% OUT = VARmakelags(DATA,lag)
% -----------------------------------------------------------------------
% INPUT
%   - DATA: matrix containing the original data
%   - lag: lag order
% -----------------------------------------------------------------------
% OUTPUT
%   - OUT: matrix of lagged values
% -----------------------------------------------------------------------
% EXAMPLE
%   x = [1 2; 3 4; 5 6; 7 8; 9 10];
%   OUT = VARmakelags(x,2)
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-14
% -----------------------------------------------------------------------

%% 1. Build lag matrix
% -----------------------------------------------------------------------
% The loop prepends successive lags so that after the loop:
%   OUT = [Y(-lag+1), ..., Y(-1), Y(0)]   (before aux is added)
% Each iteration jj=0 gives the most recent lag, jj=lag-1 the oldest,
% so the prepend order results in chronological lag ordering left-to-right.
% The final matrix is [Y(0), Y(-1), ..., Y(-lag+1)] with the contemporaneous
% values in the first columns and deeper lags to the right.
% Preallocate: lag blocks of nvar columns, nobs-lag rows.
[nobs, nvar] = size(DATA);
OUT = nan(nobs-lag, lag*nvar);
for jj = 0:lag-1
    % Prepend order: jj=lag-1 → leftmost cols, jj=0 → rightmost cols.
    % col_idx maps each jj to its block of nvar columns in the final matrix.
    col_idx = (lag-1-jj)*nvar + (1:nvar);
    OUT(:, col_idx) = DATA(jj+1:nobs-lag+jj, :);
end

% Prepend the current (non-lagged) values as the first block of columns
aux = DATA(lag+1:end, :);
OUT = [aux, OUT];