function VARhdplot(HD,VARopt)
% =======================================================================
% Plot the HD shocks computed with VARhd
% =======================================================================
% VARhdplot(HD,VARopt)
% -----------------------------------------------------------------------
% INPUT
%   - HD: structure from VARhd
%   - VARopt: options of the VAR (see VARopt from VARmodel)
% -----------------------------------------------------------------------
% EXAMPLE
%   - See VARToolbox_Primer.m in "../Primer/"
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-27
% -----------------------------------------------------------------------


%% 1. Check inputs
% -----------------------------------------------------------------------
if ~exist('VARopt','var')
    error('You need to provide VAR options (VARopt from VARmodel)');
end
% If there is VARopt check that vnames is not empty
vnames = VARopt.vnames;
if isempty(vnames)
    error('You need to add label for endogenous variables in VARopt');
end
% Define shock names
if isempty(VARopt.snames)
    snames = VARopt.vnames;
else
    snames = VARopt.snames;
end

%% 2. Retrieve and initialize variables
% -----------------------------------------------------------------------
if isempty(VARopt.figname); basename = 'HD'; else; basename = VARopt.figname; end
quality = VARopt.quality;
suptitle = VARopt.suptitle;
pick = VARopt.pick;
if isfield(VARopt,'latex') && VARopt.latex==1; interp='latex'; else; interp='tex'; end

% Initialize HD matrix dimensions (nshocks is not needed by the loop)
[nsteps, nvars, ~] = size(HD.shock);

% Validate the shock selector; when pick==0 plot all shocks starting from 1
if pick<0 || pick>nvars
    error('VARhdplot: the selected shock index (pick=%d) is out of range [0, %d].', pick, nvars)
elseif pick==0
    pick = 1;
end

% Number of figures: suffix _N applied only when more than one figure is saved
nfigs = nvars - pick + 1;


%% 3. Plot
% -----------------------------------------------------------------------
if isfield(VARopt,'visible') && VARopt.visible==0; vis='off'; else; vis='on'; end
for ii=pick:nvars
    figure('Visible',vis);
    FigSize(VARopt.FigSize(1),VARopt.FigSize(2))
    H = AreaPlot(squeeze(HD.shock(:,:,ii))); hold on;
    h = plot(sum(squeeze(HD.shock(:,:,ii)),2),'-k','LineWidth',2);
    if ~isempty(VARopt.firstdate); DatesPlot(VARopt.firstdate,nsteps,8,VARopt.frequency); end
    xlim([1 nsteps]);
    if isfield(VARopt,'xlim') && ~isempty(VARopt.xlim); xlim(VARopt.xlim); end
    if isfield(VARopt,'ylim') && ~isempty(VARopt.ylim); ylim(VARopt.ylim); end
    if isfield(VARopt,'xtick') && ~isempty(VARopt.xtick); set(gca,'XTick',VARopt.xtick); end
    set(gca,'FontSize',11,'Layer','bottom','TickLabelInterpreter',interp);
    if VARopt.grid; grid on; end
    if strcmp(interp,'latex'); tstr = ['\textbf{' vnames{ii} '}']; else; tstr = vnames{ii}; end
    title(tstr, 'FontWeight','bold','FontSize',13,'Interpreter',interp);
    if isfield(VARopt,'xlabel') && ~isempty(VARopt.xlabel); xlabel(VARopt.xlabel); end
    if isfield(VARopt,'ylabel') && ~isempty(VARopt.ylabel); ylabel(VARopt.ylabel); end
    % Disable clipping so area/line edges at the axis boundary render fully
    set(findobj(gca,'Type','line'), 'Clipping', 'off');

    SetAxesDual(gca);
    % Save
    if nfigs > 1; FigName = [basename '_' num2str(ii)]; else; FigName = basename; end
    if quality>=1
        if suptitle==1
            Alphabet = char('a'+(1:nvars)-1);
            SupTitle([Alphabet(ii) ') HD of '  vnames{ii}])
        end
        opt = LegOption; opt.handle = [H(1,:) h];
        LegSubplot([snames {'Data'}],opt);
        SaveFigure(FigName,quality)
    elseif quality==0
        legend([H(1,:) h],[snames {'Data'}])
        print('-dpdf','-r100',FigName);
    end
end

%close all