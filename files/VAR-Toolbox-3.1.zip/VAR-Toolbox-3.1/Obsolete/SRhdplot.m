function SRhdplot(HD,VARopt)
% =======================================================================
% Plot the HD shocks computed with SR (sign restriction procedure)
% =======================================================================
% SRhdplot(HD,VARopt)
% -----------------------------------------------------------------------
% INPUT
%   - HD: structure from SR
%   - VARopt: options of the VAR (from VARmodel and SR)
% -----------------------------------------------------------------------
% EXAMPLE
%   - See VARToolbox_Primer.m in "../Primer/"
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-19
% -----------------------------------------------------------------------

%% 1. Check inputs
% -----------------------------------------------------------------------
if ~exist('VARopt','var')
    error('SRhdplot: VARopt is required (output of VARmodel)');
end
% Verify that variable and shock labels have been set in VARopt
vnames = VARopt.vnames;
snames = VARopt.snames;
if isempty(vnames)
    error('SRhdplot: VARopt.vnames is empty — add variable labels');
end
if isempty(snames)
    error('SRhdplot: VARopt.snames is empty — add shock labels');
end


%% 2. Define plot parameters
% -----------------------------------------------------------------------
filename = [VARopt.figname 'HD_'];
quality  = VARopt.quality;
suptitle = VARopt.suptitle;
pick     = VARopt.pick;

% Read dimensions from the HD shock array (nsteps x nvars x nshocks)
[nsteps, nvars, ~] = size(HD.shock);

% Validate pick and set the starting shock index
if pick < 0 || pick > nvars
    error('SRhdplot: VARopt.pick is out of range')
else
    if pick == 0
        pick = 1;
    end
end


%% 3. Plot
% -----------------------------------------------------------------------
FigSize(VARopt.FigSize(1),VARopt.FigSize(2))
for ii=pick:nvars
    H = AreaPlot(squeeze(HD.shock(:,:,ii))); hold on;
    h = plot(sum(squeeze(HD.shock(:,:,ii)),2),'-k','LineWidth',2);
    if ~isempty(VARopt.firstdate); DatesPlot(VARopt.firstdate,nsteps,8,VARopt.frequency); end
    xlim([1 nsteps]);
    set(gca,'FontSize',11,'Layer','top');
    title(vnames{ii}, 'FontWeight','bold','FontSize',13);
    % Save figure
    FigName = [filename num2str(ii)];
    if quality >= 1
        if suptitle == 1
            Alphabet = char('a'+(1:nvars)-1);
            SupTitle([Alphabet(ii) ') HD of ' vnames{ii}])
        end
        opt = LegOption; opt.handle = [H(1,:) h];
        LegSubplot([snames {'Data'}],opt);
        SaveFigure(FigName,quality)
    elseif quality == 0
        legend([H(1,:) h],[snames {'Data'}])
        print('-dpdf','-r100',FigName);
    end
    clf('reset');
end

close all