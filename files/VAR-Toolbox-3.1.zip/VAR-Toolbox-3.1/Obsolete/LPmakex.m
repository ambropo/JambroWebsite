function OUT = LPmakex(x,nlag)
% =======================================================================
% *** OBSOLETE — use LPmodel.m instead ***
% This function is no longer supported and will not be updated.
% =======================================================================
% Creates a matrix containing up to "nlag" lags of the data in the
% vector x
% =======================================================================
% OUT = LPmakex(x,nlag)
% -----------------------------------------------------------------------
% INPUT
%	- x: vector of data [nobs x 1]
%	- nlag: number of lags to compute 
% -----------------------------------------------------------------------
% OUTPUT
%	- OUT: matrix with lagged data
% -----------------------------------------------------------------------
% EXAMPLE
%   x = [1; 2; 3; 4; 5; 6];
%   OUT = LPmakex(x,3)
% OUT =
%        NaN   NaN   NaN
%          1   NaN   NaN
%          2     1   NaN
%          3     2     1
%          4     3     2
%          5     4     3
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: September 2024. Updated: 2026-05-14
% -----------------------------------------------------------------------

% Build matrix of lags column by column
OUT = [];
for ii=1:nlag
    OUT = [OUT L(x,-ii)];
end
