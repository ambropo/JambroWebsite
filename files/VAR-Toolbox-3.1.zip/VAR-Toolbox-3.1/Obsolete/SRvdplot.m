function SRvdplot(VD,VARopt)
% =======================================================================
% Plot the VDs computed with SR (sign restriction procedure)
% =======================================================================
% SRvdplot(VD,VARopt)
% -----------------------------------------------------------------------
% INPUT
%   - VD(:,:,:): matrix with FEVDs (H horizons, N shocks, N variables)
%   - VARopt: options of the VAR (from VARmodel and SR)
% -----------------------------------------------------------------------
% OPTIONAL INPUT
%   - INF: lower error band (H horizons, N shocks, N variables)
%   - SUP: upper error band (H horizons, N shocks, N variables)
% -----------------------------------------------------------------------
% EXAMPLE
%   - See VARToolbox_Primer.m in "../Primer/"
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-19
% -----------------------------------------------------------------------

%% 1. Check inputs
% -----------------------------------------------------------------------
if ~exist('VARopt','var')
    error('SRvdplot: VARopt is required (output of VARmodel)');
end
% Verify that variable and shock labels have been set in VARopt
vnames = VARopt.vnames;
snames = VARopt.snames;
if isempty(vnames)
    error('SRvdplot: VARopt.vnames is empty — add variable labels');
end
if isempty(snames)
    error('SRvdplot: VARopt.snames is empty — add shock labels');
end


%% 2. Define plot parameters
% -----------------------------------------------------------------------
filename = [VARopt.figname 'VD'];
quality  = VARopt.quality;
suptitle = VARopt.suptitle;
pick     = VARopt.pick;

% Read dimensions; nshocks drives the subplot grid, nvars the loop
nshocks = length(snames); [nsteps, nvars, ~] = size(VD);

% Validate pick and set the upper variable index
if pick < 0 || pick > nvars
    error('SRvdplot: VARopt.pick is out of range')
else
    if pick == 0
        pick = 1;
    else
        nvars = pick; % plot only up to the selected variable
    end
end

% Subplot grid dimensions (one panel per shock)
row = round(sqrt(nshocks));
col = ceil(sqrt(nshocks));

%% 3. Plot
% -----------------------------------------------------------------------
% Area plot: each panel shows the FEVD of one variable across all shocks
FigSize(VARopt.FigSize(1),VARopt.FigSize(2))
for ii=1:nvars
    subplot(row,col,ii);
    H = AreaPlot(VD(:,:,ii));
    xlim([1 nsteps]); ylim([0 100]);
    title(vnames{ii}, 'FontWeight','bold','FontSize',13);
    set(gca, 'FontSize', 11, 'Layer', 'top');
end
% Save figure
FigName = filename;
if quality >= 1
    if suptitle == 1
        SupTitle('Variance Decomposition')
    end
    opt = LegOption; opt.handle = H(1,:);
    LegSubplot(snames,opt);
    SaveFigure(FigName,quality);
elseif quality == 0
    legend(H(1,:),snames)
    print('-dpdf','-r100',FigName);
end

% Close all figure windows
close all
