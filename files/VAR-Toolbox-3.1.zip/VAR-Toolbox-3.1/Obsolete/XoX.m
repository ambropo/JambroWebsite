function OUT = XoX(DATA,frequency,type)
% =======================================================================
% *** OBSOLETE — use datatreat.m instead ***
% This function is no longer supported and will not be updated.
% =======================================================================
% Compute the rate of change of a panel of time series (DATA, T obs x N
% countries) at quarterly or annual frequency
% =======================================================================
% OUT = XoX(DATA,frequency,type)
% -----------------------------------------------------------------------
% INPUT
%	- DATA: matrix DATA(T,N)
%   - frequency: 1 for X(t)-X(t-1); 4 for X(t)-X(t-4); etc...
% -----------------------------------------------------------------------
% OPTIONAL INPUT
%   - type: 'logdiff', computes log(X(t))-log(X(t-1)) [DEFAULT]
%           'diff'   , computes X(t)-X(t-1)
%           'rate'   , computes X(t)/X(t-1)-1
% -----------------------------------------------------------------------
% OUTPUT
%	- OUT: matrix DATA(T,N) of rates of change. The first # (=frequency) 
%     observations are NaN
% -----------------------------------------------------------------------
% EXAMPLE
%   x = [1 2; -3 4; 5 6; 7 8; 9 10];
%   OUT = XoX(x,1,'diff')
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% March 2012. Updated: 2026-05-14
% -----------------------------------------------------------------------

%% 1. Check inputs
% -----------------------------------------------------------------------
if ~exist('type','var')
    type = 'logdiff';
end

% Get dimensions of the input data matrix
[nobs, nvar] = size(DATA);

% Validate that the lag gap does not exceed the sample length
if frequency>nobs
    error('Frequency is larger than the number of observations')
end

%% 2. Compute rate of change
% -----------------------------------------------------------------------
% The first 'frequency' rows are NaN because no lagged value exists yet.
% 'frequency' sets the lag gap: 1=qoq or mom, 4=yoy for quarterly data.
if strcmp(type,'logdiff')   % log(X_t) - log(X_{t-h}): approximates % change
    OUT = log(DATA(1+frequency:end,:))-log(DATA(1:end-frequency,:));
    OUT = [nan(frequency,nvar); OUT];
elseif strcmp(type,'rate')  % X_t/X_{t-h} - 1: exact % change
    OUT = DATA(1+frequency:end,:)./DATA(1:end-frequency,:)-1;
    OUT = [nan(frequency,nvar); OUT];
elseif strcmp(type,'diff')  % X_t - X_{t-h}: level change
    OUT = DATA(1+frequency:end,:) - DATA(1:end-frequency,:);
    OUT = [nan(frequency,nvar); OUT];
end
