function SRirplot(IR,VARopt,INF,SUP)
% =======================================================================
% Plot the IRs computed with SR (sign restriction procedure)
% =======================================================================
% SRirplot(IR,VARopt,INF,SUP)
% -----------------------------------------------------------------------
% INPUT
%   - IR(:,:,:): IRF matrix (H horizons, N variables, N shocks)
%   - VARopt: options of the VAR (from VARmodel and SR)
% -----------------------------------------------------------------------
% OPTIONAL INPUT
%   - INF: lower error band
%   - SUP: upper error band
% -----------------------------------------------------------------------
% EXAMPLE
%   - See VARToolbox_Primer.m in "../Primer/"
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-25
% -----------------------------------------------------------------------

%% 1. Check inputs
% -----------------------------------------------------------------------
if ~exist('VARopt','var')
    error('SRirplot: VARopt is required (output of VARmodel)');
end
% Verify that variable and shock labels have been set in VARopt
vnames = VARopt.vnames;
snames = VARopt.snames;
if isempty(vnames)
    error('SRirplot: VARopt.vnames is empty — add variable labels');
end
if isempty(snames)
    error('SRirplot: VARopt.snames is empty — add shock labels');
end
if length(snames) > length(vnames)
    error('SRirplot: more shock labels than variables in VARopt');
end


%% 2. Define plot parameters
% -----------------------------------------------------------------------
filename = [VARopt.figname 'IR_'];
quality  = VARopt.quality;
suptitle = VARopt.suptitle;
pick     = VARopt.pick;

% Read dimensions; nshocks comes from snames, not the IR array third dim
nshocks = length(snames); [nsteps, nvars, ~] = size(IR);

% Validate pick and set the starting shock index
if pick < 0 || pick > nvars
    error('SRirplot: VARopt.pick is out of range')
else
    if pick == 0
        pick = 1;
    else
        nshocks = pick; % plot only up to the selected shock
    end
end

% Subplot grid dimensions
row = round(sqrt(nvars));
col = ceil(sqrt(nvars));

% Horizontal axis references
steps  = 1:1:nsteps;
x_axis = zeros(1,nsteps);


%% 3. Plot
% -----------------------------------------------------------------------
SwatheOpt        = PlotSwatheOption;
SwatheOpt.marker = '*';
SwatheOpt.col    = pantone('Blue');
FigSize(VARopt.FigSize(1),VARopt.FigSize(2))
for jj=pick:nshocks
    for ii=1:nvars
        subplot(row,col,ii);
        plot(steps,IR(:,ii,jj),'LineStyle','-','Color',pantone('Blue'),'LineWidth',2, ...
            'Marker','o','MarkerSize',7,'MarkerFaceColor',0.5*pantone('Blue')+0.5*[1 1 1], ...
            'MarkerEdgeColor',pantone('Blue')); hold on
        % Overlay confidence bands if provided
        if exist('INF','var') && exist('SUP','var')
            PlotSwathe(IR(:,ii,jj),[INF(:,ii,jj) SUP(:,ii,jj)],SwatheOpt); hold on;
        end
        plot(x_axis,'--k','LineWidth',0.5); hold on
        xlim([1 nsteps]);
        title([vnames{ii} ' to ' snames{jj}], 'FontWeight','bold','FontSize',13);
        set(gca, 'FontSize', 11, 'Layer', 'top');
    end
    % Save figure for shock jj
    FigName = [filename num2str(jj)];
    if quality >= 1
        if suptitle == 1
            Alphabet = char('a'+(1:nshocks)-1);
            SupTitle([Alphabet(jj) ') IR to a shock to ' snames{jj}])
        end
        SaveFigure(FigName,quality)
    elseif quality == 0
        print('-dpdf','-r100',FigName);
    end
    clf('reset');
end

close all