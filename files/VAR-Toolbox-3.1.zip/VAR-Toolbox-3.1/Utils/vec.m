function out = vec(X,dim)
% =======================================================================
% Vectorize the matrix X
% =======================================================================
% out = vec(X,dim)
% -----------------------------------------------------------------------
% INPUT
%   - X: (TxN) matrix
% -----------------------------------------------------------------------
% OPTIONAL INPUT
%   - dim: dimension over which to vectorize [dflt 1]. Set to 2 to get a
%          row vector
% -----------------------------------------------------------------------
% OUTPUT
%   - out: [r*c x 1] column vector (dim=1) or [1 x r*c] row vector (dim=2)
% -----------------------------------------------------------------------
% EXAMPLE
%   x = [1 2; 3 4; 5 6; 7 8; 9 10];
%   out = vec(x,1)
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% March 2012. Updated: 2026-05-19
% -----------------------------------------------------------------------

%% 1. Check inputs
% -----------------------------------------------------------------------
if ~exist('dim','var')
    dim = 1;
end

%% 2. Vectorize
% -----------------------------------------------------------------------
% dim=1: stack columns into a (r*c x 1) column vector (standard vec operator)
% dim=2: lay out elements into a (1 x r*c) row vector
[r, c] = size(X);

if dim==1
    out = reshape(X, r*c, 1);
elseif dim==2
    out = reshape(X, 1, r*c);
else
    error('vec: dim must be 1 (column vector) or 2 (row vector)')
end
    