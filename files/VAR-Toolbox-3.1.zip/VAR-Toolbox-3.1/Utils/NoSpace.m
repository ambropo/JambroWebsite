function out = NoSpace(str)
% =======================================================================
% Removes spaces from a string
% =======================================================================
% out = NoSpace(str)
% -----------------------------------------------------------------------
% INPUT
%	- str : string
% -----------------------------------------------------------------------
% OUTPUT
%	- out : string with no spaces
% -----------------------------------------------------------------------
% EXAMPLE
%   x = 'this is a string with spaces';
%   out = NoSpace(x)
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-19
% -----------------------------------------------------------------------

%% 1. Remove spaces
% -----------------------------------------------------------------------
% Logical indexing retains only non-space characters in their original order.
out = str(~isspace(str));