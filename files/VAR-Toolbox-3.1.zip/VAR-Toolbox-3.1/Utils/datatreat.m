function OUT = datatreat(DATA,vtreat,nlag)
% =======================================================================
% Treat a time series with the specified method. If changes are computed
% the function assumes 1 lag (unless otherwise specified)
% =======================================================================
% OUT = datatreat(DATA,vtreat,nlag)
% -----------------------------------------------------------------------
% INPUT
%	- DATA: matrix DATA(T,N)
%   - vtreat: transformation code
%             0  No treatment
%             1  Log
%             2  Difference
%             3  Log difference
%             4  Fractional change
% -----------------------------------------------------------------------
% OPTIONAL INPUT
%   - nlag: number of lags for difference-based transforms [dflt = 1]
% -----------------------------------------------------------------------
% OUTPUT
%	- OUT: matrix DATA(T,N) of treated data; first nlag rows are NaN for
%          difference-based transforms
% -----------------------------------------------------------------------
% EXAMPLE
%   x = [1 2; 3 4; 5 6; 7 8; 9 10];
%   OUT = datatreat(x,3,1)
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% March 2012. Updated: 2026-05-19
% -----------------------------------------------------------------------

%% 1. Check inputs
% -----------------------------------------------------------------------
if nargin < 2
    error('datatreat: DATA and vtreat are required inputs')
end

if ~ismember(vtreat, 0:4)
    error('datatreat: vtreat must be 0, 1, 2, 3, or 4')
end

if ~exist('nlag','var')
    nlag = 1;
end

%% 2. Apply transformation
% -----------------------------------------------------------------------
[nobs, nvar] = size(DATA);
OUT = nan(nobs,nvar);  % first nlag rows stay NaN for differenced series

% No treatment
if vtreat==0
    OUT = DATA;

% Log
elseif vtreat==1
    if any(DATA(:)<0), warning('Negative numbers set to NaN before taking logs'), end
    DATA(DATA<0) = NaN;
    OUT = log(DATA);

% Difference
elseif vtreat==2
    OUT(nlag+1:end,:) = DATA(1+nlag:end,:) - DATA(1:end-nlag,:);

% Log difference
elseif vtreat==3
    if any(DATA(:)<0), warning('Negative numbers set to NaN before taking logs'), end
    DATA(DATA<0) = NaN;
    OUT(nlag+1:end,:) = log(DATA(1+nlag:end,:)) - log(DATA(1:end-nlag,:));

% Fractional change
elseif vtreat==4
    OUT(nlag+1:end,:) = DATA(1+nlag:end,:)./DATA(1:end-nlag,:) - 1;
end
