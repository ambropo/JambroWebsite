function OUT = TabPrint(DATA,hlabel,vlabel,approx)
% =======================================================================
% Prints a numerical table with labels, with specified numbers of decimal
% digits
% =======================================================================
% OUT = TabPrint(DATA,hlabel,vlabel,approx)
% -----------------------------------------------------------------------
% INPUT
%   - DATA = a (T x N) matrix of numbers
% -----------------------------------------------------------------------
% OPTIONAL INPUT
%	- hlabel = a (1 x N) cell array of column headers
%	- vlabel = a (T x 1) cell array of row labels
%   - approx = number of decimal digits [dflt = 2]
% -----------------------------------------------------------------------
% OUTPUT
%   - OUT = a cell array with the formatted table
% -----------------------------------------------------------------------
% EXAMPLE
%   x = [1 2; 3 4; 5 6; 7 8; 9 10];
%   hlab = {'A','B'};
%   vlab = {'a';'b';'c';'d';'e'};
%   OUT = TabPrint(x,hlab,vlab)
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-19
% -----------------------------------------------------------------------

%% 1. Check inputs
% -----------------------------------------------------------------------
[n, m] = size(DATA);

if ~exist('hlabel','var') || isempty(hlabel)
    hlabel = cell(1,m);
end

if ~exist('vlabel','var') || isempty(vlabel)
    vlabel = cell(n,1);
end

if ~exist('approx','var')
    approx = 2;
end

if length(hlabel)~=m
    error('TabPrint: hlabel must have one entry per column of DATA (%d expected, %d supplied)', m, length(hlabel))
end

if length(vlabel)~=n
    error('TabPrint: vlabel must have one entry per row of DATA (%d expected, %d supplied)', n, length(vlabel))
end

%% 2. Assemble labelled table
% -----------------------------------------------------------------------
% Convert numbers to strings with approx decimal places
OUT = roundnum2cell(DATA,approx);

% Prepend column headers above the data
OUT = [hlabel ; OUT];
% Build a blank top-left corner cell to align the row labels
aux = cell(rows(hlabel),cols(vlabel));
vlabel = [aux; vlabel];
% Prepend row labels on the left
OUT = [vlabel, OUT];