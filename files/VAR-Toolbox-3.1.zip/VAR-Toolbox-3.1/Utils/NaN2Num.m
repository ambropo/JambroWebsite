function OUT = NaN2Num(DATA)
% =======================================================================
% Substitute NaN values with 123456789
% =======================================================================
% OUT = NaN2Num(DATA)
% -----------------------------------------------------------------------
% INPUT
%	- DATA: a (m x n) matrix with NaNs
% -----------------------------------------------------------------------
% OUTPUT
%	- OUT: a (m x n) matrix with 123456789 instead of NaNs
% -----------------------------------------------------------------------
% EXAMPLE
%   x = [NaN 2; NaN 4; 5 6; 7 8; 9 10];
%   OUT = NaN2Num(x)
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-19
% -----------------------------------------------------------------------

%% 1. Replace NaN with sentinel value
% -----------------------------------------------------------------------
% 123456789 is an arbitrary large integer used as a sentinel so that
% NaN-free matrices can be passed to routines that don't handle NaN.
% Reverse with Num2NaN.
OUT = DATA;
for i=1:size(DATA,1)
    for j=1:size(DATA,2)
        if isnan(DATA(i,j))
            OUT(i,j) = 123456789;
        end
    end
end

