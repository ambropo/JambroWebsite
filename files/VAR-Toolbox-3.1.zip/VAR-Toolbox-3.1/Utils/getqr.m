function out = getqr(a)
% =======================================================================
% QR factorization of a matrix a.
% =======================================================================
% out = getqr(a)
% -----------------------------------------------------------------------
% INPUT
%	- a: Matrix to factorize
% -----------------------------------------------------------------------
% OUTPUT
%   - out: Q matrix from QR factorization with sign-normalised columns,
%          such that out*out' = I
% -----------------------------------------------------------------------
% EXAMPLE
%   a = randn(3,3);
%   out = getqr(a)
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-19
% -----------------------------------------------------------------------

%% 1. QR factorization with sign normalization
% -----------------------------------------------------------------------
% MATLAB's qr() is not unique: columns of Q can be negated freely.
% The loop forces a positive diagonal in R, pinning the sign of each Q
% column so that out*out' = I with a canonical orientation.
[q, r] = qr(a);
for i = 1:size(q,2)
    if r(i,i) < 0
        q(:,i) = -q(:,i);
    end
end
out = q;
end