function OUT = roundnum2cell(DATA,approx)
% =======================================================================
% Transform a numerical matrix into a cell array with approx decimal digits
% =======================================================================
% OUT = roundnum2cell(DATA,approx)
% -----------------------------------------------------------------------
% INPUT
%   - DATA = a (n x m) matrix of numbers
% -----------------------------------------------------------------------
% OPTIONAL INPUT
%   - approx = number of decimal digits. Default = 2
% -----------------------------------------------------------------------
% OUTPUT
%   - OUT = a cell matrix with desired number of decimal digits
% -----------------------------------------------------------------------
% EXAMPLE
%   x = [1 2; 3 4; 5 6; 7 8; 9 10];
%   OUT = roundnum2cell(x,2)
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-19
% -----------------------------------------------------------------------

%% 1. Check inputs
% -----------------------------------------------------------------------
if ~exist('approx','var')
    approx = 2;
end

%% 2. Convert each element to a fixed-decimal string
% -----------------------------------------------------------------------
OUT = cell(size(DATA));
for i=1:numel(DATA)
    YY = round(DATA(i), approx);
    % Build a format string like '%0.2f' and apply it
    OUT{i} = sprintf(['%0.' num2str(approx) 'f'], YY);
end 

