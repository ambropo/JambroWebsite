function c = columns(DATA)
% =======================================================================
% Returns number of columns in a matrix
% =======================================================================
% c = columns(DATA)
% -----------------------------------------------------------------------
% INPUT
%   - DATA: input matrix (nobs X nvars)
% -----------------------------------------------------------------------
% OUTPUT
%	- c: number of columns in DATA
% -----------------------------------------------------------------------
% EXAMPLE
%   x = rand(20,5);
%   c = columns(x)
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-19
% -----------------------------------------------------------------------

% Extract the number of columns from the size vector
[~,c] = size(DATA);
