% Run the VAR Toolbox primer examples.
% =======================================================================
% This script demonstrates VAR estimation and identification via: zero
% short-run and long-run restrictions, sign restrictions, narrative sign
% restrictions, external instruments, and local projections. Replication
% examples: Stock-Watson (2001), Blanchard-Quah (1989), Uhlig (2005),
% Antolin-Diaz and Rubio-Ramirez (2018), and Gertler-Karadi (2015).
% Requires VAR Toolbox 3.1.
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% March 2012. Updated: 2026-05-28
% -----------------------------------------------------------------------

%% 0. PRELIMINARIES
% -----------------------------------------------------------------------
% Resolve the Primer folder and toolbox root from the script location so
% relative file paths work regardless of the folder from which the script
% is launched.
clear; close all; clc
warning off all
format short g
rng(1234);


% Resolve the Primer folder. When running sections (Cmd+Enter), mfilename returns a
% temp-file path rather than the actual script path, so we validate by checking for
% the expected 'data' subfolder and fall back to pwd if the check fails.
path_Primer = fileparts(mfilename('fullpath'));
if ~exist(fullfile(path_Primer,'data'),'dir')
    path_Primer = pwd;
end
if ~exist(fullfile(path_Primer,'data'),'dir')
    error(['VARToolbox_Primer: cannot locate the Primer directory.\n' ...
           'Set your MATLAB current folder to Primer/ before running sections.']);
end
path_Toolbox = fileparts(path_Primer);
addpath(genpath(path_Toolbox))
cd(path_Primer)

%% 1. LOAD AND STORE DATA
% -----------------------------------------------------------------------
% Loads US macro data from Simple_Data.xlsx for the bivariate example.
% The spreadsheet contains three series at quarterly frequency: real GDP
% (gdp), CPI (cpi), and the 1-year Treasury Bill yield (i1yr). Variable
% mnemonics and full labels are read from the header rows; numeric data
% are stored in matrix data, then unpacked into the DATA struct keyed by
% mnemonic for retrieval throughout sections 2–9.

% Load data from the Simple_Data spreadsheet
[xlsdata, xlstext] = xlsread('data/Simple_Data.xlsx','Sheet1');
dates = xlstext(3:end,1);       % vector of dates in string format
datesnum = Date2Num(dates);     % vector of dates in numeric format
vnames_long = xlstext(1,2:end); % full variable names
vnames = xlstext(2,2:end);      % variable mnemonic
nvar = length(vnames);          % number of variables in spreadsheet
data   = Num2NaN(xlsdata);      % matrix of data (zeros replaced by NaN)

% Store each variable in the DATA struct, keyed by mnemonic
for ii=1:length(vnames)
    DATA.(vnames{ii}) = data(:,ii);
end

% Record total number of observations in the spreadsheet (pre-trim)
nobs = size(data,1);

% Helper for bold epsilon shock labels in figure text
bfeps = @(s) ['{\bf\epsilon_{t}^{' s '}}'];

%% 2. TREAT DATA
% -----------------------------------------------------------------------
% Transforms raw series before VAR estimation. Real GDP and CPI are
% log-differenced (temptreat=3) and scaled by 100 to express growth rates
% in percentage points. The 1-year T-Bill yield is first-differenced
% (temptreat=2) without rescaling. Transformed series are written back
% into the DATA struct with a 'd' prefix (dgdp, dcpi, di1yr) and are
% available for variable selection in sections 3–9.

% Variable mnemonics, transformation codes, and rescaling factors
tempnames = {'gdp','cpi','i1yr'};  % variable mnemonics
temptreat = {3, 3, 2};             % transformation: 3=log-diff, 2=diff
tempscale = [100 100 1];           % rescaling factor

% Apply transformation and store in DATA struct with 'd' prefix
for ii=1:length(tempnames)
    aux = {['d' tempnames{ii}]};
    DATA.(aux{1}) = tempscale(ii)*...
        datatreat(DATA.(tempnames{ii}),temptreat{ii});
end
clear temp*

%% 3. VAR ESTIMATION
% -----------------------------------------------------------------------
% Estimates a bivariate VAR in GDP growth (dgdp) and the 1-year T-Bill
% yield (i1yr) with one lag and a constant. Variables are
% assembled into matrix X and aligned to a common sample via CommonSample,
% which strips leading and trailing NaNs and returns the trim indices fo
% and lo. VARmodel returns the estimated VAR struct (companion matrix F,
% residual covariance sigma) and the options struct VARopt. VARprint
% displays OLS coefficients; the coefficient matrix beta is also returned
% for downstream use.

% 3.1 Select variables and plot data
% -----------------------------------------------------------------------
% Select the bivariate variable set, assemble matrix X from the DATA
% struct, and plot the raw series before common-sample trimming.

% Endogenous variable mnemonics and display labels for plots
Xvnames = {'dgdp','i1yr'};
Xvnames_long = {'Real GDP Growth','1-year Int. Rate'};

% Number of endogenous variables
Xnvar = length(Xvnames);

% Assemble matrix X by pulling columns from the DATA struct
X = nan(nobs,Xnvar);
for ii=1:Xnvar
    X(:,ii) = DATA.(Xvnames{ii});
end

% Plot the raw selected series before trimming to common sample
figure;
FigSize(18,6)
for ii=1:Xnvar
    subplot(1,2,ii)
    H(ii) = plot(X(:,ii),'LineWidth',3,'Color',pantone('Blue'));
    title(Xvnames_long(ii),'FontWeight','bold','FontSize',13);
    DatesPlot(datesnum(1),nobs,6,'q') % Set the x-axis labels
    set(gca,'FontSize',11,'Layer','bottom'); grid on;
    set(findobj(gca,'Type','line'),'Clipping','off');
    SetAxesDual(gca);
end

% Save figure and clear canvas for the next plot
SaveFigure('graphics/BIV_DATA')

% 3.2 Estimate VAR
% -----------------------------------------------------------------------
% Trim to a common sample via CommonSample, set the lag order and
% deterministic component, then estimate the VAR by OLS.

% Align variables to a common sample by removing leading/trailing NaNs
[X, fo, lo] = CommonSample(X);

% Trim date vectors to stay aligned with the common-sample data
nobs_cs  = size(X, 1);
dates    = dates(fo+1 : fo+nobs_cs);
datesnum = datesnum(fo+1 : fo+nobs_cs);

% Deterministic component: 1=constant, 2=trend
det = 1;

% Lag order
nlags = 1;

% Estimate VAR by OLS
[VAR, VARopt] = VARmodel(X,nlags,det);

% 3.3 Inspect results
% -----------------------------------------------------------------------
% Display the estimated VAR struct fields on screen and print the OLS
% coefficient table.

% Display estimated VAR struct fields, companion matrix, and residual covariance
format short
disp(VAR)
disp(VAR.F)
disp(VAR.sigma)
disp(VARopt)

% Add variable labels to VARopt before printing the coefficient table
VARopt.vnames = Xvnames_long;

% Print OLS coefficient table and return the raw beta matrix
[TABLE, beta] = VARprint(VAR,VARopt,2);

%% 4. IDENTIFICATION WITH ZERO CONTEMPORANEOUS RESTRICTIONS
% -----------------------------------------------------------------------
% Cholesky identification imposes a recursive causal ordering: GDP growth
% is ordered first (contemporaneously exogenous to the interest rate) and
% the 1-year yield is ordered second. Setting VARopt.ident = 'short'
% instructs VARir to compute the lower-triangular Cholesky factor of the
% residual covariance matrix as the impact matrix B. The demand shock is
% shock 1 and the MP shock is shock 2. Structural shocks eps_short are
% recovered as B^{-1} * resid and are orthogonal by construction.

% 4.1 Identification setup
% -----------------------------------------------------------------------
% Select Cholesky identification and populate VARopt with IRF horizon,
% figure settings, date labels, frequency, and shock names.

% Select zero short-run (Cholesky) identification
VARopt.ident = 'short';

% IRF horizon, figure options, date labels, frequency, and shock names
VARopt.vnames = Xvnames_long;            % variable names in plots
VARopt.nsteps = 20;                      % max horizon of IRF
VARopt.FigSize = [18,6];                 % size of window (figures)
VARopt.firstdate = datesnum(1);          % first date in plots
VARopt.frequency = 'q';                  % frequency of the data
VARopt.snames = {bfeps('Demand'), bfeps('MonPol')}; % shock names
VARopt.figname = 'graphics/short';

% 4.2 Impulse responses
% -----------------------------------------------------------------------
% Compute IRFs with VARir, plot the MP shock, and display B with the
% first four rows of the MP shock IRF.

% Compute impulse responses and plot the MP shock (pick=2)
[IR, VAR] = VARir(VAR,VARopt);
VARopt.pick = 2;
VARirplot(IR,VARopt);

% Display impact matrix B and first four rows of the MP shock IRF
format short
disp(VAR.B)
disp(IR(1:4,:,2))

% 4.3 Structural shocks
% -----------------------------------------------------------------------
% Recover structural shocks as B^{-1} * resid and verify orthogonality
% via the correlation matrix.

% Recover structural shocks as B^{-1} * reduced-form residuals; verify orthogonality
eps_short = (VAR.B\VAR.resid')';
disp(corr(eps_short))

%% 5. IDENTIFICATION WITH ZERO LONG-RUN RESTRICTIONS
% -----------------------------------------------------------------------
% Blanchard-Quah identification (Blanchard and Quah, 1989) restricts the
% long-run cumulative response of GDP growth to the MP shock to zero,
% embodying long-run monetary neutrality. Setting VARopt.ident = 'long'
% instructs VARir to compute B by lower-triangular factorisation of the
% long-run covariance (eye - Fcomp)^{-1} * sigma * (eye - Fcomp)^{-T}.
% Supply and demand shocks are shock 1 and 2 respectively. The restriction
% is verified by extending the horizon to 150 quarters and plotting the
% cumulative GDP response, which should converge to zero.

% 5.1 Identification and impulse responses
% -----------------------------------------------------------------------
% Select long-run identification and compute IRFs. Display B and the
% long-run multiplier matrix (eye - F)^{-1} * B.

% Select zero long-run (Blanchard-Quah) identification
VARopt.ident = 'long';

% Update shock names and figure path; nsteps and other options carry over from section 4
VARopt.snames = {bfeps('Supply'), bfeps('MonPol')}; % shock names; MP: zero long-run effect on GDP (monetary neutrality)
VARopt.figname = 'graphics/long';

% Compute impulse responses and bootstrap bands; plot the MP shock (pick=2)
[IR, VAR] = VARir(VAR,VARopt);
[IRinf, IRsup, ~, IRbar] = VARirband(VAR,VARopt);
VARopt.pick = 2;
VARirplot(IR,VARopt);

% Display impact matrix B and the long-run multiplier matrix (eye - F)^{-1} * B
format short
disp(VAR.B)
disp((eye(2)-VAR.Fcomp)\VAR.B)

% 5.2 Verify long-run restriction
% -----------------------------------------------------------------------
% Re-compute IRFs at 150 quarters, plot cumulative responses to the MP
% shock (should converge to zero for GDP growth), and recover structural
% shocks under long-run identification.

% Extend horizon to 150 quarters to verify the long-run zero restriction visually
VARopt.nsteps = 150;
[IR, VAR] = VARir(VAR,VARopt);
figure;
FigSize(18,6)
subplot(1,2,1)
plot(cumsum(IR(:,1,2)),'LineWidth',4,'Color',[rgb('gray') 0.8]); hold on
plot(zeros(VARopt.nsteps),'-k','LineWidth',0.5); hold on
xlim([1 VARopt.nsteps]);
title(['Real GDP level to ' bfeps('MonPol')],'FontWeight','bold','FontSize',13);
set(gca,'FontSize',11,'Layer','bottom'); grid on
set(findobj(gca,'Type','line'),'Clipping','off');
SetAxesDual(gca);
subplot(1,2,2)
plot(cumsum(IR(:,2,2)),'LineWidth',4,'Color',[rgb('gray') 0.8]); hold on
plot(zeros(VARopt.nsteps),'-k','LineWidth',0.5); hold on
xlim([1 VARopt.nsteps]);
title(['Cumulative 1-year rate to ' bfeps('MonPol')],'FontWeight','bold','FontSize',13);
set(gca,'FontSize',11,'Layer','bottom'); grid on
set(findobj(gca,'Type','line'),'Clipping','off');
SetAxesDual(gca);
SaveFigure('graphics/longCum');
% Recover structural shocks under long-run identification
eps_long = (VAR.B\VAR.resid')';

%% 6. IDENTIFICATION WITH SIGN RESTRICTIONS
% -----------------------------------------------------------------------
% Set-identification via sign restrictions (Uhlig, 2005): demand shocks
% raise both GDP growth and the interest rate; MP shocks lower GDP growth
% and raise the interest rate. Restrictions are encoded in R as +1
% (positive), -1 (negative), or 0 (unrestricted) for each variable-shock
% pair. SR draws ndraws=1000 random rotations from the space of orthogonal
% matrices and retains those consistent with R over sr_hor=1 horizon.
% Results include all accepted IRs (SRout.IRall), the pointwise median
% (SRout.IRmed), and the Fry-Pagan median-target rotation (SRout.IR).

% 6.1 Define restrictions and identify
% -----------------------------------------------------------------------
% Encode sign restrictions in R and run SR to generate accepted
% orthogonal rotations. Print acceptance rate as a diagnostic.

% Sign restriction matrix: positive 1, negative -1, unrestricted 0
R = [ 1, -1;  % Real GDP
      1,  1]; % 1-year rate

% Number of random draws and restriction horizon
VARopt.ndraws = 1000;
VARopt.sr_hor = 1;

% IRF horizon, figure size, and shock names
VARopt.nsteps = 20; % horizon of impulse responses
VARopt.FigSize = [18, 6]; % size of window (figures)
VARopt.snames = {bfeps('Demand'), bfeps('MonPol')}; % shock names

% Run sign restrictions identification; print acceptance rate as a diagnostic
SRout = SR(VAR,R,VARopt);
disp(['Acceptance rate: ' num2str(100*SRout.accept_rate,'%.1f') '% of draws accepted'])

% 6.2 Identification uncertainty: all accepted rotations
% -----------------------------------------------------------------------
% Plot IRF swathes across the first 250 accepted draws to illustrate the
% width of the identified set for the MP shock.

% Plot all rotations for MP shock
figure;
FigSize(18,6)
subplot(1,2,1)
plot(squeeze(SRout.IRall(:,1,2,1:250))); hold on
plot(zeros(VARopt.nsteps),'-k','LineWidth',0.5); hold on
xlim([1 VARopt.nsteps]);
title(['RealGDP growth to ' bfeps('MonPol')],'FontWeight','bold','FontSize',13,'Interpreter','tex');
set(gca,'FontSize',11,'Layer','bottom'); grid on
set(findobj(gca,'Type','line'),'Clipping','off');
SetAxesDual(gca);
subplot(1,2,2)
plot(squeeze(SRout.IRall(:,2,2,1:250))); hold on
plot(zeros(VARopt.nsteps),'-k','LineWidth',0.5); hold on
xlim([1 VARopt.nsteps]);
title(['1-year rate to ' bfeps('MonPol')],'FontWeight','bold','FontSize',13,'Interpreter','tex');
set(gca,'FontSize',11,'Layer','bottom'); grid on
set(findobj(gca,'Type','line'),'Clipping','off');
SetAxesDual(gca);
SaveFigure('graphics/signAll');

% 6.3 Median vs Fry-Pagan rotation
% -----------------------------------------------------------------------
% Compare the pointwise median rotation with the Fry-Pagan median-target
% rotation, then recover structural shocks using SRout.B.

% Plot MP shock only: compare pointwise median with Fry-Pagan rotation
VARopt.pick = 2;
figure;
FigSize(18,6)
for ii=1:Xnvar
    subplot(1,2,ii);
    plot(SRout.IRmed(:,ii,VARopt.pick),'LineStyle','-','Color',pantone('Blue'),'LineWidth',2,'Marker','o','MarkerSize',7,'MarkerFaceColor',0.5*pantone('Blue')+0.5*[1 1 1],'MarkerEdgeColor',pantone('Blue')); hold on;
    plot(SRout.IR(:,ii,VARopt.pick),'LineStyle','-','Color',pantone('Tomato'),'LineWidth',2,'Marker','o','MarkerSize',7,'MarkerFaceColor',0.5*pantone('Tomato')+0.5*[1 1 1],'MarkerEdgeColor',pantone('Tomato')); hold on;
    plot(zeros(1,VARopt.nsteps),'-k','LineWidth',0.5); hold on
    xlim([1 VARopt.nsteps]);
    title([Xvnames_long{ii} ' to ' VARopt.snames{VARopt.pick}], ...
        'FontWeight','bold','FontSize',13);
    set(gca, 'FontSize', 11, 'Layer', 'bottom'); grid on
    set(findobj(gca,'Type','line'),'Clipping','off');
    SetAxesDual(gca);
end
legend({'Median','Median target'},'Location','northeast')
SaveFigure('graphics/signFP')
% Recover structural shocks using the Fry-Pagan median-target rotation (SRout.B)
eps_sign = (SRout.B\VAR.resid')';

%% 7. IDENTIFICATION WITH NARRATIVE SIGN RESTRICTIONS
% -----------------------------------------------------------------------
% Narrative sign restrictions (Antolin-Diaz and Rubio-Ramirez, 2018)
% augment sign restrictions with additional constraints tied to specific
% historical episodes. R from section 6 is combined with narrative
% restrictions in a struct R with R.sign, narr_sign, and narr_dom fields.
% Four restrictions across two episodes: (1-2) 1994q1 — Greenspan's first
% hike in five years (Feb 4, 1994): MP shock positive and dominant driver of
% i1yr; (3-4) 2001q1 — January 3 unscheduled inter-meeting cut: MP shock
% negative and dominant driver of i1yr. Periods are specified as date strings.

% Clear previous section restrictions
clear R


% 7.1 Sign and narrative restrictions
% -----------------------------------------------------------------------
% Build R struct combining sign restrictions from section 6 with narrative
% restrictions. Sign of the MP shock at each episode: positive at 1994q1
% (Greenspan's Feb 1994 hike) and negative at 2001q1 (unscheduled
% inter-meeting cut). Dominant-driver restriction applied at 1994q1 only.

% Sign restrictions
R.sign = [ 1, -1;  % Real GDP
           1,  1]; % 1-year rate

% Sign of MP shock for both episodes
R.narr_sign.shock  = [2;        2      ];
R.narr_sign.period = {'1994q1'; '2001q1'};
R.narr_sign.sign   = [1;       -1      ];

% MP shock is the dominant driver of i1yr only in 1994q1
R.narr_dom.shock  = [2;        ];
R.narr_dom.period = {'1994q1'; };
R.narr_dom.var    = [2;        ];

% Set options for the sign restriction routine
VARopt.sr_draw = 500000;
VARopt.dates   = dates; % date strings aligned with the VAR data
VARopt.FigSize = [18, 6];
VARopt.snames  = {bfeps('Demand'), bfeps('MonPol')};

% Run SR routine with narrative restrictions; print acceptance rate as a diagnostic
NSRout = SR(VAR, R, VARopt);
disp(['Acceptance rate (sign + narrative): ' num2str(100*NSRout.accept_rate,'%.1f') '% of draws accepted'])

% 7.2 Accepted draws: sign only vs sign + narrative
% -----------------------------------------------------------------------
% Plot the full range (min/max) as a shaded swathe across all accepted
% draws in their raw units. The swathe width is the identification
% uncertainty; narrative restrictions shrink it.

% Median and min/max band across all accepted draws (raw, no normalization)
VARopt.pick  = 2;
IRall_SR     = SRout.IRall(:,:,VARopt.pick,:);
IRall_NSR    = NSRout.IRall(:,:,VARopt.pick,:);

IRmed_SR  = median(IRall_SR,  4);
IRinf_SR  = min(IRall_SR,  [], 4);
IRsup_SR  = max(IRall_SR,  [], 4);
IRmed_NSR = median(IRall_NSR, 4);
IRinf_NSR = min(IRall_NSR, [], 4);
IRsup_NSR = max(IRall_NSR, [], 4);

% Swathe options: swatheonly=1 suppresses the built-in line; median plotted
% separately below to match the marker style used throughout the Primer.
% Transparent swathes (transp=1) show the overlap; renderer is switched
% back to painters before the marker lines are drawn so fill color matches.
SwatheOpt_SR = PlotSwatheOption;
SwatheOpt_SR.swathecol    = pantone('Blue');
SwatheOpt_SR.swatheonly   = 1;
SwatheOpt_SR.transp       = 1;
SwatheOpt_SR.alpha        = 0.15;
SwatheOpt_SR.border       = 1;
SwatheOpt_SR.borderstyle  = '--';

SwatheOpt_NSR = PlotSwatheOption;
SwatheOpt_NSR.swathecol   = pantone('Tomato');
SwatheOpt_NSR.swatheonly  = 1;
SwatheOpt_NSR.transp      = 1;
SwatheOpt_NSR.alpha       = 0.30;
SwatheOpt_NSR.border      = 1;
SwatheOpt_NSR.borderstyle = '-.';

% Swathes first (bottom layer), then median lines on top.
% Renderer is reset to painters after the swathes so markers render
% consistently with the rest of the Primer.
figure;
FigSize(18,6)
for ii = 1:Xnvar
    subplot(1,2,ii)
    PlotSwathe(IRmed_SR(:,ii,1),  [IRinf_SR(:,ii,1)  IRsup_SR(:,ii,1)],  SwatheOpt_SR);
    hold on
    PlotSwathe(IRmed_NSR(:,ii,1), [IRinf_NSR(:,ii,1) IRsup_NSR(:,ii,1)], SwatheOpt_NSR);
    set(gcf, 'renderer', 'painters')
    H1 = plot(IRmed_SR(:,ii,1),  'LineStyle', '-', 'Color', pantone('Blue'), 'LineWidth', 2, ...
        'Marker', 'o', 'MarkerSize', 7, 'MarkerFaceColor', 0.5*pantone('Blue')+0.5*[1 1 1], 'MarkerEdgeColor', pantone('Blue'));
    H2 = plot(IRmed_NSR(:,ii,1), 'LineStyle', '-', 'Color', pantone('Tomato'), 'LineWidth', 2, ...
        'Marker', 'o', 'MarkerSize', 7, 'MarkerFaceColor', 0.5*pantone('Tomato')+0.5*[1 1 1], 'MarkerEdgeColor', pantone('Tomato'));
    plot(zeros(1,VARopt.nsteps), '-k', 'LineWidth', 0.5)
    xlim([1 VARopt.nsteps])
    title([Xvnames_long{ii} ' to ' VARopt.snames{VARopt.pick}], ...
        'FontWeight', 'bold', 'FontSize', 13)
    set(gca, 'FontSize', 11, 'Layer', 'bottom'); grid on
    if ii == 1
        legend([H1 H2], {'Sign only', 'Sign + Narrative'}, ...
               'Location', 'southeast')
    end
    set(findobj(gca,'Type','line'),'Clipping','off');
    SetAxesDual(gca);
end
SaveFigure('graphics/narr')

% 7.3 Distribution of MP shocks at narrative episodes
% -----------------------------------------------------------------------
% Compare the distribution of the MP shock across accepted draws at each
% narrative episode: sign-only (pantone('Blue')) vs sign + narrative (pantone('Tomato')).

% Collect MP shock at both narrative episodes across all accepted draws
mp_shock  = 2;
t_narr    = [find(strcmp(dates,'1994q1')), find(strcmp(dates,'2001q1'))] - nlags;
ep_labels = {'1994q1 (Feb 1994 hike)', '2001q1 (Jan 2001 cut)'};

ndraws_SR  = size(SRout.Ball, 3);
shocks_SR  = zeros(ndraws_SR, 2);
for dd = 1:ndraws_SR
    e_d = SRout.Ball(:,:,dd) \ VAR.resid';
    shocks_SR(dd,:) = e_d(mp_shock, t_narr);
end

% Repeat for sign + narrative draws
ndraws_NSR  = size(NSRout.Ball, 3);
shocks_NSR  = zeros(ndraws_NSR, 2);
for dd = 1:ndraws_NSR
    e_d = NSRout.Ball(:,:,dd) \ VAR.resid';
    shocks_NSR(dd,:) = e_d(mp_shock, t_narr);
end

% Plot MP shock distributions at each episode
figure;
FigSize(18,6)
for ii = 1:2
    subplot(1,2,ii)
    histogram(shocks_SR(:,ii),   30, 'FaceColor', pantone('Blue'), 'FaceAlpha', 0.6, 'EdgeColor', 'white')
    hold on
    histogram(shocks_NSR(:,ii), 30, 'FaceColor', pantone('Tomato'), 'FaceAlpha', 0.7, 'EdgeColor', 'white')
    xline(0, '-k', 'LineWidth', 0.5)
    xlabel('MP shock')
    ylabel('Count')
    title(ep_labels{ii},'FontWeight','bold','FontSize',13)
    set(gca,'FontSize',11,'Layer','bottom'); grid on
    if ii == 1
        legend({'Sign only','Sign + Narrative'},'Location','northwest')
    end
    set(findobj(gca,'Type','line'),'Clipping','off');
    SetAxesDual(gca);
end
SaveFigure('graphics/narr_ShockDist')

%% 8. IDENTIFICATION WITH EXTERNAL INSTRUMENTS
% -----------------------------------------------------------------------
% Proxy SVAR (Stock and Watson, 2012; Mertens and Ravn, 2013): the
% external instrument must be correlated with the target shock (relevance)
% and orthogonal to all other structural shocks (exogeneity). Setting
% VARopt.ident = 'iv' instructs VARir to estimate B via IV regression of
% reduced-form residuals on the instrument. An artificial instrument is
% constructed here as the sign-restriction MP shock (eps_sign(:,2)) plus
% standard normal noise, so it is relevant but imperfect. After VARir, the
% first column of B identified by the instrument is stored in VAR.Biv,
% which is used in section 9 to condition the hybrid identification.

% 8.1 Construct instrument and compute impulse responses
% -----------------------------------------------------------------------
% Build the artificial proxy, attach it to VAR.IV, and run VARir with
% ident='iv'. The identified MP column is stored in VAR.Biv for section 9.

% Construct the artificial instrument: sign-restriction MP shock plus white noise
noise = randn(nobs,1);              % random vector from N(0,1)
noise = noise(1+fo:end-lo);         % adjust to common sample
mps = [NaN; eps_sign(:,2)] + noise; % add noise to MP shock from sign restrictions
VAR.IV = mps;                       % attach instrument to VAR struct

% Set identification to 'iv' and assign shock names for IRF plots
VARopt.ident  = 'iv';
VARopt.snames = {bfeps('MonPol'), bfeps('Other')};

% Compute impulse responses with IV identification
[IR, VAR] = VARir(VAR,VARopt);

% 8.2 Plot impulse responses
% -----------------------------------------------------------------------
% Plot IRFs with a circle marker along the path and a pentagon marker at
% the impact horizon.

% Plot IRs: circle marker on the line, pentagon marker highlighting the impact response
figure;
FigSize(18,6)
for ii=1:Xnvar
    subplot(1,2,ii);
	plot(IR(:,ii),'LineStyle','-','Color',pantone('Blue'),'LineWidth',2,'Marker','o','MarkerSize',7,'MarkerFaceColor',0.5*pantone('Blue')+0.5*[1 1 1],'MarkerEdgeColor',pantone('Blue')); hold on;
    plot(zeros(1,VARopt.nsteps),'-k','LineWidth',0.5); hold on
    plot(1,IR(1,ii),'LineStyle','-','Color',pantone('Tomato'),'LineWidth',2,...
        'Marker','p','MarkerSize',10,'MarkerFaceColor',pantone('Tomato')); hold on
    xlim([1 VARopt.nsteps]);
    title([Xvnames_long{ii} ' to ' VARopt.snames{1}], ...
        'FontWeight','bold','FontSize',13);
    set(gca, 'FontSize', 11, 'Layer', 'bottom'); grid on
    set(findobj(gca,'Type','line'),'Clipping','off');
    SetAxesDual(gca);
end
SaveFigure('graphics/iv')

%% 9. IDENTIFICATION WITH EXTERNAL INSTRUMENTS AND SIGN RESTRICTIONS
% -----------------------------------------------------------------------
% Hybrid identification combines the external instrument from section 8
% with sign restrictions. The MP shock's impact vector (first column of B)
% is already pinned down by the instrument and stored in VAR.Biv. SR reads
% VAR.Biv and rotates only in the orthogonal complement, imposing sign
% restrictions on the remaining shocks. Here a single sign restriction
% identifies the demand shock: both GDP growth and the interest rate
% respond positively. VARopt.pick = 2 selects the demand shock for plotting.

% 9.1 Set sign restrictions and identify
% -----------------------------------------------------------------------
% Define sign restrictions for the demand shock and run SR conditioned on
% the IV-identified MP column VAR.Biv. SR rotates only in the orthogonal
% complement of the already-identified column.

% Display the IV-identified first column of B as a reference
disp(VAR.Biv)

% Sign restriction for the demand shock (conditional on the MP column from IV)
% Positive 1, Negative -1, Unrestricted 0:
R = [ 1;  % Real GDP: positive
      1]; % 1-year rate: positive

% Figure path and shock names; SR reads VAR.Biv to condition on the IV column
VARopt.figname = 'graphics/iv_sign';
VARopt.snames = {bfeps('MonPol'), bfeps('Demand')};

% Run SR with VAR.Biv pre-filled; remaining rotation is in the orthogonal complement
SRIVout = SR(VAR,R,VARopt);

% 9.2 Plot demand shock
% -----------------------------------------------------------------------
% Plot the Fry-Pagan median-target demand shock IRF.

% Plot the demand shock IRF (shock 2)
VARopt.pick = 2;
VARirplot(SRIVout.IRmed,VARopt);

%% 10. LOCAL PROJECTIONS
% -----------------------------------------------------------------------
% Local projections (LP, Jorda 2005) provide an alternative way to estimate
% impulse response functions. For each horizon h, LP runs the regression:
%
%   y_{t+h} = alpha_h + beta_h * s_t + gamma_h * w_t + e_{t+h}
%
% where s_t is the shock of interest and w_t are control variables (here,
% one lag of the bivariate X). The sequence of beta_h coefficients is the
% impulse response. Confidence bands use Newey-West standard errors.
%
% We compare two approaches, both using the artificial instrument mps
% constructed in Section 8:
%   (A) LP:        LP with mps as shock S and lags of X as controls
%   (B) Exog-SVAR: bivariate VAR re-estimated with mps as a contemporaneous
%                  exogenous variable, identified with ident='exog'
%
% Both point estimates and 90% confidence bands are plotted. LP bands are
% computed from Newey-West standard errors; SVAR bands from a residual
% bootstrap. LP bands tend to be wider than VAR bands because each horizon
% is estimated by an independent regression, accumulating estimation error
% that the VAR propagates through a common dynamic model.

% 10.1 Set up LP options
% -----------------------------------------------------------------------
% Initialize LPopt with defaults, then match horizon and lag order to the
% VAR, include a constant, set bivariate X as lag controls, and request
% 90% Newey-West confidence bands.
LPopt          = LPoption;
LPopt.nsteps   = VARopt.nsteps; % match VAR horizon
LPopt.nlag     = nlags;         % match VAR lag order (=1)
LPopt.const    = det;           % include constant (det=1)
LPopt.LAGS     = X;             % bivariate X as lag controls
LPopt.pctg     = 90;            % 90% confidence bands

% 10.2 Run LP for each endogenous variable
% -----------------------------------------------------------------------
% Loop over endogenous variables and call LP, storing the point estimate
% and 90% confidence bands for each.
LP_IR  = nan(LPopt.nsteps, Xnvar);
LP_INF = nan(LPopt.nsteps, Xnvar);
LP_SUP = nan(LPopt.nsteps, Xnvar);
for ii = 1:Xnvar
    [LP_IR(:,ii), LPout.(Xvnames{ii}), LP_INF(:,ii), LP_SUP(:,ii)] = LPmodel(X(:,ii), mps, LPopt);
end

% 10.3 Exog-SVAR: re-estimate VAR with instrument as exogenous variable
% -----------------------------------------------------------------------
% Re-estimate the VAR with mps as a contemporaneous exogenous regressor
% (nlag_ex=0). Its coefficient vector across equations becomes the first
% column of B under ident='exog'. Bootstrap 90% bands with 1000 draws.
[VAR_exog, VARopt_exog] = VARmodel(X, nlags, det, mps, 0);
VARopt_exog.vnames    = Xvnames_long;
VARopt_exog.nsteps    = VARopt.nsteps;
VARopt_exog.FigSize   = VARopt.FigSize;
VARopt_exog.firstdate = VARopt.firstdate;
VARopt_exog.frequency = VARopt.frequency;
VARopt_exog.ident     = 'exog';
VARopt_exog.snames    = {bfeps('MonPol')};
VARopt_exog.pctg      = 90;    % 90% confidence bands, matching LP
VARopt_exog.ndraws    = 1000;  % bootstrap draws
VARopt_exog.method    = 'bs';  % residual bootstrap
[IR_exog, VAR_exog]   = VARir(VAR_exog, VARopt_exog);

% Bootstrap confidence bands for Exog-SVAR
[INF_exog, SUP_exog, MED_exog, ~] = VARirband(VAR_exog, VARopt_exog);

% 10.4 Plot: LP vs Exog-SVAR with 90% confidence bands
% -----------------------------------------------------------------------
% Swathe options: swatheonly=1 suppresses the built-in line; median plotted
% separately below to match the marker style used throughout the Primer.
% Transparent swathes (transp=1) show overlap; renderer is switched back to
% painters before the marker lines are drawn so fill color matches.
SwatheOpt_LP = PlotSwatheOption;
SwatheOpt_LP.swathecol    = pantone('Blue');
SwatheOpt_LP.swatheonly   = 1;
SwatheOpt_LP.transp       = 1;
SwatheOpt_LP.alpha        = 0.15;
SwatheOpt_LP.border       = 1;
SwatheOpt_LP.borderstyle  = '--';

SwatheOpt_EX = PlotSwatheOption;
SwatheOpt_EX.swathecol    = pantone('Tomato');
SwatheOpt_EX.swatheonly   = 1;
SwatheOpt_EX.transp       = 1;
SwatheOpt_EX.alpha        = 0.30;
SwatheOpt_EX.border       = 1;
SwatheOpt_EX.borderstyle  = '-.';

% Swathes first (bottom layer), then point-estimate lines on top.
figure;
FigSize(VARopt_exog.FigSize(1), VARopt_exog.FigSize(2))
for ii = 1:Xnvar
    subplot(1, Xnvar, ii)
    PlotSwathe(LP_IR(:,ii),         [LP_INF(:,ii)        LP_SUP(:,ii)],        SwatheOpt_LP);
    hold on
    PlotSwathe(MED_exog(:,ii,1),    [INF_exog(:,ii,1)    SUP_exog(:,ii,1)],    SwatheOpt_EX);
    set(gcf, 'renderer', 'painters')
    H1 = plot(LP_IR(:,ii), 'LineStyle', '-', 'Color', pantone('Blue'), 'LineWidth', 2, ...
        'Marker', 'o', 'MarkerSize', 7, 'MarkerFaceColor', 0.5*pantone('Blue')+0.5*[1 1 1], 'MarkerEdgeColor', pantone('Blue'));
    H2 = plot(MED_exog(:,ii,1), 'LineStyle', '-', 'Color', pantone('Tomato'), 'LineWidth', 2, ...
        'Marker', 'o', 'MarkerSize', 7, 'MarkerFaceColor', 0.5*pantone('Tomato')+0.5*[1 1 1], 'MarkerEdgeColor', pantone('Tomato'));
    plot(zeros(1,LPopt.nsteps), '-k', 'LineWidth', 0.5)
    xlim([1 LPopt.nsteps])
    title([Xvnames_long{ii} ' to ' bfeps('MonPol')], 'FontWeight', 'bold', 'FontSize', 13)
    set(gca, 'FontSize', 11, 'Layer', 'bottom'); grid on
    if ii == Xnvar
        legend([H1 H2], {'LP (NW)', 'SVAR-Exog (Bootstrap)'}, ...
               'Location', 'southwest')
    end
    set(findobj(gca,'Type','line'),'Clipping','off');
    SetAxesDual(gca);
end
SaveFigure('graphics/LP')

%% 11. STOCK AND WATSON (2001)
% -----------------------------------------------------------------------
% Zero contemporaneous restrictions identification example based on the
% replication of Stock and Watson (2001, JEP).
%{

% 11.1 Load data from Stock and Watson
% -----------------------------------------------------------------------
% Load SW2001 trivariate dataset (inflation, unemployment, fed funds rate)
% at quarterly frequency. Same header convention as section 1.
[xlsdata, xlstext] = xlsread('data/SW2001_Data.xlsx','Sheet1');
dates = xlstext(3:end,1);
datesnum = Date2Num(dates);
vnames_long = xlstext(1,2:end);
vnames = xlstext(2,2:end);
nvar = length(vnames);
data   = Num2NaN(xlsdata);
for ii=1:length(vnames)
    DATA.(vnames{ii}) = data(:,ii);
end
nobs = size(data,1);

% 11.2 Plot series
% -----------------------------------------------------------------------
% Plot all three variables at quarterly frequency with date labels.
figure;
FigSize(27,6)
for ii=1:nvar
    subplot(1,3,ii)
    plot(DATA.(vnames{ii}),'LineWidth',3,'Color',pantone('Blue'));
    title(vnames_long(ii),'FontWeight','bold','FontSize',13);
    DatesPlot(datesnum(1),nobs,6,'q') % Set the x-axis label dates
    set(gca,'FontSize',11); grid on;
    SetAxesDual(gca);
end
SaveFigure('graphics/SW_DATA')

% 11.3 Set up and estimate VAR
% -----------------------------------------------------------------------
% Trivariate VAR in inflation, unemployment, and the fed funds rate with
% 4 lags and a constant. Horizon set to 24 quarters.

% Select endogenous variables
Xvnames      = {'infl','unemp','ff'};
Xvnames_long = {'Inflation','Unemployment','Fed Funds'};
Xnvar        = length(Xvnames);

% Assemble data matrix X from DATA struct
X = nan(nobs,Xnvar);
for ii=1:Xnvar
    X(:,ii) = DATA.(Xvnames{ii});
end

% Estimate VAR: 4 lags, constant
det = 1;
nlags = 4;
[VAR, VARopt] = VARmodel(X,nlags,det);

% Populate VARopt for IRF plots
VARopt.vnames = Xvnames_long;
VARopt.nsteps = 24;
VARopt.FigSize = [27, 6];
VARopt.firstdate = datesnum(1);
VARopt.frequency = 'q';
VARopt.subplot = [1,3];
VARopt.figname = 'graphics/SW_';
VARopt.shorttitle = 1;

% 11.4 Impulse responses
% -----------------------------------------------------------------------
% Cholesky identification (ident='short'): MP shock ordered last. Compute
% IRFs and bootstrap bands, then plot all shocks.

% Select Cholesky identification; MP shock ordered third
VARopt.ident = 'short';
VARopt.snames = {bfeps('1'), bfeps('2'), bfeps('MonPol')};

% Compute IRFs and bootstrap confidence bands
[IR, VAR] = VARir(VAR,VARopt);
[IRinf,IRsup,IRmed,IRbar] = VARirband(VAR,VARopt);

% Plot all shock IRFs
VARirplot(IRbar,VARopt,IRinf,IRsup);
%}

%% 12. BLANCHARD AND QUAH (1989)
% -----------------------------------------------------------------------
% Zero long-run restrictions identification example based on the
% replication of Blanchard and Quah (1989, AER).
%{

% 12.1 Load data from Blanchard and Quah
% -----------------------------------------------------------------------
% Load BQ1989 bivariate dataset (GDP growth and unemployment) at quarterly
% frequency. Same header convention as section 1.
[xlsdata, xlstext] = xlsread('data/BQ1989_Data.xlsx','Sheet1');
dates = xlstext(3:end,1);
datesnum = Date2Num(dates);
vnames_long = xlstext(1,2:end);
vnames = xlstext(2,2:end);
nvar = length(vnames);
data   = Num2NaN(xlsdata);
for ii=1:length(vnames)
    DATA.(vnames{ii}) = data(:,ii);
end
year = str2double(xlstext{3,1}(1:4));
quarter = str2double(xlstext{3,1}(6));
nobs = size(data,1);

% 12.2 Plot series
% -----------------------------------------------------------------------
% Plot both variables at quarterly frequency with date labels.
figure;
FigSize(18,6)
for ii=1:nvar
    subplot(1,2,ii)
    plot(DATA.(vnames{ii}),'LineWidth',3,'Color',pantone('Blue'));
    title(vnames_long(ii),'FontWeight','bold','FontSize',13);
    DatesPlot(datesnum(1),nobs,6,'q') % Set the x-axis label
    set(gca,'FontSize',11); grid on;
    SetAxesDual(gca);
end
SaveFigure('graphics/BQ_DATA')

% 12.3 Set up and estimate VAR
% -----------------------------------------------------------------------
% Bivariate VAR in GDP growth and unemployment with 8 lags and a constant.
% Horizon set to 40 quarters to verify long-run restrictions in section 12.4.

% Select endogenous variables
Xvnames      = {'y','u'};
Xvnames_long = {'GDP growth','Unemployment'};
Xnvar        = length(Xvnames);

% Assemble data matrix X from DATA struct
X = nan(nobs,Xnvar);
for ii=1:Xnvar
    X(:,ii) = DATA.(Xvnames{ii});
end

% Estimate VAR: 8 lags, constant
det = 1;
nlags = 8;
[VAR, VARopt] = VARmodel(X,nlags,det);

% Populate VARopt for IRF plots
VARopt.vnames = Xvnames_long;
VARopt.nsteps = 40;
VARopt.FigSize = [18,6];
VARopt.firstdate = datesnum(1);
VARopt.frequency = 'q';
VARopt.figname = 'graphics/BQ_';
VARopt.shorttitle = 1;

% 12.4 Impulse responses
% -----------------------------------------------------------------------
% Blanchard-Quah identification (ident='long'): supply shock has no
% long-run effect on unemployment; demand shock has no long-run effect
% on GDP. Compute IRFs and bootstrap bands, then plot all shocks.

% Select long-run identification; supply shock ordered first
VARopt.ident = 'long';
VARopt.snames = {bfeps('Supply'), bfeps('Demand')};

% Compute IRFs and bootstrap confidence bands
[IR, VAR] = VARir(VAR,VARopt);
[IRinf,IRsup,IRmed,IRbar] = VARirband(VAR,VARopt);

% Plot all shock IRFs
VARirplot(IRbar,VARopt,IRinf,IRsup);

% 12.5 Replicate Figure 1 of Blanchard and Quah
% -----------------------------------------------------------------------
% Panel (a): cumulative GDP response and unemployment response to the supply
% shock. Panel (b): same responses to the demand shock, sign-flipped to
% match the BQ sign convention (negative demand shock).
figure;
FigSize(18,6)
steps  = 1:1:VARopt.nsteps;
x_axis = zeros(1,VARopt.nsteps);
col_gdp  = pantone('Blue');
col_unem = pantone('Tomato');

% Plot supply shock
subplot(1,2,1)
plot(steps,cumsum(IR(:,1,1)),'LineStyle','-','Color',col_gdp, 'LineWidth',2,'Marker','o','MarkerSize',7,'MarkerFaceColor',0.5*col_gdp +0.5*[1 1 1],'MarkerEdgeColor',col_gdp ); hold on
plot(steps,IR(:,2,1),        'LineStyle','-','Color',col_unem,'LineWidth',2,'Marker','o','MarkerSize',7,'MarkerFaceColor',0.5*col_unem+0.5*[1 1 1],'MarkerEdgeColor',col_unem); hold on
plot(x_axis,'-k','LineWidth',0.5); hold on
xlim([1 VARopt.nsteps]);
title('Supply shock','FontWeight','bold','FontSize',13);
set(gca,'FontSize',11,'Layer','bottom'); grid on
legend({'GDP Level';'Unemployment'})
SetAxesDual(gca);

% Plot demand shock
subplot(1,2,2)
plot(steps,cumsum(-IR(:,1,2)),'LineStyle','-','Color',col_gdp, 'LineWidth',2,'Marker','o','MarkerSize',7,'MarkerFaceColor',0.5*col_gdp +0.5*[1 1 1],'MarkerEdgeColor',col_gdp ); hold on
plot(steps,-IR(:,2,2),        'LineStyle','-','Color',col_unem,'LineWidth',2,'Marker','o','MarkerSize',7,'MarkerFaceColor',0.5*col_unem+0.5*[1 1 1],'MarkerEdgeColor',col_unem); hold on
plot(x_axis,'-k','LineWidth',0.5); hold on
xlim([1 VARopt.nsteps]);
title('Demand shock','FontWeight','bold','FontSize',13);
set(gca,'FontSize',11,'Layer','bottom'); grid on
legend({'GDP Level';'Unemployment'})
SetAxesDual(gca);

% Save
SaveFigure('graphics/BQ_Replication');
%}

%% 13. UHLIG (2005)
% -----------------------------------------------------------------------
% Sign restriction identification example based on the replication of
% Uhlig (2005, JME).
%{

% 13.1 Load data from Uhlig
% -----------------------------------------------------------------------
% Load Uhlig's 6-variable monthly dataset (real GDP, GDP deflator, commodity
% prices, total reserves, non-borrowed reserves, fed funds rate). Variables
% y, pi, comm, nbres, and res are rescaled by 100 after loading.
[xlsdata, xlstext] = xlsread('data/Uhlig2005_Data.xlsx','Sheet1');
dates = xlstext(3:end,1);
datesnum = Date2Num(dates,'m');
vnames_long = xlstext(1,2:end);
vnames = xlstext(2,2:end);
nvar = length(vnames);
data   = Num2NaN(xlsdata);
for ii=1:length(vnames)
    DATA.(vnames{ii}) = data(:,ii);
end
year = str2double(xlstext{3,1}(1:4));
month = str2double(xlstext{3,1}(6));
nobs = size(data,1);
% Transform selected variables
tempnames = {'y','pi','comm','nbres','res'};
tempscale = [100,100,100,100,100];
for ii=1:length(tempnames)
    DATA.(tempnames{ii}) = tempscale(ii)*DATA.(tempnames{ii});
end

% 13.2 Plot series
% -----------------------------------------------------------------------
% Plot all 6 variables at monthly frequency with date labels.
figure;
FigSize(18,18)
for ii=1:nvar
    subplot(3,2,ii)
    plot(DATA.(vnames{ii}),'LineWidth',3,'Color',pantone('Blue'));
    title(vnames_long(ii),'FontWeight','bold','FontSize',13);
    DatesPlot(datesnum(1),nobs,6,'m') % Set the x-axis label
    set(gca,'FontSize',11); grid on;
    SetAxesDual(gca);
end
SaveFigure('graphics/Uhlig_DATA')

% 13.3 Set up and estimate VAR
% -----------------------------------------------------------------------
% Six-variable VAR with 12 lags and a constant, matching Uhlig (2005).
% Horizon set to 60 months; 1000 sign-restriction draws.

% Use all variables in spreadsheet order
Xvnames      = vnames;
Xvnames_long = vnames_long;
Xnvar        = length(Xvnames);

% Assemble data matrix X from DATA struct
X = nan(nobs,Xnvar);
for ii=1:Xnvar
    X(:,ii) = DATA.(Xvnames{ii});
end

% Estimate VAR: 12 lags, constant
det = 1;
nlags = 12;
[VAR, VARopt] = VARmodel(X,nlags,det);

% Populate VARopt for IRF plots
VARopt.vnames = Xvnames_long;
VARopt.nsteps = 60;
VARopt.ndraws = 1000;
VARopt.FigSize = [27,12];
VARopt.firstdate = datesnum(1);
VARopt.frequency = 'm';

% 13.4 Identification
% -----------------------------------------------------------------------
% A contractionary MP shock lowers the price level, commodity prices, and
% non-borrowed reserves and raises the fed funds rate; output and total
% reserves are unrestricted (Table 1 of Uhlig 2005). Restrictions hold at
% horizons 0–5 months (sr_hor=6). Credible bands at the 68% level.

% Define the MP shock name
VARopt.snames = {bfeps('MonPol')};

% Sign restriction matrix: positive 1, negative -1, unrestricted 0
R = [ 0,0,0,0,0,0;  % Real GDP:           unrestricted
     -1,0,0,0,0,0;  % Deflator:           falls
     -1,0,0,0,0,0;  % Commodity Price:    falls
      0,0,0,0,0,0;  % Total Reserves:     unrestricted
     -1,0,0,0,0,0;  % NonBorr. Reserves:  falls
      1,0,0,0,0,0]; % Fed Funds:          rises

% Number of horizons over which to impose restrictions
VARopt.sr_hor = 6;

% Width of credible interval
VARopt.pctg = 68;

% Run sign restrictions; all results stored in SRout
SRout = SR(VAR,R,VARopt);

% 13.5 Replicate Uhlig's Figure 6
% -----------------------------------------------------------------------
% Plot median IRF with 68% credible band for the MP shock across all
% 6 variables. Layout: 2 rows × 3 columns (auto-computed for 6 variables).
% VARirplot handles figure creation, swathe+line style, saving, and cleanup.
VARopt.figname = 'graphics/Uhlig_';
VARopt.FigSize = [27,12];
VARopt.pick = 1;
VARopt.shorttitle = 1;
VARirplot(SRout.IRmed,VARopt,SRout.IRinf,SRout.IRsup);

% 13.6 Show what happens in the background
% -----------------------------------------------------------------------
% Illustrate the mechanics of sign restrictions by plotting the first 100
% accepted rotations, then isolating the first rotation and the first two
% together to show how the swathe is built up draw by draw.

% Plot all rotations (first 100) as individual lines
figure;
FigSize(27,12)
for ii=1:Xnvar
    subplot(2,3,ii)
    plot(squeeze(SRout.IRall(:,ii,1,1:100))); hold on
    plot(zeros(VARopt.nsteps),'-k'); hold on
    title(vnames_long{ii},'FontWeight','bold','FontSize',13);
    set(gca,'FontSize',11); axis tight; grid on
	store(ii,:) = ylim;
end
SaveFigure('graphics/Uhlig_Replication_500rot')
% Plot first rotation
figure;
FigSize(27,12)
for ii=1:Xnvar
    subplot(2,3,ii)
    plot(SRout.IRall(:,ii,1,1)); hold on
    plot(zeros(VARopt.nsteps),'-k');
    title(vnames_long{ii},'FontWeight','bold','FontSize',13);
    set(gca,'FontSize',11); axis tight; grid on
    ylim(store(ii,:))
end
SaveFigure('graphics/Uhlig_Replication_1rot')
% Plot first two rotations
figure;
FigSize(27,12)
for ii=1:Xnvar
    subplot(2,3,ii)
    plot(SRout.IRall(:,ii,1,1)); hold on
    plot(SRout.IRall(:,ii,1,3)); hold on
    plot(zeros(VARopt.nsteps),'-k');
    title(vnames_long{ii},'FontWeight','bold','FontSize',13);
    set(gca,'FontSize',11); axis tight; grid on
    ylim(store(ii,:))
end
SaveFigure('graphics/Uhlig_Replication_2rot')
%}

%% 14. ANTOLIN-DIAZ AND RUBIO-RAMIREZ (2018)
% -----------------------------------------------------------------------
% Narrative sign restriction identification example replicating Figure 8
% of Antolin-Diaz and Rubio-Ramirez (2018, AER). Uses the same 6-variable
% monthly monetary VAR as Uhlig (2005) — real GDP, GDP deflator, commodity
% prices, total reserves, non-borrowed reserves, and fed funds rate —
% estimated with 12 lags and no constant over 1965m1–2007m11. The key
% contribution is the October 1979 Volcker narrative restriction: the MP
% shock must be positive (Type 1) and the dominant driver of the unexpected
% movement in the fed funds rate (Type 2). IRFs are normalized to a 25bp
% impact on the fed funds rate at h = 0 to facilitate comparison.
%{

% 14.1 Load ADRR data
% -----------------------------------------------------------------------
% Load the updated Uhlig dataset (1965m1–2007m11, monthly frequency). Row 1
% contains long variable names, row 2 short mnemonics, rows 3 onward contain
% date strings and data values.
[xlsdata, xlstext] = xlsread('data/ADRR2018_Data.xlsx','Sheet1');
dates       = xlstext(3:end, 1);
datesnum    = Date2Num(dates, 'm');
vnames_long = xlstext(1, 2:end);
vnames      = xlstext(2, 2:end);
nvar        = length(vnames);
data        = Num2NaN(xlsdata);

% Store each variable as a named field in the DATA structure
for ii = 1:length(vnames)
    DATA.(vnames{ii}) = data(:,ii);
end

% Record number of observations
nobs = size(data, 1);

% 14.2 Plot series
% -----------------------------------------------------------------------
% Plot all 6 variables at monthly frequency with date labels.
figure;
FigSize(18,18)
for ii = 1:nvar
    subplot(3,2,ii)
    plot(data(:,ii),'LineWidth',3,'Color',pantone('Blue'));
    title(vnames_long(ii),'FontWeight','bold','FontSize',13);
    DatesPlot(datesnum(1),nobs,6,'m')
    set(gca,'FontSize',11); grid on;
end
SaveFigure('graphics/ADRR_DATA')

% 14.3 Set up and estimate VAR
% -----------------------------------------------------------------------
% Paper specification (footnote 8, p. 27): 12 lags, no constant. All
% 6 variables entered in their raw form from the spreadsheet.

% Use all variables in spreadsheet order
Xvnames      = vnames;
Xvnames_long = vnames_long;
Xnvar        = length(Xvnames);

% Assemble data matrix X from DATA struct
X = nan(nobs, Xnvar);
for ii = 1:Xnvar
    X(:,ii) = DATA.(Xvnames{ii});
end

% Estimate VAR: 12 lags, no constant
det   = 0;
nlags = 12;
[VAR, VARopt] = VARmodel(X, nlags, det);

% Populate VARopt
VARopt.vnames    = Xvnames_long;
VARopt.nsteps    = 60;
VARopt.ndraws    = 500;
VARopt.sr_hor    = 6;
VARopt.pctg      = 68;
VARopt.sr_draw   = 500000;
VARopt.sr_mod    = 1;
VARopt.mult      = 50;
VARopt.dates     = dates;
VARopt.FigSize   = [27, 12];
VARopt.firstdate = datesnum(1);
VARopt.frequency = 'm';
VARopt.figname = 'graphics/ADRR_';

% 14.4 Identification
% -----------------------------------------------------------------------
% Sign restrictions replicate Uhlig (2005, Table 3): contractionary MP shock
% lowers the price level, commodity prices, and non-borrowed reserves and
% raises the fed funds rate; output and total reserves are unrestricted.
% Restrictions hold at horizons 0–5 months (sr_hor=6). The narrative
% restriction adds: at October 1979 the MP shock is positive (Type 1) and
% the dominant driver of the fed funds rate (Type 2).

% Define the MP shock name
VARopt.snames = {bfeps('MonPol')};

% Sign restriction matrix: positive 1, negative -1, unrestricted 0
SIGN = [ 0, 0, 0, 0, 0, 0;   % y:     unrestricted
        -1, 0, 0, 0, 0, 0;   % pi:    falls
        -1, 0, 0, 0, 0, 0;   % comm:  falls
         0, 0, 0, 0, 0, 0;   % res:   unrestricted
        -1, 0, 0, 0, 0, 0;   % nbres: falls
         1, 0, 0, 0, 0, 0];  % ff:    rises

% Run sign restrictions baseline
disp('=== Running sign restrictions (baseline) ===')
SRout_ADRR = SR(VAR, SIGN, VARopt);

% Build R struct for sign + narrative restrictions
clear R
R.sign = SIGN;

% Type 1: MP shock is positive at October 1979
R.narr_sign.shock  = 1;
R.narr_sign.period = '1979m10';
R.narr_sign.sign   = 1;

% Type 2: MP shock is dominant driver of ff at October 1979
R.narr_dom.shock  = 1;
R.narr_dom.period = '1979m10';
R.narr_dom.var    = 6;

% Run sign + narrative restrictions
disp('=== Running sign + narrative restrictions ===')
NSRout_ADRR = SR(VAR, R, VARopt);
disp(['Acceptance rate (sign + narrative): ' ...
    num2str(100*NSRout_ADRR.accept_rate,'%.1f') '% of draws accepted'])

% 14.5 Normalize and plot: replicate Figure 8
% -----------------------------------------------------------------------
% Normalize IRFs to a 25bp impact on the fed funds rate at h = 0 by
% computing one scalar per model = 0.25 / median(IRF of ff at h=0), then
% scaling all draws. Compute 68% bands as the 16th–84th percentiles.

%....... NOTES TO FIG/TAB .......
% Figure 8, Antolin-Diaz and Rubio-Ramirez (2018, AER). Impulse responses
% to a contractionary MP shock: sign restrictions only (blue swathe) vs.
% sign + narrative restrictions (red swathe). 68% credible bands normalized
% to a 25bp impact on the fed funds rate at h = 0. Variables: real GDP,
% GDP deflator, commodity prices, total reserves, non-borrowed reserves,
% fed funds rate. Sample: 1965m1–2007m11; 12 lags; no constant.
%..................................

% Variable and shock indices
ff_var   = 6;
mp_shock = 1;

% Percentile bounds for 68% credible interval
pctg_inf_val = (100 - VARopt.pctg) / 2;
pctg_sup_val = 100 - pctg_inf_val;

% Normalize sign-only draws and compute percentile bands
scale_SR     = (0.25 / median(squeeze(SRout_ADRR.IRall(1, ff_var, mp_shock, :)))) * 100;
IRall_SR_n   = SRout_ADRR.IRall * scale_SR;
IRmed_SR     = median(IRall_SR_n, 4);
aux          = prctile(IRall_SR_n, [pctg_inf_val pctg_sup_val], 4);
IRinf_SR     = aux(:,:,:,1);
IRsup_SR     = aux(:,:,:,2);

% Normalize sign + narrative draws and compute percentile bands
scale_NSR   = (0.25 / median(squeeze(NSRout_ADRR.IRall(1, ff_var, mp_shock, :)))) * 100;
IRall_NSR_n = NSRout_ADRR.IRall * scale_NSR;
IRmed_NSR   = median(IRall_NSR_n, 4);
aux          = prctile(IRall_NSR_n, [pctg_inf_val pctg_sup_val], 4);
IRinf_NSR   = aux(:,:,:,1);
IRsup_NSR   = aux(:,:,:,2);

% Swathe options: blue for sign-only baseline; swatheonly suppresses built-in line
SwatheOpt_SR = PlotSwatheOption;
SwatheOpt_SR.swathecol    = pantone('Blue');
SwatheOpt_SR.swatheonly   = 1;
SwatheOpt_SR.transp       = 1;
SwatheOpt_SR.alpha        = 0.15;
SwatheOpt_SR.border       = 1;
SwatheOpt_SR.borderstyle  = '--';

% Swathe options: red for sign + narrative
SwatheOpt_NSR = PlotSwatheOption;
SwatheOpt_NSR.swathecol   = pantone('Tomato');
SwatheOpt_NSR.swatheonly  = 1;
SwatheOpt_NSR.transp      = 1;
SwatheOpt_NSR.alpha       = 0.30;
SwatheOpt_NSR.border      = 1;
SwatheOpt_NSR.borderstyle = '-.';

% Plot: 2×3 layout, one panel per variable; swathes first, then lines on top
figure;
FigSize(27, 12)
for ii = 1:nvar
    subplot(2, 3, ii)
    PlotSwathe(IRmed_SR(:,ii,mp_shock),   [IRinf_SR(:,ii,mp_shock)   IRsup_SR(:,ii,mp_shock)],   SwatheOpt_SR);
    hold on
    PlotSwathe(IRmed_NSR(:,ii,mp_shock), [IRinf_NSR(:,ii,mp_shock) IRsup_NSR(:,ii,mp_shock)], SwatheOpt_NSR);
    set(gcf, 'renderer', 'painters')
    H1 = plot(IRmed_SR(:,ii,mp_shock),   'LineStyle', '-', 'Color', pantone('Blue'), 'LineWidth', 2, ...
        'Marker', 'o', 'MarkerSize', 7, 'MarkerFaceColor', 0.5*pantone('Blue')+0.5*[1 1 1], 'MarkerEdgeColor', pantone('Blue'));
    H2 = plot(IRmed_NSR(:,ii,mp_shock), 'LineStyle', '-', 'Color', pantone('Tomato'), 'LineWidth', 2, ...
        'Marker', 'o', 'MarkerSize', 7, 'MarkerFaceColor', 0.5*pantone('Tomato')+0.5*[1 1 1], 'MarkerEdgeColor', pantone('Tomato'));
    plot(zeros(1, VARopt.nsteps), '-k', 'LineWidth', 0.5)
    xlim([1 VARopt.nsteps])
    title(vnames_long{ii}, 'FontWeight', 'bold', 'FontSize', 13)
    set(gca, 'FontSize', 11, 'Layer', 'bottom'); grid on
    if ii == 6
        legend([H1 H2], {'Sign only', 'Sign + Narrative'}, ...
               'Location', 'northeast')
    end
end
SaveFigure('graphics/ADRR_IR_1')
%}

%% 15. GERTLER AND KARADI (2015)
% -----------------------------------------------------------------------
% External instruments identification example based on the replication of
% Gertler and Karadi (2015, AEJ:M).
%{

% 15.1 Load data from Gertler and Karadi
% -----------------------------------------------------------------------
% Load GK2015 dataset (1-year T-Bill, log CPI, log industrial production,
% excess bond premium, and the FF4 futures instrument) at monthly frequency.
[xlsdata, xlstext] = xlsread('data/GK2015_Data.xlsx','Sheet1');
dates = xlstext(3:end,1);
datesnum = Date2Num(dates,'m');
vnames_long = xlstext(1,2:end);
vnames = xlstext(2,2:end);
nvar = length(vnames);
data   = Num2NaN(xlsdata);
for ii=1:length(vnames)
    DATA.(vnames{ii}) = data(:,ii);
end
year = str2double(xlstext{3,1}(1:4));
month = str2double(xlstext{3,1}(6));
nobs = size(data,1);

% 15.2 Plot series
% -----------------------------------------------------------------------
% Plot all 5 series at monthly frequency with date labels.
figure;
FigSize(18,18)
for ii=1:nvar
    subplot(3,2,ii)
    plot(DATA.(vnames{ii}),'LineWidth',3,'Color',pantone('Blue'));
    title(vnames_long(ii),'FontWeight','bold','FontSize',13);
    DatesPlot(datesnum(1),nobs,6,'m') % Set the x-axis label
    set(gca,'FontSize',11); grid on;
end
SaveFigure('graphics/GK_DATA')

% 15.3 Set up and estimate VAR
% -----------------------------------------------------------------------
% Four-variable VAR (1-year T-Bill, log CPI, log IP, excess bond premium)
% with 12 lags and a constant. FF4 futures used as external instrument.

% Select endogenous variables
Xvnames_long = {'1yr T-Bill';'Consumer Price Index';'Industrial Production';...
        'Excess Bond Premium';};
Xvnames      = {'gs1';'logcpi';'logip';'ebp';};
Xnvar        = length(Xvnames);

% Assemble endogenous data matrix X
X = nan(nobs,Xnvar);
for ii=1:Xnvar
    X(:,ii) = DATA.(Xvnames{ii});
end

% Select external instrument (FF4 futures) from DATA struct
IVvnames      = {'ff4_tc'};
IVvnames_long = {'FF4 futures'};
IVnvar        = length(IVvnames);

% Assemble instrument vector IV
IV = nan(nobs,IVnvar);
for ii=1:IVnvar
    IV(:,ii) = DATA.(IVvnames{ii});
end

% Estimate VAR: 12 lags, constant
det = 1;
nlags = 12;
[VAR, VARopt] = VARmodel(X,nlags,det);

% Populate VARopt for IRF plots
VARopt.vnames = Xvnames_long;
VARopt.nsteps = 60;
VARopt.FigSize = [18,12];
VARopt.firstdate = datesnum(1);
VARopt.frequency = 'm';
VARopt.figname = 'graphics/GK_';
VARopt.shorttitle = 1;

% 15.4 Identification
% -----------------------------------------------------------------------
% Proxy SVAR with the FF4 futures instrument (ident='iv'). Wild bootstrap
% for confidence bands (method='wild'). plot all shocks via VARirplot, then
% produce a second figure highlighting the impact response with a star marker.

% Attach instrument to VAR struct and set identification to 'iv'
VAR.IV = IV;
VARopt.ident = 'iv';
VARopt.snames = {bfeps('MonPol')};
VARopt.method = 'wild';
VARopt.pick = 1;

% Compute IRFs and wild-bootstrap confidence bands
[IR, VAR] = VARir(VAR,VARopt);
[IRinf,IRsup,IRmed,IRbar] = VARirband(VAR,VARopt);

% Plot all shock IRFs
VARirplot(IRbar,VARopt,IRinf,IRsup);

% Plot impact response highlighted with a star marker
figure;
FigSize(18,12)
SwatheOpt = PlotSwatheOption;
SwatheOpt.swathecol = [0.97 0.97 0.97];
SwatheOpt.linecol = [0.97 0.97 0.97 ];
for ii=1:Xnvar
    subplot(2,2,ii);
	PlotSwathe(IRbar(:,ii),[IRinf(:,ii) IRsup(:,ii)],SwatheOpt); hold on;
    plot(zeros(1,VARopt.nsteps),'-k','LineWidth',0.5); hold on
    plot(1,IRbar(1,ii),'LineStyle','-','Color',pantone('Blue'),'LineWidth',2,...
        'Marker','*','MarkerSize',15); hold on
    xlim([1 VARopt.nsteps]);
    title([Xvnames_long{ii} ' to ' VARopt.snames{1}],'FontWeight','bold','FontSize',13);
    set(gca, 'FontSize', 11, 'Layer', 'bottom'); grid on
end
SaveFigure('graphics/GK_alt_IR_1')
%}

%% 16. CLEAN UP
% -----------------------------------------------------------------------
% Remove toolbox from path and close all figures.

rmpath(genpath(path_Toolbox))
close all
