function OUT = MovAvgCent(DATA,window)
% =======================================================================
% Moving average of the matrix DATA (TxN). The moving average is
% computed over the symmetric interval [t-window, t+window] and it is
% computed down each column.
% =======================================================================
% OUT = MovAvgCent(DATA,window)
% -----------------------------------------------------------------------
% INPUT
%   DATA  : T observations x N variables [double]
%   window: half-width of the centered window; full window = 2*window+1 [double]
% -----------------------------------------------------------------------
% OUTPUT
%   OUT: T x N matrix (the first and last window observations are NaN) [double]
% -----------------------------------------------------------------------
% EXAMPLE
%   X = rand(20,2);
%   OUT = MovAvgCent(X,2)
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-19
% -----------------------------------------------------------------------

%% 1. Check inputs
% -----------------------------------------------------------------------
if nargin<2,                error('Not enough input.'),          end
if window<=0,               error('window must be positive.'),   end
if (window~=floor(window)), error('window must be an integer.'), end

% Force column vector so the loop handles both vectors and matrices uniformly
if min(size(DATA))==1
    DATA = DATA(:);  % force column vector so the loop works uniformly
end

% Get dimensions and validate window size
[nobs, nvars] = size(DATA);
if window>nobs
    error('window must not be greater than the length of DATA.')
end

%% 2. Compute centered rolling mean
% -----------------------------------------------------------------------
% Each observation jj uses the symmetric window [jj-window, jj+window].
% The first and last 'window' observations remain NaN (boundary effect).
% 'omitnan' handles internal NaNs within the window.
OUT = nan(nobs, nvars);
for jj = (window+1):(nobs-window)
    OUT(jj, :) = mean(DATA(jj-window:jj+window, :), 'omitnan');
end
