function OUT = MovAvg(DATA,window)
% =======================================================================
% Moving average of the matrix DATA (TxN). The moving average is 
% computed down each column.
% =======================================================================
% OUT = MovAvg(DATA,window)
% -----------------------------------------------------------------------
% INPUT
%   DATA: T observations x N variables [double]
%   window: window of the moving average [double]
% -----------------------------------------------------------------------
% OUTPUT
%   OUT: T x N matrix (the first window-1 observations are NaN) [double]
% -----------------------------------------------------------------------
% EXAMPLE
%   X = rand(20,2);
%   OUT = MovAvg(X,2)
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-19
% -----------------------------------------------------------------------

%% 1. Check inputs
% -----------------------------------------------------------------------
if nargin<2,                error('Not enough input.'),          end
if window<=0,               error('Window must be positive.'),   end
if (window~=floor(window)), error('Window must be an integer.'), end

% Force column vector so the loop handles both vectors and matrices uniformly
if min(size(DATA))==1
    DATA = DATA(:);  % force column vector so the loop works uniformly
end

% Get dimensions and validate window size
[nobs, nvar] = size(DATA);
if window>nobs
    error('window must not be greater than the length of DATA.')
end

%% 2. Compute rolling mean
% -----------------------------------------------------------------------
% The loop computes the mean over [row, row+window-1] for each position.
% The result has nobs-window+1 rows; prepend window-1 NaN rows to align
% with the original series (the first full window ends at row = window).
temp = nan(nobs-window+1, nvar);
for row = 1:(nobs-window+1)
    temp(row, :) = mean(DATA(row:(row+window-1), :));
end

OUT = [nan(window-1, nvar); temp]; 
