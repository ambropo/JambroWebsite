function OUT = MovCorr(X,window,i)
% =======================================================================
% Computes correlation between X_i and X_j for all j different
% of i, from window to the number of observations. The
% first window-1 rows are NaN.
% =======================================================================
% OUT = MovCorr(X, window, i)
% -----------------------------------------------------------------------
% INPUT
%   - X: panel time series T observations x N variables [double]
%   - window : size of the moving window [double]
%   - i: selects the i^th variable against which correlations are to be
%       computed [double]
% -----------------------------------------------------------------------
% OUTPUT
%   - OUT: matrix with moving correlation T observations x N-1 
%       variables. The first window-1 rows are NaN. [double]
% -----------------------------------------------------------------------
% EXAMPLE
%   X = rand(100,5);
%   OUT = MovCorr(X,20,1)
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-19
% -----------------------------------------------------------------------

%% 1. Check inputs
% -----------------------------------------------------------------------
if nargin < 3
    error('MovCorr: X, window, and i are required inputs.')
end

%% 2. Compute rolling correlations
% -----------------------------------------------------------------------
% corrcoef returns the full (nvars x nvars) correlation matrix for the
% current window. setdiff(1:nvars, i) picks all column indices except i,
% so OUT stores the correlation of variable i with every other variable.
% The first window-1 rows remain NaN (not enough data for a full window).
[nobs, nvars] = size(X);
OUT = nan(nobs, nvars-1);

% Roll over each observation, computing the correlation matrix for the current window
for tt = window:nobs
    C   = corrcoef(X(tt-window+1:tt, :));
    idx = setdiff(1:nvars, i);   % indices of all variables except i
    OUT(tt, :) = C(i, idx);
end

