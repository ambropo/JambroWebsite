function [CORR, TABLE] = CorrTable(x,vnames,pairwise)
% =======================================================================
% Computes the correlation matrix of a matrix of time series with titles
% =======================================================================
% [CORR, TABLE] = CorrTable(x,vnames,pairwise)
% -----------------------------------------------------------------------
% INPUT
%   - x: matrix (rows x cols) [double]
%   - vnames: array (1 x cols) with names of the (cols) series [cell]
% -----------------------------------------------------------------------
% OPTIONAL INPUT
%   - pairwise: 1 to compute pairwise (ignores NaN row-wise per pair) [dflt = 0]
% -----------------------------------------------------------------------
% OUTPUT
%   - CORR: correlation matrix [double]
%   - TABLE: table of correlation matrix with titles [cell]
% -----------------------------------------------------------------------
% EXAMPLE
%   x = rand(50,2);
%   [CORR, TABLE] = CorrTable(x,{'Consumption','Investment'})
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2015. Updated: 2026-05-19
% -----------------------------------------------------------------------

%% 1. Check inputs
% -----------------------------------------------------------------------
if nargin < 2
    error('CorrTable: x and vnames are required inputs.')
end
if ~exist('pairwise','var')
    pairwise = 0;
end

% vnames must be a row vector
if size(vnames,1)>1
    vnames = vnames';
end

%% 2. Compute correlation matrix
% -----------------------------------------------------------------------
if pairwise==0
    CORR = corr(x);
elseif pairwise==1
    % 'pairwise' uses all available obs for each pair, ignoring NaNs
    CORR = corr(x,'rows','pairwise');
end
[r, ~] = size(CORR);

% Zero out the strictly upper triangle (keep lower triangle and diagonal)
CORR(logical(triu(ones(r), 1))) = NaN;

%% 3. Format and print output table
% -----------------------------------------------------------------------
TAB = num2cell(CORR);
TAB = [vnames ; TAB];          % column headers on top
aux = [{''} vnames]';
TABLE = [aux TAB];             % row labels on the left

% Print formatted table to command window
info.cvnames = char(vnames);
info.rvnames = char([{' '} vnames]);
mprint(CORR,info);