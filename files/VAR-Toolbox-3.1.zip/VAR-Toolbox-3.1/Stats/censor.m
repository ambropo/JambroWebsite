function OUT = censor(X,pct)
% =======================================================================
% Censor the values of a matrix (RxC) column by column, by replacing with 
% NaNs where the data is above 100-pct and below pct
% =======================================================================
% OUT = censor(X,pct)
% -----------------------------------------------------------------------
% INPUT
%   - X   : matrix of data [double]
%   - pct : percentile to be censored on each side [double]
% -----------------------------------------------------------------------
% OUTPUT
%   - OUT : matrix [double]
% -----------------------------------------------------------------------
% EXAMPLE
%   X = rand(50,2);
%   OUT = censor(X,5)
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2015. Updated: 2026-05-19
% -----------------------------------------------------------------------

%% 1. Check inputs
% -----------------------------------------------------------------------
if nargin < 2
    error('censor: X and pct are required inputs.')
end
if pct <= 0 || pct >= 50
    error('censor: pct must be in (0, 50).')
end

%% 2. Censor each column
% -----------------------------------------------------------------------
% Values above the (100-pct) percentile or below the pct percentile
% are replaced with NaN. For example, pct=5 censors the bottom 5% and
% the top 5% of each column independently.
[row, col] = size(X);
OUT = nan(row,col);
for ii=1:col
    x = X(:,ii);
    upp = prctile(x, 100-pct);  % upper threshold: (100-pct)-th percentile
    low = prctile(x, pct);      % lower threshold: pct-th percentile
    x(x>upp) = NaN;
    x(x<low) = NaN;
    OUT(:,ii) = x;
end