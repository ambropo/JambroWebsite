function [OUT, W] = CrossWeightAverage(DATA,WEIGHT)
% =======================================================================
% Compute the weighted average of DATA, computing the weights from the
% matrix WEIGHT. Note that if there are NaNs in DATA the weights are
% rescaled. WEIGHT cannot contain NaN.
% =======================================================================
% [OUT, W] = CrossWeightAverage(DATA,WEIGHT)
% -----------------------------------------------------------------------
% INPUT
%   - DATA  : panel of time series (TxN); NaNs are accepted and weights
%             are rescaled to sum to 1 over available series [double]
%   - WEIGHT: weight matrix (TxN), or a single row (1xN) for fixed
%             weights that are replicated across all T periods [double]
% -----------------------------------------------------------------------
% OUTPUT
%   - OUT: weighted average vector (T x 1) [double]
%   - W  : matrix of (rescaled) weights (T x N) [double]
% -----------------------------------------------------------------------
% EXAMPLE 1: fixed weights (replicated across rows)
%   x = [1 NaN  3 ;
%        2   3  4 ;
%        3   4  5 ;
%        4   5  6];
%   w = [0  .4 .6];
%   [OUT, W] = CrossWeightAverage(x,w)
% -----------------------------------------------------------------------
% EXAMPLE 2: time-varying weights
%   x = [ 1 NaN   3 ;
%         2   3   4 ;
%         3   4   5 ;
%         4   5   6];
%   w = [.4  .2  .4 ;
%        .3  .4  .3 ;
%        .4  .3  .3 ;
%        .5  .3  .2];
%   [OUT, W] = CrossWeightAverage(x,w)
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2012. Updated: 2026-05-19
% -----------------------------------------------------------------------

%% 1. Check inputs
% -----------------------------------------------------------------------
if nargin < 2
    error('CrossWeightAverage: DATA and WEIGHT are required inputs.')
end
[r1, c1] = size(DATA);
[r2, c2] = size(WEIGHT);

% If a single row of weights is supplied, replicate it into a (TxN) matrix
if r2==1 && c2==c1
    WEIGHT = repmat(WEIGHT, r1, 1);
end

% Confirm DATA and WEIGHT are now conformable
[r2, c2] = size(WEIGHT);
if r1~=r2 || c1~=c2
    error('CrossWeightAverage: DATA and WEIGHT matrices are not conformable.')
end

%% 2. Compute cross-sectional weighted average
% -----------------------------------------------------------------------
% NaNs in DATA are excluded row-by-row; the remaining weights are
% renormalised to sum to 1 so the average is still well-defined.
[nobs, nvars] = size(DATA);
nans = isnan(DATA);
WEIGHT(nans) = NaN;

% Preallocate output and weight matrices
OUT = nan(nobs, 1);
W   = nan(nobs, nvars);

% Loop over rows, renormalise weights and compute weighted average
for ii=1:nobs
    % Normalise weights to sum to 1, ignoring NaN entries
    row_w = WEIGHT(ii,:);
    aux_weight = row_w ./ sum(row_w, 'omitnan');
    W(ii,:) = aux_weight;
    % Zero out weights for missing observations before computing dot product
    aux_weight(nans(ii,:)) = 0;
    DATA(ii, nans(ii,:)) = 0;
    if sum(nans(ii,:)) == nvars
        OUT(ii,1) = NaN;   % all series missing for this period
    else
        OUT(ii,1) = DATA(ii,:) * aux_weight';
    end
end
