% TSP 2026 exercise solution: Cholesky, sign restrictions, and IV
% identification applied to a monetary policy VAR (Gertler-Karadi data).
% =======================================================================
% The VAR Toolbox 3.1 is required to run this code. To get the
% latest version visit: https://github.com/ambropo/VAR-Toolbox
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% April 2026. Updated: 2026-05-25
% -----------------------------------------------------------------------

%% 1. PRELIMINARIES
% -----------------------------------------------------------------------
clear all; close all; clc
warning off all

%% 2. LOAD DATA
% -----------------------------------------------------------------------
% Load data 
[xlsdata, xlstext] = xlsread('GK2015_Data.xlsx','Sheet1');
dates = xlstext(3:end,1);
vnames_long = xlstext(1,2:end);
vnames = xlstext(2,2:end);
nvar = length(vnames);
data   = Num2NaN(xlsdata);

% Store variables in the structure DATA
for ii=1:length(vnames)
    DATA.(vnames{ii}) = data(:,ii);
end

% Observations
nobs = size(data,1);


%% 3. REDUCED-FORM VAR
% -----------------------------------------------------------------------
% Set endogenous list and names
VARvnames_long = {'CPI';'IP';'1yr rate';'EBP';};
VARvnames      = {'logcpi';'logip';'gs1';'ebp';};
VARnvar        = length(VARvnames);

% Set instrument list and names
IVvnames_long = {'FF4';};
IVvnames      = {'ff4_tc'};
IVnvar        = length(IVvnames);

% VAR specification
VARnlags = 12; VARconst = 1;

% Create matrices of variables for the VAR
ENDO = nan(nobs,VARnvar);
for ii=1:VARnvar
    ENDO(:,ii) = DATA.(VARvnames{ii});
end

% Create matrices of variables for the instrument
IV = nan(nobs,IVnvar);
for ii=1:IVnvar
    IV(:,ii) = DATA.(IVvnames{ii});
end

% Estimate reduced-form VAR
[VAR, VARopt] = VARmodel(ENDO,VARnlags,VARconst);


%% 4. CHOLESKY IDENTIFICATION
% -----------------------------------------------------------------------
% Recursive (short-run) identification. The ordering CPI -> IP -> Rate -> EBP
% implies that monetary policy (Rate) responds contemporaneously to CPI and IP
% but not to EBP; EBP responds to all variables within the month.
% The monetary policy shock is shock 3.

% Estimate VAR
[VARchol, VARoptchol] = VARmodel(ENDO,VARnlags,VARconst);
VARoptchol.ident  = 'short';
VARoptchol.nsteps = 48;

% Compute IRFs and bootstrap error bands
[IRchol, VARchol] = VARir(VARchol,VARoptchol);
[INFchol,SUPchol,MEDchol,BARchol] = VARirband(VARchol,VARoptchol);

% Plot responses to monetary shock (shock 3)
figure
FigSize(30,20)
idx = 1;
for ii=1:VARnvar
    subplot(2,2,idx)
    plot(BARchol(:,ii,3),'Color',pantone('Blue'),'LineWidth',2); hold on;
    plot(INFchol(:,ii,3),'Color',pantone('Blue'),'LineWidth',1,'LineStyle','--'); hold on;
    plot(SUPchol(:,ii,3),'Color',pantone('Blue'),'LineWidth',1,'LineStyle','--'); hold on;
    plot(zeros(VARoptchol.nsteps),'-k')
    title(VARvnames_long{ii},'FontWeight','bold')
    axis tight
    idx = idx + 1;
end


%% 5. SIGN RESTRICTIONS IDENTIFICATION
% -----------------------------------------------------------------------
% Set-identification via sign restrictions. The SIGN matrix defines the
% expected impact signs for each shock (columns) on each variable (rows):
%   +1 = positive,  -1 = negative,  0 = unrestricted
% Restrictions are imposed for the first sr_hor periods.
% The monetary policy shock is shock 3 (columns: Demand, Supply, Monetary, Unidentified).

% Estimate VAR
[VARsr, VARoptsr] = VARmodel(ENDO,VARnlags,VARconst);

%            Demand  Supply  Monetary  Unident.
SIGN = [ 1,   -1,     -1,      0;   % CPI
         1,    1,     -1,      0;   % IP
         1,    0,      1,      0;   % Rate
        -1,   -1,      1,      0];  % EBP

VARoptsr.snames = {'Demand','Supply','Monetary','Unidentified'};
VARoptsr.ndraws = 1000;   % number of accepted draws
VARoptsr.nsteps = 48;
VARoptsr.sr_hor = 3;      % restrictions hold for the first 3 months

% Run sign-restriction algorithm and compute IRFs
SRout = SR(VARsr,SIGN,VARoptsr);

% Plot responses to monetary shock (shock 3)
figure
FigSize(30,20)
idx = 1;
for ii=1:VARnvar
    subplot(2,2,idx)
    plot(SRout.IRmed(:,ii,3),'Color',cmap(2),'LineWidth',2); hold on;
    plot(SRout.IRinf(:,ii,3),'Color',cmap(2),'LineWidth',1,'LineStyle','--'); hold on;
    plot(SRout.IRsup(:,ii,3),'Color',cmap(2),'LineWidth',1,'LineStyle','--'); hold on;
    plot(zeros(VARoptsr.nsteps),'-k')
    title(VARvnames_long{ii},'FontWeight','bold')
    axis tight
    idx = idx + 1;
end


% Save original ordering for later comparison
VARvnames_orig      = {'logcpi';'logip';'gs1';'ebp'};
VARvnames_long_orig = {'CPI';'IP';'1yr rate';'EBP'};

%% 6. EXTERNAL INSTRUMENTS (PROXY SVAR) IDENTIFICATION
% -----------------------------------------------------------------------
% Identification via an external instrument (FF4: federal funds futures
% surprise, 4-month ahead). The instrument must be placed first in the VAR,
% so we re-order ENDO putting Rate before CPI and IP.
% Error bands via wild bootstrap (required for IV residuals).

% Re-order: Rate first (the instrumented variable must be first)
VARvnames_long = {'1yr rate';'CPI';'IP';'EBP';};
VARvnames      = {'gs1';'logcpi';'logip';'ebp';};

% Re-create ENDO with new ordering and re-estimate VAR
ENDO = nan(nobs,VARnvar);
for ii=1:VARnvar
    ENDO(:,ii) = DATA.(VARvnames{ii});
end
[VARiv, VARoptiv] = VARmodel(ENDO,VARnlags,VARconst);

% Attach instrument and set identification options
VARiv.IV          = IV;
VARoptiv.ident    = 'iv';
VARoptiv.nsteps   = 48;
VARoptiv.method   = 'wild';

% Compute IRFs and wild-bootstrap error bands
[IRiv, VARiv] = VARir(VARiv,VARoptiv);
[INFiv,SUPiv,MEDiv,BARiv] = VARirband(VARiv,VARoptiv);

% Plot responses to the identified monetary shock
figure
FigSize(30,20)
idx = 1;
for ii=1:VARnvar
    subplot(2,2,idx)
    plot(BARiv(:,ii),'Color',cmap(3),'LineWidth',2); hold on;
    plot(INFiv(:,ii),'Color',cmap(3),'LineWidth',1,'LineStyle','--'); hold on;
    plot(SUPiv(:,ii),'Color',cmap(3),'LineWidth',1,'LineStyle','--'); hold on;
    plot(zeros(VARoptiv.nsteps),'-k')
    title(VARvnames_long{ii},'FontWeight','bold')
    axis tight
    idx = idx + 1;
end


%% 7. COMPARISON: POINT ESTIMATES ACROSS IDENTIFICATION APPROACHES
% -----------------------------------------------------------------------
% Plot median IRFs from all three methods on the same axes. The IV results
% use a different variable ordering (Rate first), so we use find() to locate
% the column in BARiv that corresponds to each variable in the original order.

% IV variable ordering used above
VARvnames_iv = {'gs1';'logcpi';'logip';'ebp'};

% Open a new figure and plot median IRFs from all three methods side by side
figure
FigSize(30,20)
idx = 1;
for ii = 1:VARnvar
    % Find which column in IV results corresponds to variable ii
    col_iv = find(strcmp(VARvnames_iv, VARvnames_orig{ii}));
    % Plot
    subplot(2,2,idx)
    plot(BARchol(:,ii,3),    'Color',pantone('Blue'),'LineWidth',2); hold on;
    plot(SRout.IRmed(:,ii,3),'Color',cmap(2),'LineWidth',2); hold on;
    plot(BARiv(:,col_iv),    'Color',cmap(3),'LineWidth',2); hold on;
    plot(zeros(VARoptiv.nsteps),'-k')
    title(VARvnames_long_orig{ii},'FontWeight','bold')
    axis tight
    idx = idx + 1;
end
legend('Cholesky','Sign restr.','IV','Location','best')
