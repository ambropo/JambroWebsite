% Replicates Figure 6 (page 397) of Uhlig (2005, JME): sign restriction
% identification of a contractionary monetary policy shock in a 6-variable
% monthly VAR for the US economy.
% =======================================================================
% Outputs: swathe plot of IRFs to the monetary policy shock (median and
% 68% credible interval, 60-month horizon). Requires VAR Toolbox 3.1.
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% November 2020. Updated: 2026-05-28
% -----------------------------------------------------------------------

%% 1. PRELIMINARIES
% -----------------------------------------------------------------------
clear all; close all; clc
warning off all
cd(fileparts(mfilename('fullpath')));

%% 2. LOAD DATA
% -----------------------------------------------------------------------
% Load raw data and parse variable names and dates from the spreadsheet
[xlsdata, xlstext] = xlsread('Uhlig2005_Data.xlsx','Sheet1');
dates = xlstext(3:end,1);
vnames_long = xlstext(1,2:end);
vnames = xlstext(2,2:end);
nvar = length(vnames);
data = Num2NaN(xlsdata);

% Store each variable as a named field in the DATA structure
for ii=1:length(vnames)
    DATA.(vnames{ii}) = data(:,ii);
end

% Extract the first observation date (year and month) for later use
year = str2double(xlstext{3,1}(1:4));
month = str2double(xlstext{3,1}(6));
nobs = size(data,1);

% Rescale selected log-level variables by 100 to express in percent
tempnames = {'y','pi','comm','nbres','res'};
tempscale = [100,100,100,100,100];
for ii=1:length(tempnames)
    DATA.(tempnames{ii}) = tempscale(ii)*DATA.(tempnames{ii});
end

%% 3. PLOT SERIES
% -----------------------------------------------------------------------
% Plot all six variables over the full sample at monthly frequency.
% Log-level variables are shown rescaled by 100 (units: percent).
firstdate = year + (month-1)/12;
figure;
FigSize(27,12)
for ii = 1:nvar
    subplot(2,3,ii)
    plot(DATA.(vnames{ii}),'LineWidth',3,'Color',pantone('Blue'));
    title(vnames_long(ii),'FontWeight','bold','FontSize',13);
    DatesPlot(firstdate,nobs,6,'m')
    set(gca,'FontSize',11,'Layer','bottom'); grid on;
    set(findobj(gca,'Type','line'),'Clipping','off');
    SetAxesDual(gca);
end
SaveFigure('Uhlig_Data')

%% 4. VAR ESTIMATION
% -----------------------------------------------------------------------
% Construct the endogenous data matrix from the DATA structure
Xvnames      = vnames;
Xvnames_long = vnames_long;
Xnvar        = length(Xvnames);

% Build matrix X column by column
X = nan(nobs,Xnvar);
for ii=1:Xnvar
    X(:,ii) = DATA.(Xvnames{ii});
end

% Set deterministics and lag order
det = 1;
nlags = 12;

% Estimate reduced-form VAR by OLS
[VAR, VARopt] = VARmodel(X,nlags,det);

%% 5. SIGN RESTRICTIONS
% -----------------------------------------------------------------------
% Set plotting and identification options
VARopt.vnames = Xvnames_long;
VARopt.nsteps = 60;
VARopt.ndraws = 500;
VARopt.FigSize = [27,12];
VARopt.firstdate = year+(month-1)/12;
VARopt.frequency = 'm';

% Define sign restrictions: +1 positive, -1 negative, 0 unrestricted.
% A contractionary monetary policy shock raises the fed funds rate and
% lowers the price level, commodity prices, and non-borrowed reserves.
SIGN = [ 0,0,0,0,0,0;  % Real GDP
        -1,0,0,0,0,0;  % Deflator
        -1,0,0,0,0,0;  % Commodity Price
         0,0,0,0,0,0;  % Total Reserves
        -1,0,0,0,0,0;  % NonBorr. Reserves
         1,0,0,0,0,0]; % Fed Fund

% Impose restrictions for the first 6 months
VARopt.sr_hor = 6;

% Set credible interval coverage
VARopt.pctg = 68;

% Run sign restrictions routine; all results stored in SRout
SRout = SR(VAR,SIGN,VARopt);

% Reorder variables to match paper layout: left column = y, pi, comm;
% right column = res, nbres, ff. VARirplot fills subplots row-first, so
% the desired column-first arrangement requires reordering [1 4 2 5 3 6].
ord = [1 4 2 5 3 6];
VARopt.vnames  = Xvnames_long(ord);
VARopt.FigSize = [18,18];
VARopt.subplot = [3,2];
VARopt.color = pantone('Stone');
VARopt.pick = 1;
VARopt.figname = 'Uhlig_Fig6';

%% Plot IRFs using swathe (median with 68% credible interval)

%....... NOTES TO FIG/TAB .......
% Figure 6, Uhlig (2005, JME, p. 397). IRFs to a contractionary monetary
% policy shock identified by sign restrictions. 3x2 layout: left column =
% y, pi, comm; right column = res, nbres, ff. Shaded swathe: median with
% 68% credible interval (sign restrictions, 500 draws). Log-level
% variables scaled by 100 (units: percent). 60-month horizon.
%..................................
VARirplot(SRout.IRmed(:,ord,:), VARopt, SRout.IRinf(:,ord,:), SRout.IRsup(:,ord,:))

%% 6. SLIDES FIGURES
% -----------------------------------------------------------------------
% Reproduces the Primer §13.5–13.6 layout for VAR_Primer_Slides. Original
% variable order (not reordered for paper layout); saved with _Slides suffix.

% Reset VARopt to slide-friendly layout and original variable order
VARopt.vnames     = Xvnames_long;
VARopt.FigSize    = [27,12];
VARopt.subplot    = [2,3];
VARopt.color      = [];
VARopt.pick       = 1;
VARopt.shorttitle = 1;
VARopt.figname    = 'Uhlig_Slides';

%....... NOTES TO FIG/TAB .......
% Uhlig (2005, JME) Fig. 6 in slide dimensions. IRFs to a contractionary
% monetary policy shock (sign restrictions, 500 draws). Variables in
% spreadsheet order. 68% credible interval. 60-month horizon.
%..................................
VARirplot(SRout.IRmed,VARopt,SRout.IRinf,SRout.IRsup);

% Plot first 100 accepted rotations to show how the swathe builds up draw by draw
figure;
FigSize(27,12)
for ii = 1:Xnvar
    subplot(2,3,ii)
    plot(squeeze(SRout.IRall(:,ii,1,1:100))); hold on
    plot(zeros(VARopt.nsteps),'-k'); hold on
    title(Xvnames_long{ii},'FontWeight','bold','FontSize',13);
    set(gca,'FontSize',11,'Layer','bottom'); axis tight; grid on
    set(findobj(gca,'Type','line'),'Clipping','off');
    SetAxesDual(gca);
    store(ii,:) = ylim;
end
SaveFigure('Uhlig_500rot_Slides')

% Plot first rotation alone
figure;
FigSize(27,12)
for ii = 1:Xnvar
    subplot(2,3,ii)
    plot(SRout.IRall(:,ii,1,1)); hold on
    plot(zeros(VARopt.nsteps),'-k');
    title(Xvnames_long{ii},'FontWeight','bold','FontSize',13);
    set(gca,'FontSize',11,'Layer','bottom'); axis tight; grid on
    ylim(store(ii,:))
    set(findobj(gca,'Type','line'),'Clipping','off');
    SetAxesDual(gca);
end
SaveFigure('Uhlig_1rot_Slides')

% Plot first two rotations together
figure;
FigSize(27,12)
for ii = 1:Xnvar
    subplot(2,3,ii)
    plot(SRout.IRall(:,ii,1,1)); hold on
    plot(SRout.IRall(:,ii,1,3)); hold on
    plot(zeros(VARopt.nsteps),'-k');
    title(Xvnames_long{ii},'FontWeight','bold','FontSize',13);
    set(gca,'FontSize',11,'Layer','bottom'); axis tight; grid on
    ylim(store(ii,:))
    set(findobj(gca,'Type','line'),'Clipping','off');
    SetAxesDual(gca);
end
SaveFigure('Uhlig_2rot_Slides')
