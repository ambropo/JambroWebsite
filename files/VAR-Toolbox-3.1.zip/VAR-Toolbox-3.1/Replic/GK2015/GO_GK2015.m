% Replicates Figure 1 (page 61) of Gertler and Karadi (2015, AEJ:M):
% Cholesky vs. external instrument (proxy SVAR) identification of a
% monetary policy shock in a 4-variable monthly VAR.
% =======================================================================
% Outputs: 4x2 subplot comparing Cholesky (left column, red) and IV
% (right column, black) IRFs to a monetary policy shock, 48-month horizon.
% Requires VAR Toolbox 3.1.
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% November 2020. Updated: 2026-05-28
% -----------------------------------------------------------------------

%% 1. PRELIMINARIES
% -----------------------------------------------------------------------
clear all; close all; clc
warning off all
cd(fileparts(mfilename('fullpath')));

%% 2. LOAD DATA
% -----------------------------------------------------------------------
% Load raw data and parse variable names and dates from the spreadsheet
[xlsdata, xlstext] = xlsread('GK2015_Data.xlsx','Sheet1');
dates = xlstext(3:end,1);
vnames_long = xlstext(1,2:end);
vnames = xlstext(2,2:end);
nvar = length(vnames);
data = Num2NaN(xlsdata);

% Store each variable as a named field in the DATA structure
for ii=1:length(vnames)
    DATA.(vnames{ii}) = data(:,ii);
end

% Extract the first observation date for later use
year = str2double(xlstext{3,1}(1:4));
month = str2double(xlstext{3,1}(6));

% Observations
nobs = size(data,1);

%% 3. PLOT SERIES
% -----------------------------------------------------------------------
% Plot all five variables (four endogenous plus the FF4 instrument) at
% monthly frequency over the full sample.
firstdate = year + (month-1)/12;
figure;
FigSize(27,12)
for ii = 1:nvar
    subplot(2,3,ii)
    plot(DATA.(vnames{ii}),'LineWidth',3,'Color',pantone('Blue'));
    title(vnames_long(ii),'FontWeight','bold','FontSize',13);
    DatesPlot(firstdate,nobs,6,'m')
    set(gca,'FontSize',11,'Layer','bottom'); grid on;
    set(findobj(gca,'Type','line'),'Clipping','off');
    SetAxesDual(gca);
end
SaveFigure('GK_Data')

%% 4. VAR ESTIMATION
% -----------------------------------------------------------------------
% Define endogenous variables: 1-year rate, CPI, IP, excess bond premium
VARvnames_long = {'1yr rate';'CPI';'IP';'EBP';};
VARvnames      = {'gs1';'logcpi';'logip';'ebp';};
VARnvar        = length(VARvnames);

% Define external instrument: federal funds futures surprise (FF4)
IVvnames_long = {'FF4';};
IVvnames      = {'ff4_tc'};
IVnvar        = length(IVvnames);

% VAR specification: 12 lags with constant
VARnlags = 12; VARconst = 1;

% Create matrix of endogenous variables for the VAR
ENDO = nan(nobs,VARnvar);
for ii=1:VARnvar
    ENDO(:,ii) = DATA.(VARvnames{ii});
end

% Create matrix of instruments
IV = nan(nobs,IVnvar);
for ii=1:IVnvar
    IV(:,ii) = DATA.(IVvnames{ii});
end

% Estimate reduced-form VAR and attach instrument
[VAR, VARopt] = VARmodel(ENDO,VARnlags,VARconst);
VAR.IV = IV;

%% 5. CHOLESKY IDENTIFICATION
% -----------------------------------------------------------------------
% Recursive (short-run) identification for comparison with IV results.
disp('Estimate Cholesky IRFs and error bands')
VARopt.ident = 'short';
VARopt.method = 'wild';
VARopt.nsteps = 48;
VARopt.ndraws = 500;

% Compute impulse responses and bootstrap error bands
[IR, VAR] = VARir(VAR,VARopt);
[INF,SUP,MED,BAR] = VARirband(VAR,VARopt);

% Plot Cholesky IRFs in left column of a 4x2 subplot

%....... NOTES TO FIG/TAB .......
% Cholesky (recursive, short-run) IRFs to a monetary policy shock, for
% comparison with IV results. Variables in order: (1) 1-year Treasury
% rate, (2) CPI, (3) Industrial Production, (4) Excess Bond Premium.
% Red shading: bootstrap confidence bands (wild bootstrap, 200 draws);
% dashed red border lines. Solid red line: bootstrap median. 48-month
% horizon.
%..................................

% Configure swathe: red shading with dashed border lines
SwatheOpt = PlotSwatheOption;
SwatheOpt.swathecol  = [1 0 0];
SwatheOpt.swatheonly = 1;
SwatheOpt.transp     = 1;
SwatheOpt.alpha      = 0.15;
SwatheOpt.border     = 1;

figure 
FigSize(18,24)
idx = 1;
for ii=1:VARnvar
    subplot(4,2,idx)
    PlotSwathe(BAR(:,ii),[INF(:,ii) SUP(:,ii)],SwatheOpt); hold on;
    plot(BAR(:,ii),'LineWidth',2,'color',pantone('Tomato')); hold on;
    plot(zeros(VARopt.nsteps),'-k','LineWidth',0.5)
    title(VARvnames_long{ii},'FontWeight','bold')
    axis tight; grid on;
    set(gca,'Layer','bottom');
    set(findobj(gca,'Type','line'),'Clipping','off');
    SetAxesDual(gca);
    idx = idx + 2;
end
legend('Cholesky')

%% 6. IV IDENTIFICATION
% -----------------------------------------------------------------------
% External instruments (proxy SVAR) identification using FF4 futures surprise.
disp('Estimate IV IRFs and error bands')
VARopt.ident = 'iv';
VARopt.method = 'wild';

% Compute impulse responses and bootstrap error bands
[IRiv, VARiv] = VARir(VAR,VARopt);
[INFiv,SUPiv,MEDiv,BARiv] = VARirband(VARiv,VARopt);

%% 7. PLOT & SAVE

%....... NOTES TO FIG/TAB .......
% External instrument (proxy SVAR) IRFs to a monetary policy shock
% identified by FF4 federal funds futures surprises. Right column of the
% 4x2 subplot. Variables: (1) 1-year rate, (2) CPI, (3) IP, (4) EBP.
% Black shading: bootstrap confidence bands; dashed black border lines.
% Solid black line: bootstrap median. 48-month horizon. Replicates
% Figure 1 of Gertler and Karadi (2015).
%..................................

% Configure swathe: black shading with dashed border lines
SwatheOpt = PlotSwatheOption;
SwatheOpt.swathecol  = [0 0 0];
SwatheOpt.swatheonly = 1;
SwatheOpt.transp     = 1;
SwatheOpt.alpha      = 0.15;
SwatheOpt.border     = 1;

idx = 2;
for ii=1:VARnvar
    subplot(4,2,idx)
    PlotSwathe(BARiv(:,ii),[INFiv(:,ii) SUPiv(:,ii)],SwatheOpt); hold on;
    plot(BARiv(:,ii),'-k','LineWidth',2); hold on;
    plot(zeros(VARopt.nsteps),'-k','LineWidth',0.5)
    title(VARvnames_long{ii},'FontWeight','bold')
    axis tight; grid on;
    set(gca,'Layer','bottom');
    set(findobj(gca,'Type','line'),'Clipping','off');
    SetAxesDual(gca);
    idx = idx + 2;
end
legend('IV')


% -----------------------------------------------------------------------
% Save the 4x2 Cholesky vs. IV comparison figure to file.
SaveFigure('GK_Fig1');

%% 8. SLIDES FIGURES
% -----------------------------------------------------------------------
% Reproduces the Primer §15.4 layout for VAR_Primer_Slides. Proxy SVAR
% (IV) identification; figures saved with _Slides suffix.

% Configure VARopt for slide-friendly dimensions
VARopt.vnames     = VARvnames_long;
VARopt.FigSize    = [18, 12];
VARopt.pick       = 1;
VARopt.shorttitle = 1;
VARopt.figname    = 'GK_Slides';

%....... NOTES TO FIG/TAB .......
% Gertler and Karadi (2015) IV IRFs in slide dimensions. Proxy SVAR with
% FF4 futures instrument; wild bootstrap bands (500 draws). Variables:
% 1-yr T-Bill, CPI, IP, excess bond premium. 48-month horizon.
%..................................
VARirplot(BARiv,VARopt,INFiv,SUPiv);

% Custom figure: near-white swathe background with a star marker at the
% impact response (h=0), highlighting monetary policy transmission on impact.
figure;
FigSize(18,12)
SwatheOpt = PlotSwatheOption;
SwatheOpt.swathecol = [0.97 0.97 0.97];
SwatheOpt.linecol   = [0.97 0.97 0.97];
for ii = 1:VARnvar
    subplot(2,2,ii)
    PlotSwathe(BARiv(:,ii),[INFiv(:,ii) SUPiv(:,ii)],SwatheOpt); hold on
    plot(zeros(1,VARopt.nsteps),'-k','LineWidth',0.5); hold on
    plot(1,BARiv(1,ii),'LineStyle','-','Color',pantone('Blue'),'LineWidth',2,...
        'Marker','*','MarkerSize',15); hold on
    xlim([1 VARopt.nsteps])
    title(VARvnames_long{ii},'FontWeight','bold','FontSize',13)
    set(gca,'FontSize',11,'Layer','bottom'); grid on
    set(findobj(gca,'Type','line'),'Clipping','off');
    SetAxesDual(gca);
end
SaveFigure('GK_alt_Slides')
