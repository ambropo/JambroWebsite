% Replicates Figure 1 and Table 1.B of Stock and Watson (2001, JEP):
% Cholesky identification of monetary policy shocks in a trivariate VAR
% for inflation, unemployment, and the federal funds rate.
% =======================================================================
% Outputs: toolbox IRF and FEVD plots; OLS coefficient table; Table 1.B
% (variance decomposition at horizons 1,4,8,12) printed to screen.
% Requires VAR Toolbox 3.1.
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% November 2020. Updated: 2026-05-28
% -----------------------------------------------------------------------

%% 1. PRELIMINARIES
% -----------------------------------------------------------------------
clear all; close all; clc
warning off all
cd(fileparts(mfilename('fullpath')));

%% 2. LOAD DATA
% -----------------------------------------------------------------------
% Load raw data and parse variable names and dates from the spreadsheet
[xlsdata, xlstext] = xlsread('SW2001_Data.xlsx','Sheet1');
X = xlsdata; % raw data matrix passed to VARmodel
dates = xlstext(3:end,1);
vnames_long = xlstext(1,2:end);
vnames = xlstext(2,2:end);
nvar = length(vnames);
data = Num2NaN(xlsdata);

% Store each variable as a named field in the DATA structure
for ii=1:length(vnames)
    DATA.(vnames{ii}) = data(:,ii);
end

% Extract the first observation date (year and quarter) for later use
year = str2double(xlstext{3,1}(1:4));
quarter = str2double(xlstext{3,1}(6));

% Observations
nobs = size(data,1);

%% 3. PLOT SERIES
% -----------------------------------------------------------------------
% Plot all three variables over the full sample at quarterly frequency.
firstdate = year + (quarter-1)/4;
figure;
FigSize(27,6)
for ii = 1:nvar
    subplot(1,3,ii)
    plot(DATA.(vnames{ii}),'LineWidth',3,'Color',pantone('Blue'));
    title(vnames_long(ii),'FontWeight','bold','FontSize',13);
    DatesPlot(firstdate,nobs,6,'q')
    set(gca,'FontSize',11,'Layer','bottom'); grid on;
    set(findobj(gca,'Type','line'),'Clipping','off');
    SetAxesDual(gca);
end
SaveFigure('SW_Data')

%% 4. VAR ESTIMATION
% -----------------------------------------------------------------------
% 4 lags with constant (quarterly data; replicates Stock and Watson, 2001)
det = 1;
nlags = 4;

% Estimate reduced-form VAR by OLS
[VAR, VARopt] = VARmodel(X,nlags,det);

% Print OLS coefficient table on screen
VARopt.vnames = vnames;
[TABLE, beta] = VARprint(VAR,VARopt,2);

%% 5. COMPUTE IRF AND FEVD
% -----------------------------------------------------------------------
% Set options for IRF calculation: recursive (short-run) identification
VARopt.nsteps = 24;
VARopt.ident = 'short';
VARopt.ndraws = 500;
VARopt.vnames = vnames_long;
VARopt.FigSize = [27,6];
VARopt.subplot = [1,3];

% Compute impulse responses
[IR, VAR] = VARir(VAR,VARopt);

% Compute bootstrap error bands
[IRinf,IRsup,IRmed,IRbar] = VARirband(VAR,VARopt);

% Compute forecast error variance decomposition
[VD, VAR] = VARvd(VAR,VARopt);

% Compute FEVD bootstrap error bands
[VDinf,VDsup,VDmed,VDbar] = VARvdband(VAR,VARopt);

% Plot impulse responses — toolbox standard 3x3 grid (variable x shock)

%....... NOTES TO FIG/TAB .......
% All 9 IRFs (3 variables x 3 Cholesky shocks) with bootstrap confidence
% bands. Recursive identification; variable order: inflation,
% unemployment, federal funds rate. Replicates Figure 1 of Stock and
% Watson (2001).
%..................................
VARopt.figname = 'SW_Fig1';
VARirplot(IRbar,VARopt,IRinf,IRsup);

% Plot FEVD — toolbox standard bar chart (one panel per variable)
%....... NOTES TO FIG/TAB .......
% FEVD bar chart for all 3 variables over 24 quarters, decomposed by
% Cholesky shock. Toolbox standard output; same identification as IRF.
%..................................
VARopt.figname = 'SW_VD';
VARvdplot(VDbar,VARopt);

%% 6. PRINT TABLE 1.B ON SCREEN
% -----------------------------------------------------------------------
% Assemble variance decomposition at horizons 1, 4, 8, 12 for each
% variable, matching Table 1.B of Stock and Watson (2001).
FEVD_Table(1, :) = VD(1,:,1);
FEVD_Table(2, :) = VD(4,:,1);
FEVD_Table(3, :) = VD(8,:,1);
FEVD_Table(4, :) = VD(12,:,1);

FEVD_Table(5, :) = VD(1,:,2);
FEVD_Table(6, :) = VD(4,:,2);
FEVD_Table(7, :) = VD(8,:,2);
FEVD_Table(8, :) = VD(12,:,2);

FEVD_Table(9, :) = VD(1,:,3);
FEVD_Table(10,:) = VD(4,:,3);
FEVD_Table(11,:) = VD(8,:,3);
FEVD_Table(12,:) = VD(12,:,3);

% Print each block on screen

%....... NOTES TO FIG/TAB .......
% Table 1.B, Stock and Watson (2001, JEP). Variance decomposition at
% horizons 1, 4, 8, 12 quarters, printed to screen for each structural
% shock in turn. Rows = horizons; columns = fraction of each variable's
% forecast-error variance explained by the shock. Cholesky identification;
% variable order: inflation, unemployment, federal funds rate.
%..................................
disp(' ')
disp('Variance Decomposition of Inflation (t=1,4,8,12)')
disp('---------------------------------------------------')
disp(FEVD_Table(1:4,:));
disp('Variance Decomposition of Unemployment (t=1,4,8,12)')
disp('---------------------------------------------------')
disp(FEVD_Table(5:8,:));
disp('Variance Decomposition of Fed Funds (t=1,4,8,12)')
disp('---------------------------------------------------')
disp(FEVD_Table(9:12,:));
