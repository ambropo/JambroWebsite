% Replicates Figure 2 (page 662) of Blanchard and Quah (1989, AER):
% long-run identification of supply and demand shocks in a bivariate VAR
% for US GDP growth and the unemployment rate.
% =======================================================================
% Outputs: toolbox IRF plot (all 4 responses with bootstrap bands) and a
% custom Figure 2 replication plot (cumulative GDP and unemployment).
% Requires VAR Toolbox 3.1.
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% November 2020. Updated: 2026-05-28
% -----------------------------------------------------------------------

%% 1. PRELIMINARIES
% -----------------------------------------------------------------------
clear all; close all; clc
warning off all
cd(fileparts(mfilename('fullpath')));

%% 2. LOAD DATA
% -----------------------------------------------------------------------
% Load raw data and parse variable names and dates from the spreadsheet
[xlsdata, xlstext] = xlsread('BQ1989_Data.xlsx','Sheet1');
dates = xlstext(3:end,1);
vnames_long = xlstext(1,2:end);
vnames = xlstext(2,2:end);
nvar = length(vnames);
data = Num2NaN(xlsdata);

% Store each variable as a named field in the DATA structure
for ii=1:length(vnames)
    DATA.(vnames{ii}) = data(:,ii);
end

% Extract the first observation date (year and quarter) for later use
year = str2double(xlstext{3,1}(1:4));
quarter = str2double(xlstext{3,1}(6));

% Observations and data matrix passed to the VAR
nobs = size(data,1);
X = data;

%% 3. PLOT SERIES
% -----------------------------------------------------------------------
% Plot both variables over the full sample at quarterly frequency.
firstdate = year + (quarter-1)/4;
figure;
FigSize(18,6)
for ii = 1:nvar
    subplot(1,2,ii)
    plot(DATA.(vnames{ii}),'LineWidth',3,'Color',pantone('Blue'));
    title(vnames_long(ii),'FontWeight','bold','FontSize',13);
    DatesPlot(firstdate,nobs,6,'q')
    set(gca,'FontSize',11,'Layer','bottom'); grid on;
    set(findobj(gca,'Type','line'),'Clipping','off');
    SetAxesDual(gca);
end
SaveFigure('BQ_Data')

%% 4. VAR ESTIMATION
% -----------------------------------------------------------------------
% 8 lags with constant (quarterly data; paper specifies 8 lags, fn. 3, p. 659)
det = 1;
nlags = 8;

% Estimate reduced-form VAR by OLS
[VAR, VARopt] = VARmodel(X,nlags,det);

%% 5. COMPUTE IRF AND FEVD
% -----------------------------------------------------------------------
% Set options for IRF calculation: long-run (Blanchard-Quah) identification
VARopt.nsteps = 40;
VARopt.ident = 'long';
VARopt.vnames = vnames_long;
VARopt.FigSize = [18,6];

% Compute impulse responses
[IR, VAR] = VARir(VAR,VARopt);

% Compute bootstrap error bands
[IRinf,IRsup,IRmed,IRbar] = VARirband(VAR,VARopt);

% Plot all impulse responses — toolbox standard 2x2 grid (variable x shock)

%....... NOTES TO FIG/TAB .......
% All 4 IRFs (GDP growth and unemployment to supply and demand shock)
% with bootstrap confidence bands. Long-run (Blanchard-Quah) restriction:
% the demand shock has no long-run effect on the output level (cumulative
% GDP growth returns to zero at long horizons after a demand shock).
%..................................
VARopt.figname= 'BQ';
VARirplot(IRbar,VARopt,IRinf,IRsup);

%% 6. REPLICATE FIGURE 2 OF BLANCHARD AND QUAH
% -----------------------------------------------------------------------
% Reproduce Figure 2 of BQ (1989): cumulative GDP response (level) and
% unemployment response to each structural shock.

%....... NOTES TO FIG/TAB .......
% Figure 2, Blanchard and Quah (1989, AER, p. 662). Left panel: impulse
% responses to the supply shock; right panel: responses to the demand
% shock. Each panel shows the cumulative GDP growth response (output
% level, cmap color 1) and the unemployment rate response (cmap color 2)
% over 40 quarters. Demand IRFs are sign-flipped (positive demand shock
% raises output and lowers unemployment).
%..................................

figure
FigSize(18,6)

% Plot supply shock responses
subplot(1,2,1)
plot(cumsum(IR(:,1,1)),'LineWidth',2.5,'Color',pantone('Blue'))
hold on
plot(IR(:,2,1),'LineWidth',2.5,'Color',pantone('Tomato'))
hold on
plot(zeros(VARopt.nsteps),'--k')
grid on;
title('Supply shock')
legend({'GDP Level';'Unemployment'})
set(gca,'Layer','bottom');
set(findobj(gca,'Type','line'),'Clipping','off');
SetAxesDual(gca);

% Plot demand shock responses
subplot(1,2,2)
plot(cumsum(-IR(:,1,2)),'LineWidth',2.5,'Color',pantone('Blue'))
hold on
plot(-IR(:,2,2),'LineWidth',2.5,'Color',pantone('Tomato'))
hold on
plot(zeros(VARopt.nsteps),'--k')
grid on;
title('Demand shock')
legend({'GDP Level';'Unemployment'})
set(gca,'Layer','bottom');
set(findobj(gca,'Type','line'),'Clipping','off');
SetAxesDual(gca);

% Save figure
SaveFigure('BQ_Fig1Fig2');
