% Replicates Figure 5a and Figure 6a of Jordà and Taylor (2025, JEL):
% LP and LP-IV impulse responses to a monetary policy shock.
% =======================================================================
% Figure 5a: LP-OLS response of log CPI (x100) to a unit Romer-Romer
%   shock (quarterly, 1985Q1-2007Q4, 18-horizon). Plotted with 68% and
%   95% Newey-West confidence bands.
% Figure 6a: LP-IV response of the unemployment rate to a unit federal
%   funds rate shock, instrumented by the Romer-Romer shock
%   (monthly, 1985M1-2000M1, 49-horizon). Plotted with 68% and 95%
%   Newey-West confidence bands.
% Requires VAR Toolbox 3.1 and LPmodel with longdiff and IV support.
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% May 2025. Updated: 2026-05-28
% -----------------------------------------------------------------------

%% 1. PRELIMINARIES
% -----------------------------------------------------------------------
clear all; close all; clc
warning off all
cd(fileparts(mfilename('fullpath')));

%% 2. FIGURE 5A: LP OF LOG CPI RESPONSE TO ROMER-ROMER SHOCK
% -----------------------------------------------------------------------
% LP-OLS of log CPI (x100) on the Romer-Romer shock (quarterly,
% 1985Q1-2007Q4). LHS is the long-difference lcpi_{t+h} - lcpi_{t-1}.
% Controls: 4 lags of dlrgdp, dlcpi, dstir. NW bandwidth = h-1.

% Load quarterly data from Ex5 tab; variables follow toolbox header format
xlstext5 = readcell('JT2025_Data.xlsx',   'Sheet', 'Ex5');
xlsdata5 = readmatrix('JT2025_Data.xlsx', 'Sheet', 'Ex5', 'Range', 'B3');
dates5       = xlstext5(3:end,1);
vnames5_long = xlstext5(1,2:end);
vnames5      = xlstext5(2,2:end);
data5   = Num2NaN(xlsdata5);
nobs5   = size(data5,1);

% Store each variable as a named field in DATA5
for ii = 1:length(vnames5)
    DATA5.(vnames5{ii}) = data5(:,ii);
end

% Parse quarterly dates (format: '1960q1') and restrict to 1985Q1-2007Q4
year5 = zeros(nobs5,1);
qtr5  = zeros(nobs5,1);
for ii = 1:nobs5
    dstr = dates5{ii};
    qpos = strfind(dstr,'q');
    year5(ii) = str2double(dstr(1:qpos-1));
    qtr5(ii)  = str2double(dstr(qpos+1:end));
end
idx5_start = find(year5 == 1985 & qtr5 == 1);
idx5_end   = find(year5 == 2007 & qtr5 == 4);

% Plot series
nvar5      = length(vnames5);
firstdate5 = year5(1) + (qtr5(1)-1)/4;
figure;
FigSize(27,12)
for ii = 1:nvar5
    subplot(2,4,ii)
    plot(data5(:,ii),'LineWidth',3,'Color',pantone('Blue'));
    title(vnames5_long(ii),'FontWeight','bold','FontSize',13);
    DatesPlot(firstdate5,nobs5,6,'q')
    set(gca,'FontSize',11,'Layer','bottom'); grid on;
    set(findobj(gca,'Type','line'),'Clipping','off');
    SetAxesDual(gca);
end
SaveFigure('JT_Data_Ex5')

% Extract sample variables; scale lcpi to percent
lcpi5     = 100 * DATA5.lcpi(idx5_start:idx5_end);
rr_shock5 = DATA5.rr_shock(idx5_start:idx5_end);
dlrgdp5   = DATA5.dlrgdp(idx5_start:idx5_end);
dlcpi5    = DATA5.dlcpi(idx5_start:idx5_end);
dstir5    = DATA5.dstir(idx5_start:idx5_end);

% Set LP options and run LP-OLS estimation
LPopt5          = LPoption;
LPopt5.nsteps   = 18;
LPopt5.nlag     = 4;
LPopt5.longdiff = 1;
LPopt5.impact   = 1;
LPopt5.pctg     = 95;
LPopt5.LAGS     = [dlrgdp5 dlcpi5 dstir5];
LPopt5.EXOG     = [];
LPopt5.IV       = [];

[IR5, ~, INF95_5, SUP95_5] = LPmodel(lcpi5, rr_shock5, LPopt5);

% Derive 68% bands by rescaling the 95% bands via Normal quantile ratio
c95 = norminv(0.975);
c68 = norminv(0.84);
INF68_5 = IR5 - (IR5 - INF95_5) * (c68/c95);
SUP68_5 = IR5 + (SUP95_5 - IR5) * (c68/c95);

% Set display options and plot with LPirplot

%....... NOTES TO FIG/TAB .......
% Figure 5a, Jordà and Taylor (2025, JEL). LP-OLS impulse response of
% log CPI (x100) to a unit Romer-Romer monetary policy shock. LHS:
% cumulative change lcpi_{t+h} - lcpi_{t-1}. Controls: 4 lags of
% dlrgdp, dlcpi, dstir. Sample: 1985Q1-2007Q4. Green shading: 95%
% (light) and 68% (dark) Newey-West confidence bands.
%..................................
LPopt5.vnames   = {'CPI'};
LPopt5.sname    = 'Romer-Romer shock';
LPopt5.figname  = 'JT_Fig5a';
LPopt5.FigSize  = [9,6];
LPopt5.color   = cmap(6);
LPopt5.marker   = 'none';
LPopt5.hstart   = 0;
LPopt5.xtick    = 0:5:15;
LPopt5.xlim     = [0 17];
LPopt5.ylim     = [-6 2];
LPopt5.ylabel   = 'Percent';
LPopt5.visible  = 1;

% Outer band = 95%, inner band = 68%
LPirplot(IR5, LPopt5, INF95_5, SUP95_5, INF68_5, SUP68_5)

%% 3. FIGURE 6A: LP-IV RESPONSE OF UNEMPLOYMENT TO MONETARY POLICY SHOCK
% -----------------------------------------------------------------------
% LP-IV of unemployment on the FFR, instrumented by the Romer-Romer RRCG
% shock (monthly, 1985M1-2000M1). LHS: urate_{t+h} - urate_{t-1}.
% Controls: 6 lags of urate, infl, ffr. Instruments: RRCGShock and 6 lags.

% Load monthly data from Ex6 tab
xlstext6 = readcell('JT2025_Data.xlsx',   'Sheet', 'Ex6');
xlsdata6 = readmatrix('JT2025_Data.xlsx', 'Sheet', 'Ex6', 'Range', 'B3');
dates6       = xlstext6(3:end,1);
vnames6_long = xlstext6(1,2:end);
vnames6      = xlstext6(2,2:end);
data6   = Num2NaN(xlsdata6);
nobs6   = size(data6,1);

% Store each variable as a named field in DATA6
for ii = 1:length(vnames6)
    DATA6.(vnames6{ii}) = data6(:,ii);
end

% Parse monthly dates (format: '1965m12') and restrict to 1985M1-2000M1
year6 = zeros(nobs6,1);
mon6  = zeros(nobs6,1);
for ii = 1:nobs6
    dstr = dates6{ii};
    mpos = strfind(dstr,'m');
    year6(ii) = str2double(dstr(1:mpos-1));
    mon6(ii)  = str2double(dstr(mpos+1:end));
end
idx6_start = find(year6 == 1985 & mon6 == 1);
idx6_end   = find(year6 == 2000 & mon6 == 1);

% Plot series
nvar6      = length(vnames6);
firstdate6 = year6(1) + (mon6(1)-1)/12;
figure;
FigSize(27,12)
for ii = 1:nvar6
    subplot(2,3,ii)
    plot(data6(:,ii),'LineWidth',3,'Color',pantone('Blue'));
    title(vnames6_long(ii),'FontWeight','bold','FontSize',13);
    DatesPlot(firstdate6,nobs6,6,'m')
    set(gca,'FontSize',11,'Layer','bottom'); grid on;
    set(findobj(gca,'Type','line'),'Clipping','off');
    SetAxesDual(gca);
end
SaveFigure('JT_Data_Ex6')

% Extract sample variables
urate6     = DATA6.urate(idx6_start:idx6_end);
infl6      = DATA6.infl(idx6_start:idx6_end);
ffr6       = DATA6.ffr(idx6_start:idx6_end);
RRCGShock6 = DATA6.RRCGShock(idx6_start:idx6_end);

% Set LP-IV options and run estimation
% LPopt.IV = ffr (endogenous treatment); S = RRCGShock (external instrument)
% nlag_iv = 6 adds lags 1-6 of RRCGShock as extra instruments, matching
% Stata: instruments(rz l(1/6).rz) wmatrix(unadjusted) twostep
LPopt6          = LPoption;
LPopt6.nsteps   = 49;
LPopt6.nlag     = 6;
LPopt6.longdiff = 1;
LPopt6.impact   = 1;
LPopt6.pctg     = 95;
LPopt6.LAGS     = [urate6 infl6 ffr6];
LPopt6.EXOG     = [];
LPopt6.IV       = ffr6;
LPopt6.nlag_iv  = 6;

[IR6, LPout6, INF95_6, SUP95_6] = LPmodel(urate6, RRCGShock6, LPopt6);

% Derive 68% bands
INF68_6 = IR6 - (IR6 - INF95_6) * (c68/c95);
SUP68_6 = IR6 + (SUP95_6 - IR6) * (c68/c95);

% Set display options and plot with LPirplot

%....... NOTES TO FIG/TAB .......
% Figure 6a, Jordà and Taylor (2025, JEL). LP-IV impulse response of the
% unemployment rate to a unit 1pp FFR shock, instrumented by the RRCG
% shock (Coibion et al., 2017). LHS: cumulative change urate_{t+h} -
% urate_{t-1}. Controls: 6 lags of urate, infl, ffr. Instruments:
% RRCGShock and 6 lags (overidentified, joint two-step GMM). Sample:
% 1985M1-2000M1. Blue shading: 95% (light) and 68% (dark) NW bands.
%..................................
LPopt6.vnames    = {'Unemployment rate'};
LPopt6.sname     = 'FFR shock (LP-IV)';
LPopt6.figname   = 'JT_Fig6a';
LPopt6.FigSize  = [9,6];
LPopt6.color     = pantone('Blue_Dark');
LPopt6.marker    = 'none';
LPopt6.hstart    = 0;
LPopt6.xtick     = 0:12:48;
LPopt6.xlim      = [0 48];
LPopt6.ylim      = [-1 2.65];
LPopt6.ylabel    = 'Percentage points';
LPopt6.boxoff    = 1;

% Plot IRF (outer = 95%, inner = 68%); LPirplot saves a first version,
% then the joint-test annotation is added and the figure is re-saved.
LPirplot(IR6, LPopt6, INF95_6, SUP95_6, INF68_6, SUP68_6)