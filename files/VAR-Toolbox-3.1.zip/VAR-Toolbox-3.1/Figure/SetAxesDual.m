function SetAxesDual(ax)
% =======================================================================
% Apply dual-axis panel style: box off, tick marks and labels on both
% left and right y-axes, inward ticks, slightly thicker axis lines,
% and a visual closure tick at YLim(2) that is 2x the standard length.
% =======================================================================
% SetAxesDual(ax)
% -----------------------------------------------------------------------
% INPUT
%   - ax: axes handle to style [dflt = gca]
% -----------------------------------------------------------------------
% NOTES
%   Reads the left ruler's Limits (the user-set ylim) before creating the
%   right ruler, then locks both rulers to identical Limits/TickValues/
%   TickLabels via direct property assignment (ax.YAxis(n).*). Direct
%   assignment is used throughout — not the ylim/yticks/yticklabels
%   convenience functions — to avoid active-ruler routing ambiguity that
%   can silently apply values to the wrong ruler.
%   The left ruler is locked (explicit TickValues + Limits) before yyaxis
%   switches context; this prevents MATLAB from re-auto-ticking the left
%   ruler when the right ruler is first created.
%   Both rulers are locked a second time after switching back to the left,
%   because the switch can trigger a re-auto-tick in some MATLAB configs.
%   Special case: if the top tick is exactly 0 and the range spans negative
%   values and the user has not already set YLim(2) above 0, YLim(2) is
%   nudged to 0.2 x tick_spacing so a zero-reference line at y=0 does not
%   merge with the closure tick drawn at YLim(2).
%   The closure tick at YLim(2) is drawn as a line() only — it is NOT
%   added to TickValues, which would create an unwanted extra gridline.
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: May 2026. Updated: 2026-05-27
% -----------------------------------------------------------------------

if nargin < 1; ax = gca; end

lw  = 1.0;
tli = ax.TickLabelInterpreter;

% Flush pending renders so MATLAB finalises auto-tick values before capture
drawnow('nocallbacks');

% Capture left-axis state before any ruler manipulation.
% yl is read from Limits (the user-set ylim), not derived from tick bounds,
% so that an explicit ylim call is always honoured.
yl     = ax.YAxis(1).Limits;
ytk_L  = ax.YAxis(1).TickValues;
ytkl_L = ax.YAxis(1).TickLabels;

% Special case: top tick exactly 0 with negative range and no positive
% headroom — nudge YLim(2) so the zero-reference line at y=0 does not
% merge visually with the closure tick drawn at YLim(2)
if ~isempty(ytk_L) && ytk_L(end) == 0 && ytk_L(1) < 0 ...
        && numel(ytk_L) >= 2 && yl(2) <= 0
    yl(2) = 0.2 * (ytk_L(end) - ytk_L(end-1));
end

% Lock left ruler before creating the right ruler.
% Explicit TickValues/TickLabels/Limits prevent MATLAB from re-auto-ticking
% the left ruler when yyaxis switches context below.
ax.YAxis(1).Limits        = yl;
ax.YAxis(1).TickValues    = ytk_L;
ax.YAxis(1).TickLabels    = ytkl_L;
ax.YAxis(1).LineWidth     = lw;
ax.YAxis(1).TickDirection = 'in';

% Create the right ruler via yyaxis, then configure it via direct property
% assignment on ax.YAxis(2). Direct assignment avoids active-ruler routing
% (ylim/yticks/yticklabels route to whichever ruler is currently active,
% which is fragile); writing to ax.YAxis(2) is unambiguous regardless of
% which ruler yyaxis has made active.
yyaxis(ax, 'right');
ax.YAxis(2).Limits        = yl;
ax.YAxis(2).TickValues    = ytk_L;
ax.YAxis(2).TickLabels    = ytkl_L;
ax.YAxis(2).Color         = ax.YAxis(1).Color;
ax.YAxis(2).LineWidth     = lw;
ax.YAxis(2).TickDirection = 'in';

% Switch back to left and restore interpreter
yyaxis(ax, 'left');
ax.TickLabelInterpreter = tli;

% Re-lock both rulers after the switch: switching rulers can trigger a
% re-auto-tick on either ruler in some MATLAB configurations
ax.YAxis(1).Limits     = yl;
ax.YAxis(1).TickValues = ytk_L;
ax.YAxis(1).TickLabels = ytkl_L;
ax.YAxis(2).Limits     = yl;
ax.YAxis(2).TickValues = ytk_L;
ax.YAxis(2).TickLabels = ytkl_L;

% Axes-level formatting
ax.LineWidth = lw;
ax.Box       = 'off';

% ----- Draw closure tick at YLim(2) as a pure line() -----
% NOT added to TickValues to avoid an extra gridline near the top.
% Re-read xl/yl after all ruler assignments so lines land exactly on the
% axis boundary. Tick length is computed from actual pixel dimensions so
% the mark is visually 2x a standard tick regardless of aspect ratio.
yl = ax.YLim;
xl = ax.XLim;

fig       = ancestor(ax, 'figure');
old_units = get(fig, 'Units');
set(fig, 'Units', 'pixels');
fig_px    = get(fig, 'Position');
set(fig, 'Units', old_units);
ax_w_px    = ax.Position(3) * fig_px(3);
ax_h_px    = ax.Position(4) * fig_px(4);
std_tick_x = ax.TickLength(1) * max(ax_w_px, ax_h_px) * diff(xl) / ax_w_px;
tk_long    = 2.0 * std_tick_x;

lcolor = ax.YAxis(1).Color;
line(ax, [xl(1),         xl(1)+tk_long], [yl(2), yl(2)], ...
     'Color', lcolor, 'LineWidth', lw, 'HandleVisibility', 'off', 'Clipping', 'off');
line(ax, [xl(2)-tk_long, xl(2)        ], [yl(2), yl(2)], ...
     'Color', lcolor, 'LineWidth', lw, 'HandleVisibility', 'off', 'Clipping', 'off');
