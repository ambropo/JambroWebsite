function out = cmap(n)
% =======================================================================
% Return the 1x3 RGB color vector corresponding to index n in the
% toolbox color sequence:
%   1 blue, 2 yellow, 3 purple, 4 light blue, 5 red, 6 green, 7 dark red
% =======================================================================
% out = cmap(n)
% -----------------------------------------------------------------------
% INPUT
%   - n: index into the color sequence [double]
% -----------------------------------------------------------------------
% OUTPUT
%   - out: 1x3 RGB color vector [double]
% -----------------------------------------------------------------------
% EXAMPLE
%   out = cmap(1);
% =======================================================================
% VAR Toolbox 3.1
% Ambrogio Cesa-Bianchi
% ambrogiocesabianchi@gmail.com
% First version: March 2015. Updated: 2026-05-19
% -----------------------------------------------------------------------

%% 1. DEFINE COLOR TABLE AND RETURN REQUESTED COLOR
% -----------------------------------------------------------------------
% The first seven entries are hand-tuned toolbox colors; entries 8-9 are
% additional named colors; remaining rows are filled from parula.
colors = [...
    0.000,0.447,0.741 ; % 1 blue
    0.929,0.694,0.125 ; % 2 yellow
    0.494,0.184,0.556 ; % 3 purple
    0.301,0.745,0.933 ; % 4 light blue
    0.850,0.325,0.098 ; % 5 red
    0.466,0.674,0.188 ; % 6 green
    0.635,0.078,0.184 ; % 7 dark red
    0/255,48/255,143/255; % 8 air force blue
    209/255,96/255,1/255; % 9 orange
    parula];
out = colors(n,:);
