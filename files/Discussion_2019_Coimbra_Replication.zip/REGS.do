import excel "C:\Users\ambrogio\Dropbox\Nuno\DATA.xlsx", sheet("DATA_ALL") firstrow clear

*===============================================================================
* Prelims
*===============================================================================
gen qq=quarter(day)
gen yy=year(day)
gen t=yq(yy,qq)
format t %tq
xtset id t
sort id t
gen spread_stress = spread*stress
drop ds*

*===============================================================================
* Standardize variables
*===============================================================================
gen aux = 100*(s_bank/L4.s_bank-1)
bys id: egen aux_bar = mean(aux)
bys id: egen aux_std = sd(aux)
bys id: gen ds_bank = (aux-aux_bar)/aux_std
drop aux*

gen aux = 100*(s_priv/L4.s_priv-1)
bys id: egen aux_bar = mean(aux)
bys id: egen aux_std = sd(aux)
bys id: gen ds_priv = (aux-aux_bar)/aux_std
drop aux*

gen aux = 100*(bank/L4.bank-1)
bys id: egen aux_bar = mean(aux)
bys id: egen aux_std = sd(aux)
bys id: gen d_bank = (aux-aux_bar)/aux_std
drop aux*

gen aux = 100*(priv/L4.priv-1)
bys id: egen aux_bar = mean(aux)
bys id: egen aux_std = sd(aux)
bys id: gen d_priv = (aux-aux_bar)/aux_std
drop aux*

gen aux = 100*spread
bys id: egen aux_bar = mean(aux)
bys id: egen aux_std = sd(aux)
bys id: gen s = (aux-aux_bar)/aux_std
drop aux*

gen aux = 100*(spread-L4.spread)
bys id: egen aux_bar = mean(aux)
bys id: egen aux_std = sd(aux)
bys id: gen d_s = (aux-aux_bar)/aux_std
drop aux*

*===============================================================================
* Limit sample to "constrained" and "LTRO". Drop Greece and Germany.
*===============================================================================
drop if t<tq(2009q3)
drop if t>tq(2012q1)
drop if country=="Greece"
drop if country=="Germany"

*===============================================================================
* Positive correlation between private sector holdings and spreads
*===============================================================================
* HOLDING PRIV vs SPREAD
eststo clear
eststo: qui reghdfe d_priv d_s if country!="Germany", absorb(id)
eststo: qui reghdfe d_priv d_s if country!="Germany" & stress==0, absorb(id)
eststo: qui reghdfe d_priv d_s if country!="Germany" & stress==1, absorb(id)
eststo: qui reghdfe d_priv d_s if country!="Germany" & id==3 | id==7, absorb(id)
esttab, starl( * 0.10 ** 0.05 *** 0.01) mlabel("ALL" "NO STRESS" "STRESS" "IT/ES")
estout using "C:\Users\ambrogio\Dropbox\Nuno\TAB3.txt", replace ///
cells(b(fmt(4) label(b)) se(fmt(4) label(std)) p(fmt(4) label(p-value))) ///
label stats(r2 N, labels ("R2" "Obs") fmt(4 0)) ///
mlabels("ALL" "NO STRESS" "STRESS" "IT/ES")

*===============================================================================
* Negative correlation between private sector holdings and MIF holdings
*===============================================================================
* HOLDING BANK vs HOLDING PRIV
eststo clear
eststo: qui reghdfe ds_bank ds_priv, absorb(id)
eststo: qui reghdfe ds_bank ds_priv if stress==0, absorb(id)
eststo: qui reghdfe ds_bank ds_priv if stress==1, absorb(id)
eststo: qui reghdfe ds_bank ds_priv if id==3 | id==7, absorb(id) 
esttab, starl( * 0.10 ** 0.05 *** 0.01) mlabel("ALL" "NO STRESS" "STRESS" "IT/ES")
estout using "C:\Users\ambrogio\Dropbox\Nuno\TAB1.txt", replace ///
cells(b(fmt(4) label(b)) se(fmt(4) label(std)) p(fmt(4) label(p-value))) ///
label stats(r2 N, labels ("R2" "Obs") fmt(4 0)) ///
mlabels("ALL" "NO STRESS" "STRESS" "IT/ES")



