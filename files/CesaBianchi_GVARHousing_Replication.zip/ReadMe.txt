House price data used for "Housing Cycles and Macroeconomic
Fluctuations: A Global Perspective", by A. Cesa-Bianchi (2012).

The excel file contains real house price data for 40 countries. The data for the remaining variables used in the paper are the same as: Ambrogio Cesa-Bianchi & M. Hashem Pesaran & Alessandro Rebucci & TengTeng Xu, 2012. "China's Emergence in the World Economy and Business Cycles in Latin America," Journal of LACEA Economia, LACEA - LATIN AMERICAN AND CARIBBEAN ECONOMIC ASSOCIATION.

If you use this data set please cite as: 

Ambrogio Cesa-Bianchi, 2012. "Housing Cycles and Macroeconomic
Fluctuations: A Global Perspective", IDB Working Paper Series No. IDB-WP-343, Inter-American Development Bank, Research Department.


