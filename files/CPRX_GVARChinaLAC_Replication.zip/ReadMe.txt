Data for replication of "China's Emergence in the World Economy and Business Cycles in Latin America", by A. Cesa-Bianchi et al. (2012).

The excel file contains data for 33 countries for real GDP, CPI inflation, Real Equity Prices, Real Exchange Rate, Long-term and Short-term Interest Rates, and Oil Price.

The variables are defined as in the main text.

If you use this data set please cite as:

Ambrogio Cesa-Bianchi & M. Hashem Pesaran & Alessandro Rebucci & TengTeng Xu, 2012. "China's Emergence in the World Economy and Business Cycles in Latin America," Journal of LACEA Economia, LACEA - LATIN AMERICAN AND CARIBBEAN ECONOMIC ASSOCIATION.