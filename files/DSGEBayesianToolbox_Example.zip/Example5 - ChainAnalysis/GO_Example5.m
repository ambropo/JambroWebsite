% This example shows how ot analyze the convergence and identification 
% of a DSGE model estimated with Bayesian techniques in Dynare. 

% The DSGE Bayesian Toolbox and the VAR Toolbox 2.0 are both required to 
% run this code. To get the latest version of the toolboxes visit: 
% 
%       https://sites.google.com/site/ambropo/MatlabCodes
% 
% =======================================================================
% Ambrogio Cesa Bianchi, March 2015
% ambrogio.cesabianchi@gmail.com


%% 1. PRELIMINARIES
% =======================================================================
clear all; clear session; close all; clc
warning off all

% Name of mod file:
fname_ = 'fs2000';

% If you place this file in the Dynare output folder, get the current directory 
pathinfo  = what;
path = pathinfo.path;

% Set the current directory
cd(path)
fnameXX   = [fname_ '_Chain'];

% specify directory to save the results
dir_save = ['Chain Analysis Results'];
mkdir(dir_save)


%% 2. Load the data
% =======================================================================
% Load Chain
disp('');
disp('Loading the chain');
[XX, ndraws] = LoadChain(fname_);
disp('Done!');

% Load Posterior mode
[Mode, HH, param_names] = LoadMode(fname_);
param_names = param_names';
nparam      = size(Mode,1);

% Load results from dynare
results = load( [fname_ '_results.mat'] );
aux     = size(results.M_.params,1);
nshocks = nparam-aux;
clear aux

% Load prior information
prior = load( [fname_ '\prior\definition.mat'] );




%% 3. Transform the data
% =======================================================================
% Drop the burn in observations
burnin = 0.5;
drop = round(burnin*ndraws);
X = XX(drop+1:ndraws,:);
[nobs, aux_nparam] = size(X);

% make a check on the number of parameters
if aux_nparam ~= nparam
    disp(' ');
    disp('Error: the number of parameters in the posterior mode does not');
    disp('correspond to the number of parameters in the chain.');
    return
end

% Save
save([dir_save filesep fnameXX],'X','XX')



%% 4. Plot Posterior
% =======================================================================
disp(' ');
disp('Plotting posterior...');
option = PlotLineOption;
option.FigName = [dir_save filesep 'PosteriorDistribution'];
FigSize(32,16)
HistfitPlot(X,param_names,option)
disp('Done!');





%% 5. Plot Prior VS Posterior
% =======================================================================
disp(' ');
disp('Plotting prior VS posterior...');
figname = [dir_save filesep 'PriorPosterior'];
FigSize(32,16)
PriorPostPlot(X,Mode,prior.bayestopt_,param_names,figname)
disp('Done!');





%% 6. Summary statistics (print on screen)
% =======================================================================
disp(' ');
disp('Computing summary statistics...');
Xmode   = mode(X);
Xmean   = mean(X);
Xmedian = median(X);

% I have to run the loop here to avoid memory problems with prctile.m when
% nobs > 300000
Xp5  = zeros(1,nparam);
Xp95 = zeros(1,nparam);
for ii=1:nparam
    Xp5(1,ii)  = prctile(X(:,ii),5);
    Xp95(1,ii) = prctile(X(:,ii),95);
end

Xtable  = [Mode Xmode' Xmean' Xp5' Xmedian' Xp95'];

in.cnames = char( {'PostMode','Mode','Mean','Conf 5%','Median','Conf 95%'} );
in.rnames = char({'parameter'; char(param_names)});
in.fmt = '%6.3f';
disp(' ');
mprint(Xtable,in)
disp('Done!');






%% 7. Calculate and scatter plot correlations between the parameters (implied by the Hessian)
% asymptotically these correspond to the ones implied by the chain
% =======================================================================
disp(' ');
disp('Calculating correlations implied by the Hessian...');

% Hessian in the inverse of the variance-covariance matrix of the estimated
% parameters
HHinv = inv(HH);

% Formula to compute correlation from a VCV matrix
CorrHessian = diag(1./sqrt(diag(HHinv))) * HHinv * diag(1./sqrt(diag(HHinv)));

% Take only the elements below the diagonal
corr_aux = tril(CorrHessian,-1);

% Look for values above a threshold
CorrBound = 0.1;
[r, c] = find(abs(corr_aux)>CorrBound);
extremeHH = cell(length(r),3);

% Print them in a matrix
for i=1:length(r)
    extremeHH{i,1} = param_names{r(i)};
    extremeHH{i,2} = param_names{c(i)};
    extremeHH{i,3} = corr_aux(r(i),c(i));
end
disp('Done!');



%% 8. Calculate and scatter plot correlations between the parameters (implied by the chain)
% =======================================================================
disp(' ');
disp('Calculating correlations implied by the chain...');
Xcorr = corr(X);

% Take only the elements below the diagonal
corr_aux = tril(Xcorr,-1);

% Look for values above a threshold
[rr, cc] = find(abs(corr_aux)>CorrBound);
extremeXcorr = cell(length(rr),3);

% Print them in a matrix
for i=1:length(rr)
    extremeXcorr{i,1} = param_names{rr(i)};
    extremeXcorr{i,2} = param_names{cc(i)};
    extremeXcorr{i,3} = corr_aux(rr(i),cc(i));
end

% I can use CorrBound to select the pairs of parameter chains I want to
% scatterplot.
FigSize(32,16)
if size(r,1)>1
    disp(' ')
    disp('Printing scatter plots...')
    figname = [dir_save filesep 'Scatter(Chain)'];
    ScatterParameter(X,param_names,rr,cc,3,4,figname)
    disp('Done!');
end




%% 9. Plot the entire chain for each parameter
% =======================================================================
disp(' ')
disp('Printing the entire chain...')
select = round(linspace(1,ndraws,500))';
XXplot = XX(select,:);

option.savename  = [dir_save filesep 'ChainPlot'];
option.LineWidth(1) = 0.01;
option.ynames = param_names;
option.do_x = 0;
PlotLine(XXplot,option)
disp('Done!');




%% 10. Compute cusum statistics (on the whole chain)
% =======================================================================
disp(' ')
disp('Computing and printing CUSUM...')
nobs_cusum = 20000; % number of observations for cusum test
if nobs_cusum > ndraws
    disp('Watch out: nobs_cusum exceeds number of draws.');
    disp('I automatically set it to half of # draws ')
    nobs_cusum = ndraws / 2;
end
select  = round(linspace(1,ndraws,nobs_cusum))'; % shrink the chain (see YADA manual)
XXcusum = cusum(XX(select,:))';
figname  = [dir_save filesep 'Cusum'];
FigSize(32,16)
CusumPlot(XXcusum,select,drop,param_names,3,4,figname)
disp('Done!');


